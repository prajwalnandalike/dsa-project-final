const express=require('express');
const {adminSignup, generateOTP, verifyOTP, adminLogin}=require('../controllers/adminController');
const protect=require('../middleware/authMiddleware');
const router=express.Router();

router.post('/signup', adminSignup);
router.post('/send-otp', generateOTP);
router.post('/verify-otp', verifyOTP);
router.post('/login', adminLogin);
router.get('/protected', protect, (req, res)=>{

  if(req.user.role!=='admin'){
    return res.status(403).json({
      message:'Admin access required'
    })
  }
  res.json({
    message:"Admin authentication successful",
    user:req.user
  })
});



module.exports=router;

