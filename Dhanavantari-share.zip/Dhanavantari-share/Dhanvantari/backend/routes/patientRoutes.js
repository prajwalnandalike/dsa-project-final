const allowRoles=require('../middleware/roleMiddleware')
const express=require('express');
const {createPatient, getPatients, getPatientById, updatePatient, deactivatePatient}=require('../controllers/patientController');
const protect=require('../middleware/authMiddleware');

const router=express.Router();

router.post('/', protect, allowRoles('admin', 'doctor', 'intern'), createPatient);
router.get('/', protect, allowRoles('admin', 'doctor', 'intern'),  getPatients);
router.get('/:id', protect, allowRoles('admin', 'doctor', 'intern'),  getPatientById)
router.put('/:patientId', protect, allowRoles('admin', 'doctor', 'intern'),   updatePatient)
router.delete('/:patientId', protect, allowRoles('admin', 'doctor', 'intern'), deactivatePatient)


module.exports=router;
