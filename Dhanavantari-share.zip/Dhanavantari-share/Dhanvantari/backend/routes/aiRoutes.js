const express = require("express");
const protect = require("../middleware/authMiddleware");

const {
  generateClinicalSummary,
} = require("../controllers/aiController");

const router = express.Router();

router.post("/clinical-summary", protect, generateClinicalSummary);

module.exports = router;