const express=require('express')
const allowRoles=require('../middleware/roleMiddleware')
const {createIntern, getInterns, getInternById, updateIntern, deactivateIntern, activateIntern, internLogin}=require('../controllers/internController')
const protect=require('../middleware/authMiddleware')
const router=express.Router()

router.post('/', protect, allowRoles('admin', 'doctor'), createIntern)
router.get('/', protect, allowRoles('admin', 'doctor'), getInterns)
router.get('/:id', protect, allowRoles('admin', 'doctor'), getInternById)
router.put('/:id', protect, allowRoles('admin', 'doctor'), updateIntern)
router.delete('/:id', protect, allowRoles('admin'), deactivateIntern)
router.patch('/:id/activate', protect, allowRoles('admin'), activateIntern)
router.post('/login', internLogin)


module.exports=router;