const express = require("express");
const protect = require("../middleware/authMiddleware");
const allowRoles = require("../middleware/roleMiddleware");

const {
  getAuditLogs,
} = require("../controllers/auditController");

const router = express.Router();

router.get(
  "/",
  protect,
  allowRoles("admin"),
  getAuditLogs
);

module.exports = router;