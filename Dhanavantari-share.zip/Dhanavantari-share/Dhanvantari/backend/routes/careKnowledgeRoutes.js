const express = require('express')

const {
  getCareRecommendations
} = require('../controllers/careKnowledgeController')

const protect = require('../middleware/authMiddleware')
const allowRoles = require('../middleware/roleMiddleware')

const router = express.Router()

router.get(
  '/',
  protect,
  allowRoles('admin', 'doctor', 'intern'),
  getCareRecommendations
)

module.exports = router