const express = require("express");
const protect = require("../middleware/authMiddleware");

const {
  searchTerminology,
} = require("../controllers/terminologyMappingController");

const router = express.Router();

router.get("/search", protect, searchTerminology);

module.exports = router;