const express=require('express');
const allowRoles=require('../middleware/roleMiddleware')
const protect=require('../middleware/authMiddleware');
const {createDoctor, getDoctors, getDoctorById, updateDoctor, deactivateDoctor,activateDoctor, doctorlogin }=require('../controllers/doctorController')
const router=express.Router();

router.post('/', protect, allowRoles('admin'),  createDoctor)
router.get('/', protect, allowRoles('admin', 'doctor'),  getDoctors)

router.get('/:id', protect, allowRoles('admin', 'doctor'),  getDoctorById)
router.put('/:id', protect, allowRoles('admin'), updateDoctor)
router.delete('/:id', protect, allowRoles('admin'),  deactivateDoctor)
router.patch('/:id/activate' , protect, allowRoles('admin'),  activateDoctor)
router.post('/login', doctorlogin)


module.exports=router