const express = require("express");
const protect=require('../middleware/authMiddleware')
const {
  createCase,
  getAllCases,
  getCaseById,
  getCasesByPatient,
  updateCase,
  deleteCase,
} = require("../controllers/caseController");

const router = express.Router();

// Create a new case
router.post("/",protect, createCase);

// Get all cases
router.get("/",protect, getAllCases);

// Get cases for a specific patient
router.get("/patient/:patientId",protect, getCasesByPatient);

// Get one case by ID
router.get("/:id",protect, getCaseById);

// Update a case
router.put("/:id",protect, updateCase);

// Delete a case
router.delete("/:id",protect, deleteCase);

module.exports = router;