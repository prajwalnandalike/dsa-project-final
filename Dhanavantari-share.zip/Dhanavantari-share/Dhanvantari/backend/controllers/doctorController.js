const bcrypt=require('bcryptjs')
const Doctor=require('../models/Doctor')
const jwt=require('jsonwebtoken')

const createDoctor=async (req, res)=>{

  try{
    console.log("doctor craete user", req.user)
    if(req.user.role!=='admin'){
      return res.status(403).json({
        message:'Only admin can create the doctor'
      })
    }
  const {doctorName, email, mobile, registrationNumber, qualification, specialization, department, password}=req.body
  if(!doctorName || !email || !mobile||  !registrationNumber|| !qualification || !password ){
    return res.status(400).json({
      message:'fields are required'
    })
  }
  const existingDoctor=await Doctor.findOne({
    hospitalId: req.user.hospitalId,
    $or:[
      {email:email.toLowerCase()},
      {registrationNumber}
    ]

  })
  if(existingDoctor){
    return res.status(400).json({
      message:'Doctor already exists'
    })
  }
  const hashedPassword=await bcrypt.hash(password, 12)
  const doctor=await Doctor.create({
    hospitalId:req.user.hospitalId,
    doctorName, 
    email:email.toLowerCase(), 
    mobile, 
    registrationNumber, 
    qualification, 
    specialization, 
    department,
    password:hashedPassword,
    role:'doctor',
    createdBy:{
      userId:req.user.userId,
      role:'admin'

    }

  })

  res.status(201).json({
    message:'Doctor created successfully', doctor
  })
  }catch(error){
    console.log(error);
    res.status(500).json({
      message:'failed to create the doctor'
    })

  }
}
const doctorlogin=async(req, res)=>{
  try{
    const {email, password}=req.body;
    if(!email || !password){
      return res.status(400).json({error:'Email and password are required'});
    }

    const doctor=await Doctor.findOne({
      email:email.toLowerCase()
    })
    if(!doctor){
      return res.status(401).json({
        message:'invalid details'
      })
    }
    if(!doctor.isActive){
      return res.status(401).json({
        message:'doctor account is inactive'
      })
    }
    const isPasswordValid=await bcrypt.compare(password, doctor.password)
    if(!isPasswordValid){
      return res.status(401).json({
        message:'invalid  email or password'
      })

    }
    const token=jwt.sign({
      userId:doctor._id,
      role:'doctor',
      hospitalId:doctor.hospitalId
    }, process.env.JWT_SECRET, { expiresIn:'1d'})
    res.status(200).json({
      message:'Doctor login successfull', token, 
      doctor:{
        id:doctor._id,
        doctorName:doctor.doctorName,
        email:doctor.email,
        role:doctor.role,
        hospitalId:doctor.hospitalId

      }
    })

  }catch(error){
    console.log(error);
    res.status(500).json({
      message:'Internal server error during doctor login'
    })

  }
}



const getDoctors=async(req, res)=>{
  try{
    if(req.user.role!=='admin'){
      return res.status(403).json({
        message:"Only admin can view"
      })
    }
    const doctors=await Doctor.find({
      hospitalId:req.user.hospitalId
    })
    .select('-password')
    .sort({createAt:-1})

    res.json({
      doctors
    })


  }catch(error){
    console.log(error);
    res.status(500).json({
      messsage:'failed to get the doctor'
    })

  }
}

const getDoctorById=async(req, res)=>{
  try{
    if(req.user.role!=='admin'){
      return  res.status(403).json({
        message:"Only admin can view"
      })
    }
    const doctor =await Doctor.findOne({
      _id:req.params.id,
      hospitalId:req.user.hospitalId
    }).select('-password')

    if(!doctor){
      return res.status(404).json({
        message:'doctor not found'
      })
    }
    
    res.json({
      doctor
    })

  }catch(error){
    console.log(error)
    res.status(500).json({
      message:'Failed to fetch doctor'
    })

  }
}
const updateDoctor=async(req, res)=>{
  try{
    if(req.user.role!=='admin'){
      return  res.status(403).json({
        message:"Only admin can update"
      })
    }
    const doctor =await Doctor.findOne({
      _id:req.params.id,
      hospitalId:req.user.hospitalId
    })
    if(!doctor){
      return res.status(404).json({
        message:'doctor not found'
      })
    }
    const allowedFields=[
      'doctorName', 
      'email', 
      'mobile', 
      'registrationNumber',
      'qualification', 
      'specialization', 
      'department',  
    ]
    allowedFields.forEach((field)=>{
      if(req.body[field]!==undefined){
        doctor[field]=req.body[field]
      }
    })

    if(req.body.password){
      doctor.password=await bcrypt.hash(req.body.password, 12)
    }
    await doctor.save();
    res.json({
      message:'doctor updated successfully'
    })



  }catch(error){
    console.log(error)
    res.status(500).json({
      message:'Failed to  update doctor'
    })

  }
}
const deactivateDoctor=async(req, res)=>{
  try{
    if(req.user.role!=='admin'){
      return  res.status(403).json({
        message:"Only admin can deactivate doctor"
      })
    }
    const doctor =await Doctor.findOne({
      _id:req.params.id,
      hospitalId:req.user.hospitalId
    })
    if(!doctor){
      return res.status(404).json({
        message:'doctor not found'
      })
    }
    doctor.isActive=false
    await doctor.save()
    res.json({
      message:"doctor deactivated successfully"
    })

  }catch(error){
    console.log(error)
    res.status(500).json({
      message:'Failed to  deactivate doctor'
    })

  }
}
// Activate Doctor
const activateDoctor = async (req, res) => {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        message: 'Only admin can activate doctors'
      })
    }

    const doctor = await Doctor.findOne({
      _id: req.params.id,
      hospitalId: req.user.hospitalId
    })

    if (!doctor) {
      return res.status(404).json({
        message: 'Doctor not found'
      })
    }

    doctor.isActive = true

    await doctor.save()

    res.json({
      message: 'Doctor activated successfully'
    })
  } catch (error) {
    console.error('Activate doctor error:', error)

    res.status(500).json({
      message: 'Failed to activate doctor'
    })
  }
}
module.exports={createDoctor, getDoctors, getDoctorById, updateDoctor, deactivateDoctor,activateDoctor, doctorlogin }