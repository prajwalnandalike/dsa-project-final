const bcrypt=require('bcryptjs')
const Intern=require('../models/Intern')
const jwt=require('jsonwebtoken')
const Doctor=require('../models/Doctor')

const createIntern=async(req, res)=>{
  try{
    if(req.user.role!=='admin' && req.user.role !=='doctor'){
      return res.status(403).json({
        message:'ONly admin or doctor can add intern'
      })
    }
    const {internName, internId, email, mobile, college, course, year, department, joiningDate, supervisorDoctorId, password}=req.body
    
    if(!internName || !internId || !email || !mobile || !password){
      return res.status(400).json({
        message:'fields are required'
      })
    }
    const existingIntern=await Intern.findOne({
      hospitalId:req.user.hospitalId,
      $or:[{internId}, {email: email.toLowerCase()}]
    })
    if(existingIntern){
      return res.status(400).json({
        message:'Intern already exists'
      })
    }
    let supervisiorId=supervisorDoctorId || null
    if(req.user.role==='doctor'){
      supervisiorId=req.user.userId
    }
    let supervisor=null
    if(supervisiorId){
      supervisor=await Doctor.findOne({
        _id:supervisiorId,
        hospitalId:req.user.hospitalId,
        isActive:true
      })
    
    if(!supervisor){
      return res.status(400).json({
        message:'invalid  supervisor doctor'
      })
    }
  }
    const hashedPassword=await bcrypt.hash(password, 12)
    const intern=await Intern.create({
      hospitalId:req.user.hospitalId,
      internName,
      internId,
      email:email.toLowerCase(),
      mobile,
      college,
      course,
      year,
      department,
      joiningDate,
      supervisorDoctorId:supervisorDoctorId,
      password:hashedPassword,
      role:'intern',
      createdBy:{
        userId:req.user.userId,
        role:req.user.role
      }
    })

    const internResponse=intern.toObject()
    delete internResponse.password

    res.status(201).json({
      message:'Intern created successfully', intern:internResponse
    })

  }catch(error){
    console.log(error)
    res.status(500).json({
      message:'failed to create intern'
    })

  }
}
const getInterns = async (req, res) => {
  try {
    const interns = await Intern.find({
      hospitalId: req.user.hospitalId
    }).select('-password')

    res.json({
      count: interns.length,
      interns
    })
  } catch (error) {
    console.error('Get interns error:', error)

    res.status(500).json({
      message: 'Failed to fetch interns'
    })
  }
}
const getInternById = async (req, res) => {
  try {
    const intern = await Intern.findOne({
      internId: req.params.id,
      hospitalId: req.user.hospitalId
    })
      .select('-password')
      .populate('supervisorDoctorId', 'doctorName email specialization')

    if (!intern) {
      return res.status(404).json({
        message: 'Intern not found'
      })
    }

    return res.json({
      intern
    })

  } catch (error) {
    console.error('Get intern error:', error)

    return res.status(500).json({
      message: 'Failed to fetch intern'
    })
  }
}
const updateIntern = async (req, res) => {
  try {
    const intern = await Intern.findOne({
      internId: req.params.id,
      hospitalId: req.user.hospitalId
    })

    if (!intern) {
      return res.status(404).json({
        message: 'Intern not found'
      })
    }

    const allowedFields = [
      'internName',
      'email',
      'mobile',
      'college',
      'course',
      'year',
      'department',
      'joiningDate',
      'supervisorDoctorId'
    ]

    allowedFields.forEach((field) => {
      if (req.body[field] !== undefined) {
        intern[field] = req.body[field]
      }
    })

    // Validate supervisor if changed
    if (req.body.supervisorDoctorId) {
      const supervisor = await Doctor.findOne({
        _id: req.body.supervisorDoctorId,
        hospitalId: req.user.hospitalId,
        isActive: true
      })

      if (!supervisor) {
        return res.status(400).json({
          message: 'Invalid supervisor doctor'
        })
      }
    }

    await intern.save()

    const internResponse = intern.toObject()
    delete internResponse.password

    return res.json({
      message: 'Intern updated successfully',
      intern: internResponse
    })

  } catch (error) {
    console.error('Update intern error:', error)

    return res.status(500).json({
      message: 'Failed to update intern'
    })
  }
}
const deactivateIntern = async (req, res) => {
  try {
    const intern = await Intern.findOne({
      internId: req.params.id,
      hospitalId: req.user.hospitalId
    })

    if (!intern) {
      return res.status(404).json({
        message: 'Intern not found'
      })
    }

    intern.isActive = false

    await intern.save()

    return res.json({
      message: 'Intern deactivated successfully'
    })

  } catch (error) {
    console.error('Deactivate intern error:', error)

    return res.status(500).json({
      message: 'Failed to deactivate intern'
    })
  }
}
const activateIntern = async (req, res) => {
  try {
    const intern = await Intern.findOne({
      internId: req.params.id,
      hospitalId: req.user.hospitalId
    })

    if (!intern) {
      return res.status(404).json({
        message: 'Intern not found'
      })
    }

    intern.isActive = true

    await intern.save()

    return res.json({
      message: 'Intern activated successfully'
    })

  } catch (error) {
    console.error('Activate intern error:', error)

    return res.status(500).json({
      message: 'Failed to activate intern'
    })
  }
}
const internLogin = async (req, res) => {
  try {
    const { email, password } = req.body

    if (!email || !password) {
      return res.status(400).json({
        message: 'Email and password are required'
      })
    }

    const intern = await Intern.findOne({
      email: email.toLowerCase()
    })

    if (!intern) {
      return res.status(401).json({
        message: 'Invalid email or password'
      })
    }

    if (!intern.isActive) {
      return res.status(403).json({
        message: 'Intern account is inactive'
      })
    }

    const isMatch = await bcrypt.compare(
      password,
      intern.password
    )

    if (!isMatch) {
      return res.status(401).json({
        message: 'Invalid email or password'
      })
    }

    const token = jwt.sign(
      {
        userId: intern._id,
        role: 'intern',
        hospitalId: intern.hospitalId
      },
      process.env.JWT_SECRET,
      {
        expiresIn: '1d'
      }
    )

    return res.json({
      message: 'Intern login successful',
      token,

      intern: {
        id: intern._id,
        internName: intern.internName,
        internId: intern.internId,
        email: intern.email,
        hospitalId: intern.hospitalId,
        role: intern.role,
        supervisorDoctorId: intern.supervisorDoctorId
      }
    })

  } catch (error) {
    console.error('Intern login error:', error)

    return res.status(500).json({
      message: 'Intern login failed'
    })
  }
}
module.exports={createIntern, getInterns, getInternById, updateIntern, deactivateIntern, activateIntern, internLogin}