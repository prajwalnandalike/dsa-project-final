const bcrypt=require('bcryptjs')
const Patient=require('../models/Patient');
const mongoose=require('mongoose')
// const Hospital=require('../models/Hospital');
const createPatient =async(req, res)=>{
  try{
    console.log('authenticated user', req.user)
    const {patientId, patientName, dateOfBirth, age, gender, mobile, email, address, bloodGroup, abhaNumber, registrationType, loginEnabled, password, guardian}=req.body;
    if(!patientId || !patientName || !registrationType){
      return res.status(400).json({
        message:'Patient ID, name, registration type is required'
      })

    }
      const existingPatient=await Patient.findOne({
        hospitalId: req.user.hospitalId, patientId
      })
      if(existingPatient){
        return res.status(400).json({
          message:'Patient ID is already exists'
        })
      }

    let hashedPassword
    if(password){
      hashedPassword=await bcrypt.hash(password, 12);
    }
    const patient=await Patient.create({
      hospitalId:req.user.hospitalId,
      patientId, 
      patientName, 
      dateOfBirth, 
      age, 
      gender, 
      mobile, 
      email, 
      address, 
      bloodGroup, 
      abhaNumber, 
      registrationType, 
      loginEnabled: loginEnabled || false, 
      password: hashedPassword, 
      guardian,
      createdBy:{
        userId:req.user.userId,
        role:req.user.role
      }

    })
    res.status(201).json({
      message:'Patient created successfully', patient
    })
    

  }catch(error){
    console.log(error);
    res.status(500).json({
      message:'Failed to create patient'
    })

  }
}
const getPatients = async (req, res) => {
  try {
    const hospitalId = req.user.hospitalId

    const patients = await Patient.find({
      hospitalId
    }).sort({ createdAt: -1 })

    const totalPatients = patients.length

    const activePatients = patients.filter(
      patient => patient.isActive === true
    ).length

    const today = new Date()
    today.setHours(0, 0, 0, 0)

    const registeredToday = patients.filter(
      patient => new Date(patient.createdAt) >= today
    ).length

    const admittedPatients = 0

    res.json({
      patients,
      stats: {
        totalPatients,
        activePatients,
        admittedPatients,
        registeredToday
      }
    })

  } catch (error) {
    console.error(error)

    res.status(500).json({
      message: 'Failed to fetch patients'
    })
  }
}

const getPatientById= async(req, res)=>{
  try{
    const patient = await Patient.findOne({
      patientId:req.params.id,
      hospitalId: req.user.hospitalId
    })
    if(!patient){
      return res.status(404).json({
        message:'Patient not found'
      })
    }

    res.json({
      patient
    })

  }catch(error){
    console.error(error)

    res.status(500).json({
      message: 'Failed to fetch patient'
    })

  }
}

const updatePatient=async(req, res)=>{
  try{
    const {patientId} =req.params
    const patient =await Patient.findOne({
      hospitalId:req.user.hospitalId,
      patientId:patientId
    })
    if(!patient){
      return res.status(404).json({
        message:'patient not found'
      })
    }
    const allowedFields=[
      'patientName', 
      'dateOfBirth', 
      'age', 
      'gender',
      'mobile' ,
      'email', 
      'address', 
      'bloodGroup', 
      'abhaNumber', 
      'registrationType', 
      'loginEnabled', 
      'password', 
      'guardian'

    ]
    allowedFields.forEach((field)=>{
      if(req.body[field]!==undefined){
        patient[field]=req.body[field]
      }
    })
    await patient.save();
    res.json({
      message:'Patient updated successfully'
    })

  }catch(error){
    console.log(error);
    res.status(500).json({message:'failed to update patient'})

  }
}

const deactivatePatient = async (req, res) => {
  try {
    const { patientId } = req.params

    const patient = await Patient.findOne({
      hospitalId: req.user.hospitalId,
      patientId: patientId
    })

    if (!patient) {
      return res.status(404).json({
        message: 'Patient not found'
      })
    }

    patient.isActive = false

    await patient.save()

    res.json({
      message: 'Patient deactivated successfully'
    })
  } catch (error) {
    console.error(error)

    res.status(500).json({
      message: 'Failed to deactivate patient'
    })
  }
}
module.exports={createPatient, getPatients, getPatientById, updatePatient, deactivatePatient}