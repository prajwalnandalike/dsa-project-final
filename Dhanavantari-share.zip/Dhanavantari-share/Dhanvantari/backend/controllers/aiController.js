const OpenAI = require("openai");
const TerminologyMapping = require("../models/TerminologyMapping");

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

const generateClinicalSummary = async (req, res) => {
  try {
    const { diagnosis, caseData, medicalSystem } = req.body;

    if (!diagnosis) {
      return res.status(400).json({
        success: false,
        message: "Diagnosis is required",
      });
    }


// Find terminology mapping
const normalizeTerminology = (term) => {
  return term
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ");
};


const searchTerm = normalizeTerminology(diagnosis);
const terminologyAliases = {
  jwara: "jvarah",
};

const lookupTerm = terminologyAliases[searchTerm] || searchTerm;
console.log("Diagnosis:", diagnosis);
console.log("Search term:", searchTerm);
console.log("Lookup term:", lookupTerm);

const mapping = await TerminologyMapping.findOne({
  $or: [
    { namcTerm: { $regex: lookupTerm, $options: "i" } },
    { namEnglish: { $regex: lookupTerm, $options: "i" } },
    {
      namEnglishIndexRelated: {
        $regex: lookupTerm,
        $options: "i",
      },
    },
    {
      primaryIndexRelated: {
        $regex: lookupTerm,
        $options: "i",
      },
    },
  ],
  mappingStatus: "mapped",
});
    console.log("FOUND MAPPING:", mapping);
    let mappingContext = "No direct terminology mapping was found.";

    if (mapping) {
      mappingContext = `
NAMC Term: ${mapping.namcTerm || ""}
NAMC Code: ${mapping.namcCode || ""}
ICD-11 TM2 Code: ${mapping.icd11Tm2Code || ""}
ICD-11 TM2 Multicode: ${mapping.icd11Tm2Multicode || ""}
English Term: ${mapping.namEnglish || ""}
Definition: ${mapping.longDefinition || ""}
Mapping Status: ${mapping.mappingStatus}
`;
    }

    const prompt = `
You are generating a standardized biomedical clinical summary from an AYUSH clinical case.

Medical System:
${medicalSystem || "AYUSH"}

AYUSH Diagnosis:
${diagnosis}

Verified terminology mapping from the hospital database:
${mappingContext}

Clinical case data:
${JSON.stringify(caseData || {}, null, 2)}

Generate a concise, structured clinical summary for use by a medical professional.

Requirements:
1. Use only information present in the clinical case data.
2. Use the verified terminology mapping provided above.
3. Do not invent an ICD-11 TM2 code.
4. Do not invent symptoms, examination findings, investigations, diagnoses, medicines, or treatment.
5. Do not provide treatment recommendations.
6. Clearly distinguish documented findings from clinical interpretation.
7. If no mapping was found, explicitly state that no direct standardized mapping was found.
8. Write in standard biomedical/clinical terminology so that the case can be understood across medical systems.

Return the summary with these headings:

Presenting Complaints
Relevant History
Examination Findings
Investigations
Standardized Terminology
Clinical Impression
Mapping / Uncertainty
`;

    const response = await openai.responses.create({
      model: "gpt-5.6",
      input: prompt,
    });

    const clinicalSummary = response.output_text;

    return res.status(200).json({
      success: true,
      clinicalSummary,
      mapping: mapping || null,
    });
  } catch (error) {
    console.error("AI clinical summary error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to generate clinical summary",
    });
  }
};

module.exports = {
  generateClinicalSummary,
};