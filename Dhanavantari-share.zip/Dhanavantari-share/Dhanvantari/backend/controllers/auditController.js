const AuditLog=require('../models/auditLog');

const createAuditLog=async ({
  userId,
  role,
  action,
  targetType,
  targetId,
  description,
  ipAddress
})=>{
  try{
    await AuditLog.create({
      userId,
      role,
      action,
      targetType,
      targetId,
      description,
      ipAddress
    });
  } 
  catch(error){
    console.error('Error creating audit log:', error.message);
    throw new Error('Failed to create audit log');
  }
}

const getAuditLogs = async (req, res) => {
  try {
    const logs = await AuditLog.find()
      .sort({ createdAt: -1 })
      .limit(5);

    res.json({ logs });
  } catch (error) {
    console.error("Error fetching audit logs:", error);
    res.status(500).json({ message: "Failed to fetch audit logs" });
  }
};

module.exports={createAuditLog, getAuditLogs};