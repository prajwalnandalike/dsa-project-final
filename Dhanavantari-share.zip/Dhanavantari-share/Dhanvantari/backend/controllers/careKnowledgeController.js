const CareKnowledge = require('../models/careKnowledge')

const getCareRecommendations = async (req, res) => {
  try {
    const {
      medicalSystem,
      diseaseName,
      dosha,
      patientGroup
    } = req.query

    if (!medicalSystem || !diseaseName) {
      return res.status(400).json({
        message: 'Medical system and disease are required'
      })
    }

    const query = {
      medicalSystem: medicalSystem.toLowerCase(),
      diseaseName: {
      $regex: `^${diseaseName}$`,
      $options:'i'},

      isActive: true
    }
    if (dosha) {
  query.dosha = dosha
    }

   if (patientGroup) {
  query.$or = [
    {
      patientGroup: null
    },
    {
      patientGroup: {
        $regex: `^${patientGroup}$`,
        $options: 'i'
      }
    }
    ]
   }
   

    const recommendations = await CareKnowledge.find(query)
     
    const care = {
  pathya: [],
  apathya: [],
  dosage: [],
  sevanaKala: []
}

recommendations.forEach((item) => {
  if (item.pathya) {
    care.pathya.push(item.pathya)
  }

  if (item.apathya) {
    care.apathya.push(item.apathya)
  }

  if (item.dosage) {
    care.dosage.push({
      patientGroup: item.patientGroup,
      value: item.dosage
    })
  }

  if (item.sevanaKala) {
    care.sevanaKala.push({
      patientGroup: item.patientGroup,
      value: item.sevanaKala
    })
  }
})

res.status(200).json({
  message: 'Care recommendations fetched successfully',

  medicalSystem,
  disease: diseaseName,
  dosha: dosha || null,
  patientGroup: patientGroup || null,

  care
})
    
  } catch (error) {
    console.error(error)

    res.status(500).json({
      message: 'Failed to fetch care recommendations'
    })
  }
}

module.exports = {
  getCareRecommendations
}