const TerminologyMapping = require("../models/TerminologyMapping");

// Search terminology mapping
const searchTerminology = async (req, res) => {
  try {
    const { term } = req.query;

    if (!term || !term.trim()) {
      return res.status(400).json({
        success: false,
        message: "Terminology search term is required",
      });
    }

    const searchTerm = term.trim();

    // 1. Try exact match first
    const exactMatch = await TerminologyMapping.findOne({
      $or: [
        { namcTerm: { $regex: `^${searchTerm}$`, $options: "i" } },
        { namEnglish: { $regex: `^${searchTerm}$`, $options: "i" } },
        {
          nameEnglishIndexRelated: {
            $regex: `^${searchTerm}$`,
            $options: "i",
          },
        },
      ],
    });

    if (exactMatch) {
      return res.status(200).json({
        success: true,
        count: 1,
        mapping: exactMatch,
      });
    }

    // 2. If exact match is not found, search partial matches
    const mappings = await TerminologyMapping.find({
      $or: [
        { namcTerm: { $regex: searchTerm, $options: "i" } },
        { namEnglish: { $regex: searchTerm, $options: "i" } },
        {
          nameEnglishIndexRelated: {
            $regex: searchTerm,
            $options: "i",
          },
        },
        {
          primaryIndexRelated: {
            $regex: searchTerm,
            $options: "i",
          },
        },
      ],
    })
      .sort({ mappingStatus: 1 })
      .limit(10);

    return res.status(200).json({
      success: true,
      count: mappings.length,
      mappings,
    });
  } catch (error) {
    console.error("Terminology search error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to search terminology mapping",
    });
  }
};

module.exports = {
  searchTerminology,
};