const bcrypt=require('bcryptjs');
const Admin=require('../models/admin');
const OTP=require('../models/otp');
const Hospital=require('../models/Hospital');
const jwt=require('jsonwebtoken');
const {createAuditLog}=require('./auditController');

const adminSignup=async(req, res)=>{
  try{
    const {hospitalName, hospitalId, medicalSystem, address, hospitalPhoneNumber, hospitalEmail, website,  adminName, email, phoneNumber, password}=req.body;
    if(!hospitalName || !hospitalId || !medicalSystem || !address || !hospitalPhoneNumber || !hospitalEmail || !website || !adminName || !email || !phoneNumber || !password){
      return res.status(400).json({error:'All fields are required'});
    }
    const existingEmail=await Admin.findOne({email});
    if(existingEmail){
      return res.status(400).json({error:'Email already exists'});
    }

    const existingPhoneNumber=await Admin.findOne({phoneNumber});
    if(existingPhoneNumber){
      return res.status(400).json({error:'Phone number already exists'});
    }
    const existingHospital=await Hospital.findOne({hospitalId});
    if(existingHospital){
      return res.status(400).json({error:'Hospital ID already exists'});
    }
    const hospital=await Hospital.create({
      hospitalName,
      hospitalId,
      medicalSystem,
      address,
      phoneNumber:hospitalPhoneNumber,
      email:hospitalEmail,
      website
    })

    const hashedPassword=await bcrypt.hash(password, 10);
    const admin= await Admin.create({
      hospitalId:hospital._id,
      adminName,
      email,
      phoneNumber,
      password:hashedPassword,
      phoneNumberVerified:false,
      isActive:true
    });
    hospital.activeAdminId=admin._id;
     await hospital.save();
    res.status(201).json({message:'Admin registered successfully. Please verify the phone number', adminId:admin._id, hospitalId:hospital._id});

  }
  catch(error){
    console.error('Error during admin signup:', error.message);
    res.status(500).json({error:'Internal server error during admin signup'});
  }
}

const generateOTP=async(req, res)=>{
  try{
    const {phoneNumber}=req.body;
    if(!phoneNumber){
      return res.status(400).json({error:'Phone number is required'});
    }
    const otp=Math.floor(100000+Math.random()*900000).toString();
    console.log("generated admin otp", otp);
    const expiresAt=new Date(Date.now()+10*60*1000); // OTP expires in 10 minutes
    OTP.deleteMany({phoneNumber});
    await OTP.create({phoneNumber, otp, expiresAt});
    res.status(200).json({message:'OTP generated successfully', otp:otp});

  }
  catch(error){
    console.error('Error during OTP generation:', error.message);
    res.status(500).json({error:'Internal server error during OTP generation'});
  }
}

const verifyOTP=async(req, res)=>{
  try{
    const {phoneNumber, otp}=req.body;
    if(!phoneNumber|| !otp){
      return res.status(400).json({message:'Phone number and otp are required'});
    }
    const otpRecord=await OTP.findOne({phoneNumber}).sort({createdAt:-1});
    if(!otpRecord){
      return res.status(400).json({message:'No OTP found for this phone number'});
    }
    if(new Date()>otpRecord.expiresAt){
      await OTP.deleteOne({_id:otpRecord._id});
      return res.status(400).json({message:'OTP has expired'});
    }
    console.log("hi", otpRecord.otp);
    console.log("otp", otp);
    
    if(otpRecord.otp!==otp){
      otpRecord.attempts +=1;
      await otpRecord.save();

      return res.status(404).json({
        message:"Invalid otp"
      })

    }
    const admin=await Admin.findOne({phoneNumber});
    if(!admin){
      return res.status(404).json({message:'Admin not found'});
    }
    admin.phoneNumberVerified=true
    await admin.save();

    await OTP.deleteOne({_id:otpRecord._id});

    //audit log
    await createAuditLog({
      userId:admin._id,
      role:'admin',
      action:'OTP_VERIFIED',  
      targetType:'Admin',
      targetId:admin._id,
      description:'Admin phone number verified successfully',
      ipAddress:req.ip
    })
    res.status(200).json({message:'Phone number verified successfully'});
  }catch(error){
    console.error('OTP verification error:', error.message);
    res.status(500).json({error:'Internal server error during OTP verification'});
  }
}

const adminLogin=async (req, res)=>{
  try{
    const {email, password}=req.body;
    if(!email || !password){
      return res.status(400).json({error:'Email and password are required'});
    }
    const admin=await Admin.findOne({email});
    if(!admin){
      await createAuditLog({
        role:'admin',
        action:'LOGIN_FAILED',
        description:'Admin login failed account not found',
        ipAddress:req.ip
      })
      return res.status(404).json({error:'Admin not found'});
    }
    if(!admin.isActive){
      return res.status(403).json({error:'Admin account is inactive'});
    }
    if(!admin.phoneNumberVerified){
      return res.status(403).json({error:'Phone number not verified'});
    }
    const isPasswordCorrect=await bcrypt.compare(password, admin.password);

    if(!isPasswordCorrect){
      await createAuditLog({
        userId:admin._id,
        role:'admin',
        action:'LOGIN_FAILED',
        description:'Admin login failed account invalid password',
        ipAddress:req.ip
      })

      return res.status(401).json({
        message:'Invalid password'
      })
    }
    const hospital=await Hospital.findById(admin.hospitalId);
    if(!hospital){  
      return res.status(404).json({error:'Associated hospital not found'});
    }
    const token=jwt.sign({userId:admin._id, role:'admin', hospitalId:admin.hospitalId}, process.env.JWT_SECRET, {expiresIn:'1d'});

    await createAuditLog({
      userId:admin._id,
        role:'admin',
        action:'LOGIN_SUCCESS',
        description:'Admin loggedin Successfully',
        ipAddress:req.ip
      })
    res.status(200).json({message:'Login successful', token, admin:{
      id:admin._id,
      hospitalName:admin.hospitalName,
      adminName:admin.adminName,
      email:admin.email,
      phoneNumber:admin.phoneNumber,
      hospitalId:hospital._id,
      hospitalName:hospital.hospitalName,
      role:'admin'
    }});
  } catch(error){
    console.error('Admin login error:', error.message);
    res.status(500).json({error:'Internal server error during admin login'});
  }
}

module.exports={adminSignup, generateOTP, verifyOTP, adminLogin};