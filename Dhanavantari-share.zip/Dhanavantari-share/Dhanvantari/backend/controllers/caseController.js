const Case = require("../models/Case");
const Hospital = require("../models/Hospital");

// =====================================================
// CREATE CASE
// =====================================================
const createCase = async (req, res) => {
  try {
    const { patientId, caseData } = req.body;
    const hospital = await Hospital.findById(req.user.hospitalId);

      if (!hospital) {
        return res.status(404).json({
          success: false,
          message: "Hospital not found",
        });
      }

    if (!patientId) {
      return res.status(400).json({
        message: "Patient ID is required",
      });
    }

    if (!caseData) {
      return res.status(400).json({
        message: "Case data is required",
      });
    }

    const newCase = await Case.create({
      patient: patientId,
      doctor: req.user.userId,
      medicalSystem: hospital.medicalSystem,
      templateName: `${hospital.medicalSystem} Case Template`,
      templateVersion: "1.0",
      caseData,
      status: "draft",
    });

    return res.status(201).json({
      success: true,
      message: "Case saved successfully",
      case: newCase,
    });
  } catch (error) {
    console.error("Create Case Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to save case",
      error: error.message,
    });
  }
};


// =====================================================
// GET ALL CASES
// =====================================================
const getAllCases = async (req, res) => {
  try {
   const cases = await Case.find()
      .populate({
        path: "patient",
        match: { hospitalId: req.user.hospitalId },
      })
      .populate("doctor")
      .populate("intern")
      .sort({ createdAt: -1 });

const hospitalCases = cases.filter((caseRecord) => caseRecord.patient);
          

    return res.status(200).json({
      success: true,
      count: hospitalCases.length,
      cases:hospitalCases,
    });
  } catch (error) {
    console.error("Get All Cases Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch cases",
      error: error.message,
    });
  }
};


// =====================================================
// GET SINGLE CASE
// =====================================================
const getCaseById = async (req, res) => {
  try {
    const { id } = req.params;

   const caseRecord = await Case.findById(id)
  .populate({
    path: "patient",
    match: { hospitalId: req.user.hospitalId },
  })
  .populate("doctor")
  .populate("intern");

    if (!caseRecord) {
      return res.status(404).json({
        success: false,
        message: "Case not found",
      });
    }
    if (!caseRecord.patient) {
      return res.status(404).json({
        success: false,
        message: "Case not found",
      });
    }


    return res.status(200).json({
      success: true,
      case: caseRecord,
    });
  } catch (error) {
    console.error("Get Case Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch case",
      error: error.message,
    });
  }
};


// =====================================================
// GET CASES BY PATIENT
// =====================================================
const getCasesByPatient = async (req, res) => {
  try {
    const { patientId } = req.params;

  const cases = await Case.find({ patient: patientId })
  .populate({
    path: "patient",
    match: { hospitalId: req.user.hospitalId },
  })
  .populate("doctor")
  .populate("intern")
  .sort({ createdAt: -1 });

const hospitalCases = cases.filter((caseRecord) => caseRecord.patient);

    return res.status(200).json({
      success: true,
      count: hospitalCases.length,
      cases:hospitalCases,
    });
  } catch (error) {
    console.error("Get Patient Cases Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch patient cases",
      error: error.message,
    });
  }
};


// =====================================================
// UPDATE CASE
// =====================================================
const updateCase = async (req, res) => {
  try {
    const { id } = req.params;
    const { caseData } = req.body;

    if (!caseData) {
      return res.status(400).json({
        success: false,
        message: "Case data is required",
      });
    }
    const caseRecord = await Case.findById(id).populate("patient");

        if (!caseRecord || !caseRecord.patient) {
          return res.status(404).json({
            success: false,
            message: "Case not found",
          });
        }

        if (
          String(caseRecord.patient.hospitalId) !==
          String(req.user.hospitalId)
        ) {
          return res.status(403).json({
            success: false,
            message: "You are not allowed to update this case",
          });
        }

        caseRecord.caseData = caseData;

        const updatedCase = await caseRecord.save();

        await updatedCase.populate("doctor");
        await updatedCase.populate("intern");
      

    // if (!updatedCase) {
    //   return res.status(404).json({
    //     success: false,
    //     message: "Case not found",
    //   });
    // }

    return res.status(200).json({
      success: true,
      message: "Case updated successfully",
      case: updatedCase,
    });
  } catch (error) {
    console.error("Update Case Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to update case",
      error: error.message,
    });
  }
};


// =====================================================
// DELETE CASE
// =====================================================
const deleteCase = async (req, res) => {
  try {
    const { id } = req.params;

    const caseRecord = await Case.findById(id).populate("patient");

      if (!caseRecord || !caseRecord.patient) {
        return res.status(404).json({
          success: false,
          message: "Case not found",
        });
      }

      if (
        String(caseRecord.patient.hospitalId) !==
        String(req.user.hospitalId)
      ) {
        return res.status(403).json({
          success: false,
          message: "You are not allowed to delete this case",
        });
      }

      await Case.findByIdAndDelete(id);

    // if (!deletedCase) {
    //   return res.status(404).json({
    //     success: false,
    //     message: "Case not found",
    //   });
    // }

    return res.status(200).json({
      success: true,
      message: "Case deleted successfully",
    });
  } catch (error) {
    console.error("Delete Case Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to delete case",
      error: error.message,
    });
  }
};


// =====================================================
// EXPORTS
// =====================================================
module.exports = {
  createCase,
  getAllCases,
  getCaseById,
  getCasesByPatient,
  updateCase,
  deleteCase,
};