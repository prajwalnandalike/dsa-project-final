const mongoose = require('mongoose')

const patientSchema = new mongoose.Schema(
  {
    hospitalId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Hospital',
      required: true
    },

    patientName: {
      type: String,
      required: true,
      trim: true
    },

    patientId: {
      type: String,
      required: true,
      trim: true
    },

    email: {
      type: String,
      trim: true,
      lowercase: true
    },
    mobile: {
      type: String,
      required: true,
      trim: true
    },

    dateOfBirth: {
      type: Date
    },
    age:{
      type:Number,
      min:0
    },
    guardian: {
      name:{
        type:String,
        trim:true
      },
      relationship:{
        type:String,
        trim:true
      },
      Mobile: {
      type: String,
      trim: true
    },  
    },
    

    gender: {
      type: String,
      enum: ['male', 'female', 'other', 'prefer_not_to_say']
    },

    address: {
      type: String,
      trim: true
    },
    registrationType:{
      type:String,
      required:true,
      enum:[
        'full_account', 'quick_registration', 'guardian_assisted']
      
    },
    loginEnabled:{
      type:Boolean,
      default:false
    },

    password: {
      type: String
    },

    role: {
      type: String,
      default: 'patient',
      enum: ['patient']
    },
    bloodGroup:{
      type:String,
      trim:true
    },
    abhaNumber:{
      type:String,
      trim:true,
      unique:true,
      sparse:true
    },

    isActive: {
      type: Boolean,
      default: true
    },
    createdBy: {
      userId: {
        type: mongoose.Schema.Types.ObjectId,
        required: true
      },

      role: {
        type: String,
        required: true,
        enum: ['admin', 'doctor', 'intern']
      }
    }
  },
  {
    timestamps: true
  }
)
patientSchema.index({ hospitalId: 1, patientId: 1 }, { unique: true });

module.exports = mongoose.model('Patient', patientSchema)