const mongoose=require('mongoose');
const adminSchema=new mongoose.Schema({
  hospitalId:{
    type:mongoose.Schema.Types.ObjectId,
    ref:'Hospital',
    required:true
  },
  adminName:{
    type:String,
    required:true,
    trim:true,
  },
  email:{
    type:String,
    required:true,
    trim:true,
    unique:true,
    lowercase:true,
  },
  phoneNumber:{
    type:String,
    required:true,
    unique:true,
    trim:true,
  },
  password:{  
    type:String,
    required:true,
  },
  phoneNumberVerified:{
    type:Boolean,
    default:false,  
  },
  isActive:{
    type:Boolean,
    default:true
  }
},
  {
    timestamps:true
  }

);
const Admin=mongoose.model('Admin',adminSchema);
module.exports=Admin;