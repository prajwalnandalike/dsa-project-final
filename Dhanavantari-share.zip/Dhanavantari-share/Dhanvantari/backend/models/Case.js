const mongoose = require("mongoose");

const caseSchema = new mongoose.Schema(
  {
    patient: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Patient",
      required: true,
    },

    doctor: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Doctor",
      required: true,
    },

    intern: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Intern",
      default: null,
    },

    medicalSystem: {
      type: String,
      required: true,
      enum: [
        "Ayurveda",
        "unani",
        "siddha",
        "homeopathy",
        "yoga",
        "naturopathy",
      ],
    },

    templateName: {
      type: String,
      required: true,
      trim: true,
    },

    templateVersion: {
      type: String,
      default: "1.0",
    },

    caseData: {
      type: mongoose.Schema.Types.Mixed,
      default: {},
    },

    diagnosis: {
      type: String,
      trim: true,
      default: "",
    },

    clinicalSummary: {
      type: String,
      trim: true,
      default: "",
    },

    status: {
      type: String,
      enum: [
        "draft",
        "submitted",
        "under_review",
        "reviewed",
        "completed",
      ],
      default: "draft",
    },

    reviewedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Doctor",
      default: null,
    },

    reviewedAt: {
      type: Date,
      default: null,
    },
  },
  {
    timestamps: true,
  }
);

caseSchema.index({ patient: 1, createdAt: -1 });
caseSchema.index({ doctor: 1, createdAt: -1 });
caseSchema.index({ medicalSystem: 1, status: 1 });

module.exports = mongoose.model("Case", caseSchema);