const mongoose=require('mongoose');

const auditLogSchema=new mongoose.Schema({
    userId:{
      type:mongoose.Schema.Types.ObjectId
  },
  role:{
    type:String,
    required:true,
    enum:['admin', 'doctor','intern', 'patient'],
  },
  action:{
    type:String,
    required:true,  
  },
  targetId:{
    type:mongoose.Schema.Types.ObjectId
  },
  description:{
    type:String,
  },
  ipAddress:{
    type:String,
  },

},{ timestamps: true }

);

const AuditLog=mongoose.model('AuditLog', auditLogSchema);
module.exports=AuditLog;
