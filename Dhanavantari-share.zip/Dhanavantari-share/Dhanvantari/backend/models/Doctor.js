const mongoose=require('mongoose');


const doctorSchema=new mongoose.Schema({
  hospitalId:{
    type:mongoose.Schema.Types.ObjectId,
    ref:'Hospital',
    required :true
  },
  doctorName:{
    type:String,
    required:true,
    trim:true
  },
  email:{
    type:String,
    required:true,
  },
  mobile:{
    type:String,
    required:true,
    trim:true
  },
  registrationNumber:{
    type:String,
    required:true,
    trim:true
  },
  qualification:{
    type:String,
    required:true,
  },
  specialization:{
    type:String,
    required:true,
  },
  department:{
    type:String,
    required:true,
  },
  password:{
    type:String,
    required:true,
  },
  role:{
    type:String,
    default:'doctor',
    enum:['doctor' ]
  },
  isActive:{
    type:Boolean,
    default:true
  },
  createdBy:{
    userId:{
      type:mongoose.Schema.Types.ObjectId,
      required:true
    },
    role:{
      type:String,
      required:true,
      enum:['admin']
    }
  }
},
{timestamps:true}

)
module.exports=mongoose.model('Doctor',doctorSchema);