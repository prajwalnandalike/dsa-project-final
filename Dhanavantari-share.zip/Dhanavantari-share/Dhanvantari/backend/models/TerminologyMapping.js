const mongoose = require('mongoose');

const terminologyMappingSchema = new mongoose.Schema({
  namcId: {
    type: String,
    trim:true
  },
  namcCode: {
    type: String,
    trim:true 
  },
  namcTerm:{
    type: String,
    trim:true
  },
  namcTermDiacritical: {
    type: String,
    trim:true
  },
  namcTermDevanagari: {
    type: String,
    trim:true
  },
  icd11Tm2Code: {
    type: String,
    trim:true
  },
  icd11Tm2Multicode: {
  type: String,
  trim: true
},

  longDefinition: {
    type: String,
    trim:true
  },
  ontologyBranches: {
    type: [String],
    trim:true
  },
  namEnglish:{
    type: String,
    trim:true

  },
  nameEnglishIndexRelated:{
    type: String,
    trim:true

  },
  primaryIndexRelated:{
    type: String,
    trim:true
  },
  mappingStatus:{
    type: String,
    enum:['mapped', 'no_direct_match', 'pending'],
    default:'pending'
  }
},
  {timestamps:true}
)
module.exports=mongoose.model('TerminologyMapping', terminologyMappingSchema)