const mongoose=require('mongoose');
const hospitalSchema=new mongoose.Schema({
  hospitalName:{
    type:String,
    required:true,
    trim:true
  },
  hospitalId:{
    type:String,
    required:true,
    unique:true,
    trim:true
  },
    medicalSystem: {
    type: String,
    required: true,
    enum: [
      "Ayurveda",
      "Unani",
      "Siddha",
      "Homeopathy",
      "Yoga",
      "Naturopathy",
    ],
  },
  
  address:{
    type:String,
    required:true,  
  },
  phoneNumber:{
    type:String,  
    required:true
  },
  email:{
    type:String,
    required:true,
    lowercase:true,
  },
  website:{
    type:String,
    trim:true
  },
  activeAdminId:{
    type:mongoose.Schema.Types.ObjectId,
    ref:'Admin',
    default:null
  },
  isActive:{
    type:Boolean,
    default:true
  }
},
  {
    timestamps:true
  }
);
const Hospital=mongoose.model('Hospital',hospitalSchema);
module.exports=Hospital;