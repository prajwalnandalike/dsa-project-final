const mongoose = require('mongoose')

const internSchema = new mongoose.Schema(
  {
    hospitalId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Hospital',
      required: true
    },

    internName: {
      type: String,
      required: true,
      trim: true
    },

    internId: {
      type: String,
      required: true,
      trim: true
    },

    email: {
      type: String,
      required: true,
      trim: true,
      lowercase: true
    },

    mobile: {
      type: String,
      required: true,
      trim: true
    },

    college: {
      type: String,
      trim: true
    },

    course: {
      type: String,
      trim: true
    },

    year: {
      type: String,
      trim: true
    },

    department: {
      type: String,
      trim: true
    },

    joiningDate: {
      type: Date
    },

    supervisorDoctorId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Doctor',
      default: null
    },

    password: {
      type: String,
      required: true
    },

    role: {
      type: String,
      default: 'intern',
      enum: ['intern']
    },

    isActive: {
      type: Boolean,
      default: true
    },

    createdBy: {
      userId: {
        type: mongoose.Schema.Types.ObjectId,
        required: true
      },

      role: {
        type: String,
        required: true,
        enum: ['admin', 'doctor']
      }
    }
  },
  {
    timestamps: true
  }
)

module.exports = mongoose.model('Intern', internSchema);