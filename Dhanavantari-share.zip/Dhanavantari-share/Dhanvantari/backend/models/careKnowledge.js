const mongoose = require('mongoose')

const careKnowledgeSchema = new mongoose.Schema(
  {
    medicalSystem: {
      type: String,
      required: true,
      enum: [
        'Ayurveda',
        'unani',
        'siddha',
        'homeopathy',
        'yoga',
        'naturopathy'
      ]
    },

    namcCode: {
      type: String,
      trim: true
    },

    namcId: {
      type: String,
      trim: true
    },

    diseaseName: {
      type: String,
      required: true,
      trim: true
    },

    patientGroup: {
      type: String,
      trim: true,
      default: null
    },

    dosha: {
      type: String,
      trim: true,
      default: null
    },

    aushadhi: {
      type: String,
      trim: true,
      default: null
    },

    dosage: {
      type: String,
      trim: true,
      default: null
    },

    sevanaKala: {
      type: String,
      trim: true,
      default: null
    },

    pathya: {
      type: String,
      trim: true,
      default: null
    },

    apathya: {
      type: String,
      trim: true,
      default: null
    },

    isApproved: {
      type: Boolean,
      default: false
    },

    isActive: {
      type: Boolean,
      default: true
    }
  },
  {
    timestamps: true
  }
)

module.exports = mongoose.model(
  'CareKnowledge',
  careKnowledgeSchema
)

