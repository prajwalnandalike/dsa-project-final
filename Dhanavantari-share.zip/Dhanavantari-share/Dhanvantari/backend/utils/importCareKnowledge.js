const mongoose = require('mongoose')
const XLSX = require('xlsx')
const path = require('path')
const dotenv = require('dotenv')

const CareKnowledge = require('../models/careKnowledge')

dotenv.config()

const filePath = path.join(
  __dirname,
  '../../data set.xlsx'
)

const importCareKnowledge = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI)

    console.log('MongoDB connected')

    const workbook = XLSX.readFile(filePath)

    const sheet = workbook.Sheets['Sheet1']

    if (!sheet) {
      throw new Error('Sheet1 not found')
    }

    const rows = XLSX.utils.sheet_to_json(sheet, {
      defval: ''
    })

    const data = rows.map((row) => {
      return {
        medicalSystem: String(
          row['Medical_System'] || ''
        ).trim().toLowerCase(),

        namcCode: String(
          row['NAMC_CODE'] || ''
        ).trim(),

        namcId: String(
          row['NAMC_ID'] || ''
        ).trim(),

        diseaseName: String(
          row['Disease_Name'] || ''
        ).trim(),

        patientGroup: String(
          row['Patient_Group'] || ''
        ).trim() || null,

        dosha: String(
          row['Dosha'] || ''
        ).trim() || null,

        // Aushadhi is intentionally NOT imported.
        // Doctor will enter it manually.
        aushadhi: null,

        dosage: String(
          row['Dosage'] || ''
        ).trim() || null,

        sevanaKala: String(
          row['Sevana_Kala'] || ''
        ).trim() || null,

        pathya: String(
          row['Pathya'] || ''
        ).trim() || null,

        apathya: String(
          row['Apathya'] || ''
        ).trim() || null,

        isApproved: false,
        isActive: true
      }
    })

    await CareKnowledge.deleteMany({})

    await CareKnowledge.insertMany(data)

    console.log(
      `${data.length} care knowledge records imported`
    )

    await mongoose.connection.close()

    console.log('Care knowledge import completed successfully')
  } catch (error) {
    console.error(
      'Care knowledge import failed:',
      error.message
    )

    process.exit(1)
  }
}

importCareKnowledge()