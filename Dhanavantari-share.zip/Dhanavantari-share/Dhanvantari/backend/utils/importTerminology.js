const mongoose=require('mongoose');
const XLSX=require('xlsx');
const path=require('path');
const dotenv=require('dotenv')

const TerminologyMapping=require('../models/TerminologyMapping');

dotenv.config();
const filePath=path.join(__dirname,'../../SSI_Ayurveda_Diseases_NAMC_Matched.xlsm');

const importTerminology=async()=>{
  try{
    await mongoose.connect(process.env.MONGO_URI)
    console.log('Mongodb connected');
    const workBook=XLSX.readFile(filePath);
    const sheet=workBook.Sheets['Matched NAMC A-L']

    if(!sheet){
      throw new Error('Matched NAMC A-L not found');
    }
    const rows=XLSX.utils.sheet_to_json(sheet, {defval:''})
    const data=rows.map((row)=>{
      const icdCode=String(row['ICD-11 TM2 Code (XLOOKUP)']||'').trim()

      let mappingStatus='pending';
      if(icdCode){
        mappingStatus='mapped'
      }
      if(icdCode.toLowerCase().includes('no direct match')){
        mappingStatus='no_direct_match'
      }
      return {
        namcId:String(row['NAMC_ID']||'').trim(),
        namcCode:String(row['NAMC_CODE']||'').trim(),
        namcTerm:String(row['NAMC_term']||'').trim(),
        namcTermDiacritical:String(row['NAMC_Term_diacritical']||'').trim(),
        namcTermDevanagari:String(row['NAMC_Term_DEVANAGARI']||'').trim(),
        icd11Tm2Code:icdCode||null,
        icd11Tm2Multicode: String(
          row['ICD-11 TM2 Multicode (XLOOKUP)'] || ''
        ).trim(),
        longDefinition:String(row['Long_definition']||'').trim(),
        ontologyBranches:String(row['Ontology_branches']||'').trim()? String(row['Ontology_branches']).split(',').map(item => item.trim())
  : [],
        namEnglish:String(row['Name English']||'').trim(),
        namEnglishIndexRelated:String(row['Name English Under Index']||'').trim(),
        primaryIndexRelated:String(row['Primary Index Related']||'').trim(),
        mappingStatus

      }
    })
    await TerminologyMapping.deleteMany({})
    await TerminologyMapping.insertMany(data)
    console.log(`${data.length} terminology records imported`)

    await mongoose.connection.close();
    console.log('Import completed successfully')
  }catch(error){
    console.log('import failed', error.message)
    process.exit(1)
  }
}
importTerminology()