const express=require('express');
const app=express();
const cors=require('cors');
const dotenv=require('dotenv');
dotenv.config();
// const mongoose=require('mongoose');
const connectDB=require('./config/db');
connectDB();
app.use(cors());
app.use(express.json());

const adminRoutes=require('./routes/adminRoutes');
app.use('/api/admin', adminRoutes);

const patientRoutes=require('./routes/patientRoutes');
app.use('/api/patients', patientRoutes)

const doctorRoutes=require('./routes/doctorRoutes')
app.use('/api/doctors', doctorRoutes)

const internroutes=require('./routes/internRoutes')
app.use('/api/interns', internroutes)


const careKnowledgeRoutes=require('./routes/careKnowledgeRoutes')
app.use('/api/care', careKnowledgeRoutes)

const caseRotes=require('./routes/caseRoutes')
app.use('/api/cases', caseRotes)

const auditRoutes=require("./routes/auditRoutes")
app.use("/api/audit", auditRoutes)

const terminologyMappingRoutes = require("./routes/terminologyMappingRoutes");
app.use("/api/terminology-mapping", terminologyMappingRoutes);

const aiRoutes = require("./routes/aiRoutes");
app.use("/api/ai", aiRoutes);

app.get("/api/test", (req, res)=>{
  res.json({message:"API is working fine!"});

});

const PORT= process.env.PORT ||5000;
app.listen(PORT, ()=>{
  console.log(`Backend is running on port http://localhost:${PORT}`);
});