import React, { useState } from "react";

const initialData = {
  generalAppearance: "",
  consciousness: "",
  orientation: "",
  built: "",
  nourishment: "",
  posture: "",
  gait: "",
  pallor: "",
  icterus: "",
  cyanosis: "",
  clubbing: "",
  lymphNodes: "",
  edema: "",
  temperature: "",
  pulse: "",
  respiratoryRate: "",
  bloodPressure: "",
  spo2: "",
  height: "",
  weight: "",
  bmi: "",
  skin: "",
  hair: "",
  nails: "",
  voice: "",
  facialExpression: "",
  otherObservations: "",
};

const examinationGroups = [
  {
    title: "General Appearance",
    fields: [
      {
        key: "generalAppearance",
        label: "General Appearance",
        type: "select",
        options: [
          "Healthy",
          "Ill-looking",
          "Moderately built",
          "Poorly built",
          "Well nourished",
          "Poorly nourished",
        ],
      },
      {
        key: "consciousness",
        label: "Level of Consciousness",
        type: "select",
        options: [
          "Conscious",
          "Drowsy",
          "Confused",
          "Stuporous",
          "Unconscious",
        ],
      },
      {
        key: "orientation",
        label: "Orientation",
        type: "select",
        options: [
          "Oriented to time, place and person",
          "Disoriented",
          "Partially oriented",
        ],
      },
      {
        key: "built",
        label: "Built",
        type: "select",
        options: [
          "Well built",
          "Moderately built",
          "Poorly built",
        ],
      },
      {
        key: "nourishment",
        label: "Nourishment",
        type: "select",
        options: [
          "Well nourished",
          "Moderately nourished",
          "Poorly nourished",
        ],
      },
      {
        key: "posture",
        label: "Posture",
        type: "select",
        options: [
          "Normal",
          "Active",
          "Restless",
          "Lethargic",
          "Abnormal",
        ],
      },
      {
        key: "gait",
        label: "Gait",
        type: "select",
        options: [
          "Normal",
          "Antalgic",
          "Ataxic",
          "Unsteady",
          "Abnormal",
        ],
      },
    ],
  },

  {
    title: "General Clinical Signs",
    fields: [
      {
        key: "pallor",
        label: "Pallor",
        type: "select",
        options: ["Absent", "Present"],
      },
      {
        key: "icterus",
        label: "Icterus",
        type: "select",
        options: ["Absent", "Present"],
      },
      {
        key: "cyanosis",
        label: "Cyanosis",
        type: "select",
        options: ["Absent", "Present"],
      },
      {
        key: "clubbing",
        label: "Clubbing",
        type: "select",
        options: ["Absent", "Present"],
      },
      {
        key: "lymphNodes",
        label: "Lymph Nodes",
        type: "select",
        options: [
          "Not palpable",
          "Palpable",
          "Tender",
          "Non-tender",
        ],
      },
      {
        key: "edema",
        label: "Edema",
        type: "select",
        options: [
          "Absent",
          "Present",
          "Pitting",
          "Non-pitting",
        ],
      },
    ],
  },

  {
    title: "Vital Signs",
    fields: [
      {
        key: "temperature",
        label: "Temperature",
        type: "number",
        placeholder: "°F",
      },
      {
        key: "pulse",
        label: "Pulse Rate",
        type: "number",
        placeholder: "beats/min",
      },
      {
        key: "respiratoryRate",
        label: "Respiratory Rate",
        type: "number",
        placeholder: "breaths/min",
      },
      {
        key: "bloodPressure",
        label: "Blood Pressure",
        type: "text",
        placeholder: "e.g. 120/80 mmHg",
      },
      {
        key: "spo2",
        label: "SpO₂",
        type: "number",
        placeholder: "%",
      },
    ],
  },

  {
    title: "Anthropometry",
    fields: [
      {
        key: "height",
        label: "Height",
        type: "number",
        placeholder: "cm",
      },
      {
        key: "weight",
        label: "Weight",
        type: "number",
        placeholder: "kg",
      },
      {
        key: "bmi",
        label: "BMI",
        type: "number",
        placeholder: "kg/m²",
      },
    ],
  },

  {
    title: "External Examination",
    fields: [
      {
        key: "skin",
        label: "Skin",
        type: "select",
        options: [
          "Normal",
          "Dry",
          "Oily",
          "Pale",
          "Yellowish",
          "Reddish",
          "Pigmented",
          "Other",
        ],
      },
      {
        key: "hair",
        label: "Hair",
        type: "select",
        options: [
          "Normal",
          "Dry",
          "Oily",
          "Brittle",
          "Thin",
          "Coarse",
          "Hair loss",
        ],
      },
      {
        key: "nails",
        label: "Nails",
        type: "select",
        options: [
          "Normal",
          "Pale",
          "Brittle",
          "Discolored",
          "Clubbing",
        ],
      },
      {
        key: "voice",
        label: "Voice",
        type: "select",
        options: [
          "Normal",
          "Hoarse",
          "Weak",
          "Harsh",
          "Low",
          "Loud",
        ],
      },
      {
        key: "facialExpression",
        label: "Facial Expression",
        type: "select",
        options: [
          "Normal",
          "Painful",
          "Anxious",
          "Depressed",
          "Restless",
          "Other",
        ],
      },
    ],
  },
];

function GeneralExaminationSection({ data = {}, onChange }) {
  const [formData, setFormData] = useState({
    ...initialData,
    ...data,
  });

  const handleChange = (key, value) => {
    const updatedData = {
      ...formData,
      [key]: value,
    };

    setFormData(updatedData);

    if (onChange) {
      onChange(updatedData);
    }
  };

  const calculateBMI = () => {
    const weight = Number(formData.weight);
    const height = Number(formData.height);

    if (!weight || !height) {
      return;
    }

    const heightInMeters = height / 100;
    const bmi = weight / (heightInMeters * heightInMeters);

    handleChange("bmi", bmi.toFixed(2));
  };

  const resetAll = () => {
    setFormData(initialData);

    if (onChange) {
      onChange(initialData);
    }
  };
const saveData = () => {
  const assessment = {
    generalAppearance: formData.generalAppearance || "Not assessed",
    consciousness: formData.consciousness || "Not assessed",
    orientation: formData.orientation || "Not assessed",
    built: formData.built || "Not assessed",
    nourishment: formData.nourishment || "Not assessed",
    posture: formData.posture || "Not assessed",
    gait: formData.gait || "Not assessed",
    pallor: formData.pallor || "Not assessed",
    icterus: formData.icterus || "Not assessed",
    cyanosis: formData.cyanosis || "Not assessed",
    clubbing: formData.clubbing || "Not assessed",
    edema: formData.edema || "Not assessed",
    temperature: formData.temperature || "",
    pulse: formData.pulse || "",
    respiratoryRate: formData.respiratoryRate || "",
    bloodPressure: formData.bloodPressure || "",
    spo2: formData.spo2 || "",
    height: formData.height || "",
    weight: formData.weight || "",
    bmi: formData.bmi || "",
    skin: formData.skin || "Not assessed",
    hair: formData.hair || "Not assessed",
    nails: formData.nails || "Not assessed",
    voice: formData.voice || "Not assessed",
    facialExpression: formData.facialExpression || "Not assessed",
    otherObservations: formData.otherObservations || "",
    assessedFields,
    totalFields,
  };

  const updatedData = {
    ...formData,
    assessment,
  };

  setFormData(updatedData);

  if (onChange) {
    onChange(updatedData);
  }

  alert("General Examination assessment saved successfully.");
};
  

  const assessedFields = Object.keys(initialData).filter(
    (key) =>
      formData[key] !== undefined &&
      formData[key] !== null &&
      formData[key] !== ""
  ).length;

  const totalFields = Object.keys(initialData).length;

  return (
    <div className="w-full bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">

      {/* HEADER */}
      <div className="px-6 py-5 bg-gradient-to-r from-emerald-50 to-blue-50 border-b">

        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">

          <div>
            <h2 className="text-2xl font-bold text-slate-800">
              General Examination
            </h2>

            <p className="text-sm text-slate-600 mt-1">
              General physical examination and baseline clinical observations
            </p>
          </div>

          <div className="bg-white rounded-xl px-4 py-3 border border-emerald-100">

            <p className="text-xs text-slate-500">
              Assessment Progress
            </p>

            <p className="text-lg font-bold text-emerald-700">
              {assessedFields} / {totalFields}
            </p>

          </div>

        </div>
      </div>

      {/* CONTENT */}
      <div className="p-5">

        <div className="grid grid-cols-1 xl:grid-cols-[1fr_300px] gap-5">

          {/* LEFT SIDE */}
          <div className="space-y-5">

            {examinationGroups.map((group) => (

              <div
                key={group.title}
                className="border border-slate-200 rounded-xl overflow-hidden"
              >

                {/* GROUP HEADER */}
                <div className="px-5 py-3 bg-slate-50 border-b">

                  <h3 className="font-bold text-slate-800">
                    {group.title}
                  </h3>

                </div>

                {/* FIELDS */}
                <div className="p-5 grid grid-cols-1 md:grid-cols-2 gap-5">

                  {group.fields.map((field) => (

                    <div key={field.key}>

                      <label className="block text-sm font-semibold text-slate-700 mb-2">
                        {field.label}
                      </label>

                      {field.type === "select" ? (

                        <select
                          value={formData[field.key]}
                          onChange={(e) =>
                            handleChange(
                              field.key,
                              e.target.value
                            )
                          }
                          className="w-full border border-slate-300 rounded-lg px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-emerald-300"
                        >

                          <option value="">
                            Select
                          </option>

                          {field.options.map((option) => (

                            <option
                              key={option}
                              value={option}
                            >
                              {option}
                            </option>

                          ))}

                        </select>

                      ) : (

                        <div className="relative">

                          <input
                            type={field.type}
                            value={formData[field.key]}
                            onChange={(e) =>
                              handleChange(
                                field.key,
                                e.target.value
                              )
                            }
                            placeholder={field.placeholder || ""}
                            className="w-full border border-slate-300 rounded-lg px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-emerald-300"
                          />

                        </div>

                      )}

                    </div>

                  ))}

                  {/* BMI CALCULATION */}
                  {group.title === "Anthropometry" && (
                    <div className="md:col-span-2 flex items-center justify-end">

                      <button
                        type="button"
                        onClick={calculateBMI}
                        className="px-4 py-2 rounded-lg bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700"
                      >
                        Calculate BMI
                      </button>

                    </div>
                  )}

                </div>

              </div>

            ))}

            {/* OTHER OBSERVATIONS */}
            <div className="border border-slate-200 rounded-xl overflow-hidden">

              <div className="px-5 py-3 bg-slate-50 border-b">

                <h3 className="font-bold text-slate-800">
                  Other Observations
                </h3>

              </div>

              <div className="p-5">

                <textarea
                  rows="5"
                  value={formData.otherObservations}
                  onChange={(e) =>
                    handleChange(
                      "otherObservations",
                      e.target.value
                    )
                  }
                  placeholder="Enter any additional general examination findings..."
                  className="w-full border border-slate-300 rounded-lg px-3 py-3 text-sm outline-none focus:ring-2 focus:ring-emerald-300"
                />

              </div>

            </div>

          </div>

          {/* RIGHT SIDE */}
          <div className="space-y-4">

            {/* SUMMARY */}
            <div className="border rounded-xl overflow-hidden">

              <div className="px-4 py-3 bg-blue-50 border-b">

                <h3 className="font-bold text-blue-800">
                  Examination Summary
                </h3>

              </div>

              <div className="p-3 space-y-2">

                {[
                  ["General Appearance", "generalAppearance"],
                  ["Consciousness", "consciousness"],
                  ["Orientation", "orientation"],
                  ["Built", "built"],
                  ["Nourishment", "nourishment"],
                  ["Posture", "posture"],
                  ["Gait", "gait"],
                  ["Pallor", "pallor"],
                  ["Icterus", "icterus"],
                  ["Cyanosis", "cyanosis"],
                  ["Clubbing", "clubbing"],
                  ["Edema", "edema"],
                ].map(([label, key]) => (

                  <div
                    key={key}
                    className="flex items-center justify-between gap-3 border rounded-lg px-3 py-2.5"
                  >

                    <span className="text-sm font-medium text-slate-700">
                      {label}
                    </span>

                    <span className="text-xs text-right text-slate-500">
                      {formData[key] || "Not assessed"}
                    </span>

                  </div>

                ))}

              </div>

            </div>

            {/* VITALS CARD */}
            <div className="border rounded-xl bg-emerald-50 border-emerald-200 p-4">

              <h3 className="font-bold text-emerald-800 mb-3">
                Vital Signs
              </h3>

              <div className="space-y-3">

                <div className="flex justify-between">
                  <span className="text-sm text-slate-600">
                    Temperature
                  </span>

                  <span className="font-semibold text-slate-800">
                    {formData.temperature
                      ? `${formData.temperature} °F`
                      : "--"}
                  </span>
                </div>

                <div className="flex justify-between">
                  <span className="text-sm text-slate-600">
                    Pulse
                  </span>

                  <span className="font-semibold text-slate-800">
                    {formData.pulse
                      ? `${formData.pulse} /min`
                      : "--"}
                  </span>
                </div>

                <div className="flex justify-between">
                  <span className="text-sm text-slate-600">
                    Respiratory Rate
                  </span>

                  <span className="font-semibold text-slate-800">
                    {formData.respiratoryRate
                      ? `${formData.respiratoryRate} /min`
                      : "--"}
                  </span>
                </div>

                <div className="flex justify-between">
                  <span className="text-sm text-slate-600">
                    Blood Pressure
                  </span>

                  <span className="font-semibold text-slate-800">
                    {formData.bloodPressure || "--"}
                  </span>
                </div>

                <div className="flex justify-between">
                  <span className="text-sm text-slate-600">
                    SpO₂
                  </span>

                  <span className="font-semibold text-slate-800">
                    {formData.spo2
                      ? `${formData.spo2}%`
                      : "--"}
                  </span>
                </div>

              </div>

            </div>

            {/* ANTHROPOMETRY */}
            <div className="border rounded-xl bg-amber-50 border-amber-200 p-4">

              <h3 className="font-bold text-amber-800 mb-3">
                Anthropometry
              </h3>

              <div className="space-y-3">

                <div className="flex justify-between">
                  <span className="text-sm text-slate-600">
                    Height
                  </span>

                  <span className="font-semibold">
                    {formData.height
                      ? `${formData.height} cm`
                      : "--"}
                  </span>
                </div>

                <div className="flex justify-between">
                  <span className="text-sm text-slate-600">
                    Weight
                  </span>

                  <span className="font-semibold">
                    {formData.weight
                      ? `${formData.weight} kg`
                      : "--"}
                  </span>
                </div>

                <div className="flex justify-between">
                  <span className="text-sm text-slate-600">
                    BMI
                  </span>

                  <span className="font-semibold">
                    {formData.bmi || "--"}
                  </span>
                </div>

              </div>

            </div>

            {/* NOTE */}
            <div className="border rounded-xl bg-blue-50 border-blue-200 p-4">

              <h3 className="font-bold text-blue-800 mb-2">
                Clinical Note
              </h3>

              <p className="text-sm text-slate-600 leading-6">
                Record the patient's general physical condition,
                vital signs and relevant external findings.
              </p>

            </div>

          </div>

        </div>

        {/* BUTTONS */}
        <div className="flex flex-col sm:flex-row justify-between gap-3 mt-6">

          <button
            type="button"
            onClick={resetAll}
            className="px-6 py-3 border border-slate-300 rounded-xl font-semibold text-slate-700 hover:bg-slate-50"
          >
            ↻ Reset All
          </button>

          <button
            type="button"
            onClick={saveData}
            className="px-7 py-3 rounded-xl font-semibold text-white bg-emerald-600 hover:bg-emerald-700"
          >
            ✓ Save General Examination
          </button>

        </div>

      </div>
    </div>
  );
}

export default GeneralExaminationSection;