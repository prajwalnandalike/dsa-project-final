import React, { useState } from "react";

const DietLifestyleSection = ({ data = {}, onChange }) => {
  const [form, setForm] = useState(data);

  const update = (key, value) => {
    const updated = { ...form, [key]: value };
    setForm(updated);
    onChange?.(updated);
  };

  return (
    <section className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
      <div className="mb-6 flex items-center gap-4">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-100 font-bold text-emerald-700">
          07
        </div>

        <div>
          <h2 className="text-xl font-bold text-slate-800">
            Diet & Lifestyle
          </h2>
          <p className="text-sm text-slate-500">
            Record the patient's usual diet and lifestyle pattern.
          </p>
        </div>
      </div>

      <div className="grid gap-5 md:grid-cols-2">

        <Select
          label="Diet Type"
          value={form.dietType}
          onChange={(v) => update("dietType", v)}
          options={["Vegetarian", "Non-Vegetarian", "Mixed"]}
        />

        <Select
          label="Appetite"
          value={form.appetite}
          onChange={(v) => update("appetite", v)}
          options={["Normal", "Increased", "Decreased", "Variable"]}
        />

        <Select
          label="Meal Frequency"
          value={form.mealFrequency}
          onChange={(v) => update("mealFrequency", v)}
          options={["1 meal/day", "2 meals/day", "3 meals/day", "More than 3", "Irregular"]}
        />

        <Select
          label="Water Intake"
          value={form.waterIntake}
          onChange={(v) => update("waterIntake", v)}
          options={["< 1 L/day", "1–2 L/day", "2–3 L/day", "> 3 L/day"]}
        />

        <Input
          label="Food Preferences"
          value={form.foodPreferences}
          onChange={(v) => update("foodPreferences", v)}
          placeholder="e.g. spicy, sweet, salty"
        />

        <Input
          label="Food Intolerances"
          value={form.foodIntolerances}
          onChange={(v) => update("foodIntolerances", v)}
          placeholder="Mention if any"
        />

        <Select
          label="Daily Physical Activity"
          value={form.physicalActivity}
          onChange={(v) => update("physicalActivity", v)}
          options={["Sedentary", "Light", "Moderate", "Heavy"]}
        />

        <Select
          label="Stress Level"
          value={form.stress}
          onChange={(v) => update("stress", v)}
          options={["Low", "Moderate", "High", "Variable"]}
        />

        <Select
          label="Sleep Quality"
          value={form.sleepQuality}
          onChange={(v) => update("sleepQuality", v)}
          options={["Good", "Average", "Poor"]}
        />

        <Select
          label="Screen Time"
          value={form.screenTime}
          onChange={(v) => update("screenTime", v)}
          options={[
            "< 2 hours/day",
            "2–4 hours/day",
            "4–6 hours/day",
            "> 6 hours/day",
          ]}
        />

        <div className="md:col-span-2">
          <label className="mb-2 block text-sm font-semibold text-slate-600">
            Daily Routine
          </label>

          <textarea
            value={form.dailyRoutine || ""}
            onChange={(e) => update("dailyRoutine", e.target.value)}
            placeholder="Briefly describe the patient's daily routine..."
            rows={4}
            className="w-full resize-none rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100"
          />
        </div>

      </div>
    </section>
  );
};

const Select = ({ label, value, onChange, options }) => (
  <div>
    <label className="mb-2 block text-sm font-semibold text-slate-600">
      {label}
    </label>

    <select
      value={value || ""}
      onChange={(e) => onChange(e.target.value)}
      className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100"
    >
      <option value="">Select {label}</option>

      {options.map((option) => (
        <option key={option} value={option}>
          {option}
        </option>
      ))}
    </select>
  </div>
);

const Input = ({ label, value, onChange, placeholder }) => (
  <div>
    <label className="mb-2 block text-sm font-semibold text-slate-600">
      {label}
    </label>

    <input
      type="text"
      value={value || ""}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="w-full rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100"
    />
  </div>
);

export default DietLifestyleSection;