import React, { useState } from "react";

import CommonPatientSection from "./commonPatientSection";
import ChiefComplaintSection from "./chiefComplaintSection";
import HistoryPresentIllnessSection from "./HistoryPresentIllnessSection";
import PastHistorySection from "./PastHistorySection";
import FamilyHistorySection from "./FamilyHistorySection";
import PersonalHistorySection from "./PersonalHistorySection";
import PrakruthiSection from "./PrakruthiSection";
import InvestigationsSection from "./InvestigationsSection";
import VikruthiSection from "./VikruthiSection";
import DietLifestyleSection from "./DietLifeStyleSection";
import DashavidhaParikshaSection from "./DashvidhaParikshaSection";
import AshtasthanaParikshaSection from "./AshtasthanaParikshaSection";
import GeneralExaminationSection from "./GeneralExaminationSection";
import SystemicExaminationSection from "./SystemicExaminationSection";
import AyurvedicDiagnosisSection from "./AyurvedicDiagnosisSection";
import DoshaDhatuMalaSection from "./DoshaDhatuMalaSection";
import AgniAmaSection from "./AgniAmaSection";

const CaseTaking = () => {
  const patient = JSON.parse(
    localStorage.getItem("selectedPatient") || "{}"
  );

  const [activeSection, setActiveSection] = useState(1);

  const [caseData, setCaseData] = useState({});

  const handleSaveCase = async () => {
  try {
    const token = localStorage.getItem("token");

    const response = await fetch("/api/cases", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        patientId: patient._id,
        caseData,
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || "Failed to save case");
    }

    alert("Case saved successfully!");
    console.log("Saved case:", data);
  } catch (error) {
    console.error(error);
    alert(error.message || "Unable to save case");
  }
};

  const updateSection = (sectionKey, value) => {
    setCaseData((previous) => ({
      ...previous,
      [sectionKey]: value,
    }));
  };

  const sections = [
  { number: 1, key: "patient", title: "Patient" },
  { number: 2, key: "chiefComplaint", title: "Chief Complaint" },
  {
    number: 3,
    key: "historyPresentIllness",
    title: "History of Present Illness",
  },
  { number: 4, key: "pastHistory", title: "Past History" },
  { number: 5, key: "familyHistory", title: "Family History" },
  { number: 6, key: "personalHistory", title: "Personal History" },
  { number: 7, key: "dietLifestyle", title: "Diet & Lifestyle" },
  { number: 8, key: "prakruthi", title: "Prakruthi" },
  { number: 9, key: "vikruthi", title: "Vikruthi" },

  {
    number: 10,
    key: "doshaDhatuMala",
    title: "Dosha, Dhatu & Mala",
  },

  {
    number: 11,
    key: "agniAma",
    title: "Agni & Ama",
  },

  {
    number: 12,
    key: "dashavidhaPariksha",
    title: "Dashavidha Pariksha",
  },
  {
    number: 13,
    key: "ashtasthanaPariksha",
    title: "Ashtasthana Pariksha",
  },
  {
    number: 14,
    key: "generalExamination",
    title: "General Examination",
  },
  {
    number: 15,
    key: "systemicExamination",
    title: "Systemic Examination",
  },
  {
    number: 16,
    key: "investigations",
    title: "Investigations",
  },
  {
    number: 17,
    key: "ayurvedicDiagnosis",
    title: "Ayurvedic Diagnosis",
  },
];

  const renderSection = () => {
    switch (activeSection) {
      case 1:
        return (
          <CommonPatientSection
            patient={patient}
          />
        );

      case 2:
        return (
          <ChiefComplaintSection
            data={caseData.chiefComplaint || []}
            onChange={(value) =>
              updateSection("chiefComplaint", value)
            }
          />
        );

      case 3:
        return (
          <HistoryPresentIllnessSection
            data={caseData.historyPresentIllness || {}}
            onChange={(value) =>
              updateSection("historyPresentIllness", value)
            }
          />
        );

      case 4:
        return (
          <PastHistorySection
            data={caseData.pastHistory || {}}
            onChange={(value) =>
              updateSection("pastHistory", value)
            }
          />
        );

      case 5:
        return (
          <FamilyHistorySection
            data={caseData.familyHistory || {}}
            onChange={(value) =>
              updateSection("familyHistory", value)
            }
          />
        );

      case 6:
        return (
          <PersonalHistorySection
            data={caseData.personalHistory || {}}
            onChange={(value) =>
              updateSection("personalHistory", value)
            }
          />
        );

        case 7:
  return (
    <DietLifestyleSection
      data={caseData.dietLifestyle || {}}
      onChange={(value) =>
        updateSection("dietLifestyle", value)
      }
    />
  );

      case 8:
        return (
          <PrakruthiSection
            data={caseData.prakruthi || {}}
            onChange={(value) =>
              updateSection("prakruthi", value)
            }
          />
        );
        case 9:
  return (
    <VikruthiSection
      data={caseData.vikruthi || {}}
      onChange={(value) =>
        updateSection("vikruthi", value)
      }
    />
  );
    case 10:
  return (
    <DoshaDhatuMalaSection
      data={caseData.doshaDhatuMala || {}}
      onChange={(value) =>
        updateSection("doshaDhatuMala", value)
      }
    />
  );

case 11:
  return (
    <AgniAmaSection
      data={caseData.agniAma || {}}
      onChange={(value) =>
        updateSection("agniAma", value)
      }
    />
  );

      case 12:
  return (
    <DashavidhaParikshaSection
      data={caseData.dashavidhaPariksha || {}}
      onChange={(value) =>
        updateSection("dashavidhaPariksha", value)
      }
    />
  );
      case 13:
  return (
    <AshtasthanaParikshaSection
      data={caseData.ashtasthanaPariksha}
      onChange={(data) =>
        setCaseData((prev) => ({
          ...prev,
          ashtasthanaPariksha: data,
        }))
      }
    />
  );
      case 14:
  return (
    <GeneralExaminationSection
      data={caseData.generalExamination}
      onChange={(data) =>
        setCaseData((prev) => ({
          ...prev,
          generalExamination: data,
        }))
      }
    />
  );
       case 15:
  return (
    <SystemicExaminationSection
      data={caseData.systemicExamination}
      onChange={(data) =>
        setCaseData((prev) => ({
          ...prev,
          systemicExamination: data,
        }))
      }
    />
  );

      case 16:
        return (
          <InvestigationsSection
            data={caseData.investigations || []}
            onChange={(value) =>
              updateSection("investigations", value)
            }
          />
        );

        case 17:
  return (
    <AyurvedicDiagnosisSection
      data={caseData}
      onChange={(data) =>
        setCaseData((prev) => ({
          ...prev,
          ayurvedicDiagnosis: data.ayurvedicDiagnosis ||{},
        }))
      }
    />
  );

      default:
        return (
          <SectionComingSoon
            number={activeSection}
            title={
              sections.find(
                (section) => section.number === activeSection
              )?.title
            }
          />
        );
    }
  };

  const currentIndex = sections.findIndex(
    (section) => section.number === activeSection
  );

  const goPrevious = () => {
    if (currentIndex > 0) {
      setActiveSection(
        sections[currentIndex - 1].number
      );
    }
  };

  const goNext = () => {
    if (currentIndex < sections.length - 1) {
      setActiveSection(
        sections[currentIndex + 1].number
      );
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">

      {/* ================= HEADER ================= */}
      <header className="sticky top-0 z-30 bg-gradient-to-r from-emerald-700 via-emerald-600 to-cyan-600 px-4 py-4 text-white shadow-lg sm:px-6">

        <div className="mx-auto flex max-w-7xl items-center justify-between">

          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-emerald-100">
              BAMS Doctor / Intern Portal
            </p>

            <h1 className="mt-1 text-xl font-bold sm:text-2xl">
              Ayurveda Case Taking
            </h1>
          </div>

          <div className="hidden rounded-xl bg-white/10 px-4 py-2 text-right backdrop-blur sm:block">
            <p className="text-xs text-emerald-100">
              Medical System
            </p>

            <p className="font-bold">
              Ayurveda
            </p>
          </div>

        </div>

      </header>

      {/* ================= MAIN ================= */}
      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6">

        {/* Patient mini header */}
        <div className="mb-6 rounded-2xl bg-white p-5 shadow-sm ring-1 ring-slate-200">

          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">

            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Current Patient
              </p>

              <h2 className="mt-1 text-lg font-bold text-slate-800">
                {patient.patientName || "Patient not selected"}
              </h2>

              <p className="text-sm text-slate-500">
                Patient ID: {patient.patientId || "—"}
              </p>
            </div>

            <div className="rounded-xl bg-emerald-50 px-4 py-3">
              <p className="text-xs text-emerald-600">
                Current Section
              </p>

              <p className="font-bold text-emerald-700">
                {String(activeSection).padStart(2, "0")} / 17
              </p>
            </div>

          </div>

        </div>

        <div className="grid gap-6 lg:grid-cols-[280px_1fr]">

          {/* ================= SIDEBAR ================= */}
          <aside className="h-fit rounded-2xl bg-white p-3 shadow-sm ring-1 ring-slate-200 lg:sticky lg:top-24">

            <div className="mb-3 px-3 py-2">
              <p className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Case Sections
              </p>
            </div>

            <div className="max-h-[70vh] space-y-1 overflow-y-auto">

              {sections.map((section) => {

                const active =
                  activeSection === section.number;

                return (
                  <button
                    key={section.number}
                    type="button"
                    onClick={() =>
                      setActiveSection(section.number)
                    }
                    className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left transition ${
                      active
                        ? "bg-emerald-600 text-white shadow-md"
                        : "text-slate-600 hover:bg-emerald-50 hover:text-emerald-700"
                    }`}
                  >

                    <span
                      className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-xs font-bold ${
                        active
                          ? "bg-white/20 text-white"
                          : "bg-slate-100 text-slate-500"
                      }`}
                    >
                      {String(section.number).padStart(2, "0")}
                    </span>

                    <span className="text-sm font-semibold">
                      {section.title}
                    </span>

                  </button>
                );

              })}

            </div>

          </aside>

          {/* ================= CONTENT ================= */}
          <div>

            {renderSection()}

            {/* Navigation */}
            <div className="mt-6 flex items-center justify-between gap-3">

              <button
                type="button"
                onClick={goPrevious}
                disabled={currentIndex === 0}
                className="rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-bold text-slate-600 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-40"
              >
                ← Previous
              </button>

            <button
              type="button"
              onClick={handleSaveCase}
              className="rounded-xl border border-emerald-600 bg-emerald-50 px-5 py-3 text-sm font-bold text-emerald-700 transition hover:bg-emerald-100"
            >
              Save Case
            </button>

              <p className="hidden text-sm text-slate-400 sm:block">
                Section {activeSection} of 17
              </p>

              <button
                type="button"
                onClick={goNext}
                disabled={currentIndex === sections.length - 1}
                className="rounded-xl bg-gradient-to-r from-emerald-600 to-cyan-600 px-5 py-3 text-sm font-bold text-white shadow-md transition hover:-translate-y-0.5 hover:shadow-lg disabled:cursor-not-allowed disabled:opacity-40"
              >
                Next →
              </button>

            </div>

          </div>

        </div>

      </main>

    </div>
  );
};


/* ================= TEMPORARY PLACEHOLDER ================= */

const SectionComingSoon = ({ number, title }) => {
  return (
    <section className="flex min-h-[400px] items-center justify-center rounded-2xl bg-white p-8 text-center shadow-sm ring-1 ring-slate-200">

      <div>

        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-50 text-xl font-bold text-emerald-600">
          {String(number).padStart(2, "0")}
        </div>

        <h2 className="mt-5 text-2xl font-bold text-slate-800">
          {title}
        </h2>

        <p className="mt-2 text-sm text-slate-500">
          This section will be configured next.
        </p>

      </div>

    </section>
  );
};

export default CaseTaking;