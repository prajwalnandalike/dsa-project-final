import React from 'react'

const AyurvedaSections = [
  { order: 1, key: 'patient', name: 'PATIENT' },
  { order: 2, key: 'chief_complaint', name: 'CHIEF COMPLAINT' },
  { order: 3, key: 'history_of_present_illness', name: 'HISTORY OF PRESENT ILLNESS' },
  { order: 4, key: 'past_history', name: 'PAST HISTORY' },
  { order: 5, key: 'family_history', name: 'FAMILY HISTORY' },
  { order: 6, key: 'personal_history', name: 'PERSONAL HISTORY' },
  { order: 7, key: 'diet_and_lifestyle', name: 'DIET AND LIFESTYLE' },
  { order: 8, key: 'prakriti', name: 'PRAKRITI' },
  { order: 9, key: 'vikriti', name: 'VIKRITI' },

  { order: 10, key: 'dosha_dhatu_mala', name: 'DOSHA, DHATU & MALA' },

  { order: 11, key: 'agni_ama', name: 'AGNI & AMA' },

  { order: 12, key: 'dashavidha_pariksha', name: 'DASHAVIDHA PARIKSHA' },
  { order: 13, key: 'ashtasthana_pariksha', name: 'ASHTASTHANA PARIKSHA' },
  { order: 14, key: 'general_examination', name: 'GENERAL EXAMINATION' },
  { order: 15, key: 'systemic_examination', name: 'SYSTEMIC EXAMINATION' },
  { order: 16, key: 'investigations', name: 'INVESTIGATIONS' },
  { order: 17, key: 'ayurvedic_diagnosis', name: 'AYURVEDIC DIAGNOSIS' },
];

const CaseTemplateBuilder = () => {
  return (
    <div className="min-h-screen bg-slate-50">

      {/* Header */}
      <header className="bg-gradient-to-r from-emerald-700 via-emerald-600 to-cyan-600 px-6 py-5 text-white shadow-lg">
        <div className="mx-auto max-w-6xl">
          <p className="text-sm font-semibold uppercase tracking-wider text-emerald-100">
            Case Template Builder
          </p>

          <h1 className="mt-1 text-2xl font-bold">
            Ayurveda Medical Case Taking
          </h1>

          <p className="mt-1 text-sm text-emerald-100">
            Configure the structure of the Ayurveda clinical case-taking form.
          </p>
        </div>
      </header>

      {/* Content */}
      <main className="mx-auto max-w-6xl px-6 py-8">

        {/* Medical System */}
        <div className="mb-6 rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">

          <p className="text-sm font-semibold text-slate-500">
            Medical System
          </p>

          <div className="mt-2 inline-flex rounded-xl bg-emerald-50 px-4 py-2 font-bold text-emerald-700">
            Ayurveda
          </div>

        </div>

        {/* Sections */}
        <div className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">

          <div className="mb-6 flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-slate-800">
                Ayurveda Case Sections
              </h2>

              <p className="mt-1 text-sm text-slate-500">
                32 sections configured for the case-taking workflow.
              </p>
            </div>

            <span className="rounded-full bg-emerald-50 px-4 py-2 text-sm font-bold text-emerald-700">
              {AyurvedaSections.length} Sections
            </span>
          </div>

          <div className="space-y-3">

            {AyurvedaSections.map((section) => (
              <div
                key={section.key}
                className="flex items-center gap-4 rounded-xl border border-slate-200 bg-slate-50 px-4 py-4 transition hover:border-emerald-200 hover:bg-emerald-50/40"
              >

                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-emerald-100 text-sm font-bold text-emerald-700">
                  {String(section.order).padStart(2, '0')}
                </div>

                <div className="flex-1">
                  <p className="font-semibold text-slate-800">
                    {section.name}
                  </p>

                  <p className="mt-0.5 text-xs text-slate-400">
                    {section.key}
                  </p>
                </div>

                <button
                  type="button"
                  className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-600 transition hover:border-emerald-300 hover:text-emerald-600"
                >
                  Configure
                </button>

              </div>
            ))}

          </div>

        </div>

      </main>
    </div>
  )
}

export default CaseTemplateBuilder