import React, { useState } from "react";

const ChiefComplaintSection = ({ complaints = [], onChange }) => {
  const [localComplaints, setLocalComplaints] = useState(
    complaints.length > 0
      ? complaints
      : [
          {
            complaint: "",
            duration: "",
            since: "",
            severity: "",
          },
        ]
  );

  const updateComplaints = (updated) => {
    setLocalComplaints(updated);

    if (onChange) {
      onChange(updated);
    }
  };

  const updateComplaint = (index, field, value) => {
    const updated = [...localComplaints];

    updated[index] = {
      ...updated[index],
      [field]: value,
    };

    updateComplaints(updated);
  };

  const addComplaint = () => {
    updateComplaints([
      ...localComplaints,
      {
        complaint: "",
        duration: "",
        since: "",
        severity: "",
      },
    ]);
  };

  const removeComplaint = (index) => {
    if (localComplaints.length === 1) return;

    const updated = localComplaints.filter(
      (_, complaintIndex) => complaintIndex !== index
    );

    updateComplaints(updated);
  };

  return (
    <section className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">

      {/* Header */}
      <div className="mb-6 flex items-center gap-4">

        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-100 font-bold text-emerald-700">
          02
        </div>

        <div>
          <h2 className="text-xl font-bold text-slate-800">
            Chief Complaint
          </h2>

          <p className="text-sm text-slate-500">
            Record the patient's main complaint or presenting problem.
          </p>
        </div>

      </div>

      {/* Complaints */}
      <div className="space-y-5">

        {localComplaints.map((item, index) => (

          <div
            key={index}
            className="rounded-xl border border-slate-200 bg-slate-50 p-5"
          >

            {/* Complaint Header */}
            <div className="mb-5 flex items-center justify-between">

              <h3 className="font-bold text-slate-700">
                Complaint {index + 1}
              </h3>

              {localComplaints.length > 1 && (
                <button
                  type="button"
                  onClick={() => removeComplaint(index)}
                  className="text-sm font-semibold text-red-500 transition hover:text-red-700"
                >
                  Remove
                </button>
              )}

            </div>

            <div className="grid gap-5 md:grid-cols-2">

              {/* Complaint */}
              <div className="md:col-span-2">
                <label className="mb-2 block text-sm font-semibold text-slate-600">
                  Chief Complaint
                </label>

                <input
                  type="text"
                  value={item.complaint}
                  onChange={(e) =>
                    updateComplaint(
                      index,
                      "complaint",
                      e.target.value
                    )
                  }
                  placeholder="Enter patient's main complaint"
                  className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100"
                />
              </div>

              {/* Duration */}
              <div>
                <label className="mb-2 block text-sm font-semibold text-slate-600">
                  Duration
                </label>

                <input
                  type="text"
                  value={item.duration}
                  onChange={(e) =>
                    updateComplaint(
                      index,
                      "duration",
                      e.target.value
                    )
                  }
                  placeholder="e.g. 5 days, 2 months"
                  className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100"
                />
              </div>

              {/* Since */}
              <div>
                <label className="mb-2 block text-sm font-semibold text-slate-600">
                  Since
                </label>

                <input
                  type="date"
                  value={item.since}
                  onChange={(e) =>
                    updateComplaint(
                      index,
                      "since",
                      e.target.value
                    )
                  }
                  className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100"
                />
              </div>

              {/* Severity */}
              <div>
                <label className="mb-2 block text-sm font-semibold text-slate-600">
                  Severity
                </label>

                <select
                  value={item.severity}
                  onChange={(e) =>
                    updateComplaint(
                      index,
                      "severity",
                      e.target.value
                    )
                  }
                  className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100"
                >
                  <option value="">Select severity</option>
                  <option value="mild">Mild</option>
                  <option value="moderate">Moderate</option>
                  <option value="severe">Severe</option>
                </select>
              </div>

            </div>

          </div>

        ))}

      </div>

      {/* Add Complaint */}
      <button
        type="button"
        onClick={addComplaint}
        className="mt-5 flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-5 py-3 text-sm font-bold text-emerald-700 transition hover:bg-emerald-100"
      >
        <span className="text-lg">+</span>
        Add Another Complaint
      </button>

    </section>
  );
};

export default ChiefComplaintSection;