import React, { useState } from "react";

const PersonalHistorySection = ({ data = {}, onChange }) => {
  const [formData, setFormData] = useState(data);

  const updateField = (field, value) => {
    const updated = {
      ...formData,
      [field]: value,
    };

    setFormData(updated);

    if (onChange) {
      onChange(updated);
    }
  };

  const toggleCheckbox = (field, value) => {
    const current = formData[field] || [];

    const updated = current.includes(value)
      ? current.filter((item) => item !== value)
      : [...current, value];

    updateField(field, updated);
  };

  return (
    <section className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">

      {/* HEADER */}
      <div className="mb-6 flex items-center gap-4">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-100 font-bold text-emerald-700">
          06
        </div>

        <div>
          <h2 className="text-xl font-bold text-slate-800">
            Personal History
          </h2>

          <p className="text-sm text-slate-500">
            Record bowel, bladder, sleep, habits, occupation and
            reproductive history.
          </p>
        </div>
      </div>

      {/* ================= BOWEL ================= */}
      <SectionCard title="Bowel Habits">

        <Select
          label="Frequency"
          value={formData.bowelFrequency}
          onChange={(value) =>
            updateField("bowelFrequency", value)
          }
          options={[
            "Once daily",
            "Twice daily",
            "More than twice daily",
            "Alternate days",
            "Irregular",
          ]}
        />

        <Select
          label="Pattern"
          value={formData.bowelPattern}
          onChange={(value) =>
            updateField("bowelPattern", value)
          }
          options={[
            "Regular",
            "Irregular",
          ]}
        />

        <Select
          label="Constipation"
          value={formData.constipation}
          onChange={(value) =>
            updateField("constipation", value)
          }
          options={[
            "Absent",
            "Present",
          ]}
        />

        <Select
          label="Diarrhea"
          value={formData.diarrhea}
          onChange={(value) =>
            updateField("diarrhea", value)
          }
          options={[
            "Absent",
            "Present",
          ]}
        />

        <Textarea
          label="Stool Characteristics"
          value={formData.stoolCharacteristics}
          onChange={(value) =>
            updateField("stoolCharacteristics", value)
          }
          placeholder="Record relevant stool characteristics"
        />

      </SectionCard>

      {/* ================= BLADDER ================= */}
      <SectionCard title="Bladder Habits">

        <Select
          label="Frequency"
          value={formData.urineFrequency}
          onChange={(value) =>
            updateField("urineFrequency", value)
          }
          options={[
            "Normal",
            "Increased",
            "Decreased",
            "Irregular",
          ]}
        />

        <Select
          label="Day / Night"
          value={formData.urineTiming}
          onChange={(value) =>
            updateField("urineTiming", value)
          }
          options={[
            "Daytime only",
            "Day and night",
            "Night predominant",
          ]}
        />

        <Select
          label="Urgency"
          value={formData.urineUrgency}
          onChange={(value) =>
            updateField("urineUrgency", value)
          }
          options={[
            "Absent",
            "Present",
          ]}
        />

        <Select
          label="Burning"
          value={formData.urineBurning}
          onChange={(value) =>
            updateField("urineBurning", value)
          }
          options={[
            "Absent",
            "Present",
          ]}
        />

        <Textarea
          label="Urine Characteristics"
          value={formData.urineCharacteristics}
          onChange={(value) =>
            updateField("urineCharacteristics", value)
          }
          placeholder="Record relevant urine characteristics"
        />

      </SectionCard>

      {/* ================= SLEEP ================= */}
      <SectionCard title="Sleep">

        <Select
          label="Sleep Duration"
          value={formData.sleepDuration}
          onChange={(value) =>
            updateField("sleepDuration", value)
          }
          options={[
            "Less than 4 hours",
            "4–6 hours",
            "6–8 hours",
            "More than 8 hours",
          ]}
        />

        <Select
          label="Difficulty Falling Asleep"
          value={formData.difficultyFallingAsleep}
          onChange={(value) =>
            updateField("difficultyFallingAsleep", value)
          }
          options={[
            "Absent",
            "Present",
          ]}
        />

        <Select
          label="Night Awakening"
          value={formData.nightAwakening}
          onChange={(value) =>
            updateField("nightAwakening", value)
          }
          options={[
            "Absent",
            "Occasional",
            "Frequent",
          ]}
        />

        <Select
          label="Daytime Sleepiness"
          value={formData.daytimeSleepiness}
          onChange={(value) =>
            updateField("daytimeSleepiness", value)
          }
          options={[
            "Absent",
            "Present",
          ]}
        />

      </SectionCard>

      {/* ================= EXERCISE ================= */}
      <SectionCard title="Exercise">

        <Input
          label="Type"
          value={formData.exerciseType}
          onChange={(value) =>
            updateField("exerciseType", value)
          }
          placeholder="e.g. walking, yoga, gym"
        />

        <Select
          label="Frequency"
          value={formData.exerciseFrequency}
          onChange={(value) =>
            updateField("exerciseFrequency", value)
          }
          options={[
            "Daily",
            "3–5 times/week",
            "1–2 times/week",
            "Occasionally",
            "Never",
          ]}
        />

        <Select
          label="Duration"
          value={formData.exerciseDuration}
          onChange={(value) =>
            updateField("exerciseDuration", value)
          }
          options={[
            "Less than 15 minutes",
            "15–30 minutes",
            "30–60 minutes",
            "More than 60 minutes",
          ]}
        />

        <Select
          label="Intensity"
          value={formData.exerciseIntensity}
          onChange={(value) =>
            updateField("exerciseIntensity", value)
          }
          options={[
            "Light",
            "Moderate",
            "Heavy",
          ]}
        />

      </SectionCard>

      {/* ================= HABITS ================= */}
      <SectionCard title="Habits / Addictions">

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">

          {[
            "Tobacco",
            "Alcohol",
            "Smoking",
            "Other Substance Use",
            "None",
          ].map((habit) => (
            <label
              key={habit}
              className="flex cursor-pointer items-center gap-3 rounded-lg border border-slate-200 bg-white p-3 transition hover:border-emerald-300"
            >
              <input
                type="checkbox"
                checked={(formData.habits || []).includes(habit)}
                onChange={() =>
                  toggleCheckbox("habits", habit)
                }
                className="h-4 w-4 accent-emerald-600"
              />

              <span className="text-sm text-slate-700">
                {habit}
              </span>
            </label>
          ))}

        </div>

      </SectionCard>

      {/* ================= OCCUPATION ================= */}
      <SectionCard title="Occupation">

        <Input
          label="Occupation"
          value={formData.occupation}
          onChange={(value) =>
            updateField("occupation", value)
          }
          placeholder="Enter occupation"
        />

        <Select
          label="Work Environment"
          value={formData.workEnvironment}
          onChange={(value) =>
            updateField("workEnvironment", value)
          }
          options={[
            "Office",
            "Outdoor",
            "Industrial",
            "Healthcare",
            "Home-based",
            "Other",
          ]}
        />

        <Select
          label="Working Hours"
          value={formData.workingHours}
          onChange={(value) =>
            updateField("workingHours", value)
          }
          options={[
            "Less than 4 hours",
            "4–8 hours",
            "8–12 hours",
            "More than 12 hours",
            "Variable",
          ]}
        />

        <Select
          label="Physical Activity at Work"
          value={formData.workPhysicalActivity}
          onChange={(value) =>
            updateField("workPhysicalActivity", value)
          }
          options={[
            "Sedentary",
            "Light",
            "Moderate",
            "Heavy",
          ]}
        />

        <Input
          label="Occupational Exposure"
          value={formData.occupationalExposure}
          onChange={(value) =>
            updateField("occupationalExposure", value)
          }
          placeholder="Dust, chemicals, heat, noise, etc."
        />

      </SectionCard>

      {/* ================= LIFESTYLE ================= */}
      <SectionCard title="Lifestyle">

        <Textarea
          label="Travel"
          value={formData.travel}
          onChange={(value) =>
            updateField("travel", value)
          }
          placeholder="Record relevant travel habits or exposure"
        />

        <Textarea
          label="Other Lifestyle Factors"
          value={formData.otherLifestyleFactors}
          onChange={(value) =>
            updateField("otherLifestyleFactors", value)
          }
          placeholder="Record other relevant lifestyle factors"
        />

      </SectionCard>

      {/* ================= SEXUAL / REPRODUCTIVE ================= */}
      <SectionCard title="Sexual / Reproductive History">

        <Select
          label="Marital Status"
          value={formData.maritalStatus}
          onChange={(value) =>
            updateField("maritalStatus", value)
          }
          options={[
            "Single",
            "Married",
            "Divorced",
            "Widowed",
            "Other",
            "Prefer not to say",
          ]}
        />

        <Textarea
          label="Menstrual History"
          value={formData.menstrualHistory}
          onChange={(value) =>
            updateField("menstrualHistory", value)
          }
          placeholder="Record when relevant"
        />

        <Textarea
          label="Obstetric History"
          value={formData.obstetricHistory}
          onChange={(value) =>
            updateField("obstetricHistory", value)
          }
          placeholder="Record when relevant"
        />

        <Textarea
          label="Other Relevant History"
          value={formData.reproductiveOtherHistory}
          onChange={(value) =>
            updateField("reproductiveOtherHistory", value)
          }
          placeholder="Record other relevant history"
        />

      </SectionCard>

      {/* ================= OTHER ================= */}
      <SectionCard title="Other Personal History">

        <Textarea
          label="Details"
          value={formData.otherPersonalHistory}
          onChange={(value) =>
            updateField("otherPersonalHistory", value)
          }
          placeholder="Enter any other significant personal history"
        />

      </SectionCard>

    </section>
  );
};


/* ================= SECTION CARD ================= */

const SectionCard = ({ title, children }) => {
  return (
    <div className="mb-6 rounded-xl border border-slate-200 bg-slate-50 p-5">

      <h3 className="mb-5 font-bold text-slate-700">
        {title}
      </h3>

      <div className="grid gap-5 md:grid-cols-2">
        {children}
      </div>

    </div>
  );
};


/* ================= SELECT ================= */

const Select = ({ label, value, onChange, options }) => {
  return (
    <div>
      <label className="mb-2 block text-sm font-semibold text-slate-600">
        {label}
      </label>

      <select
        value={value || ""}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100"
      >
        <option value="">Select {label}</option>

        {options.map((option) => (
          <option key={option} value={option}>
            {option}
          </option>
        ))}
      </select>
    </div>
  );
};


/* ================= INPUT ================= */

const Input = ({ label, value, onChange, placeholder }) => {
  return (
    <div>
      <label className="mb-2 block text-sm font-semibold text-slate-600">
        {label}
      </label>

      <input
        type="text"
        value={value || ""}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100"
      />
    </div>
  );
};


/* ================= TEXTAREA ================= */

const Textarea = ({ label, value, onChange, placeholder }) => {
  return (
    <div className="md:col-span-2">
      <label className="mb-2 block text-sm font-semibold text-slate-600">
        {label}
      </label>

      <textarea
        value={value || ""}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        rows={3}
        className="w-full resize-none rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100"
      />
    </div>
  );
};

export default PersonalHistorySection;