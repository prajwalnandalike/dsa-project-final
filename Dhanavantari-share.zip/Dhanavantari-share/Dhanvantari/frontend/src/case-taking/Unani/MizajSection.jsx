import React, { useEffect, useMemo, useState } from "react";

const initialData = {
  primaryMizaj: "",
  qualities: { hararat: "", burudat: "", yubusat: "", rutubat: "" },
  ajnas: {
    malmas: "", lahmWaShahm: "", ashar: "", laun: "",
    hayatAlAza: "", kayfiyatAlInfial: "", naumWaYaqzah: "",
    afalAlAza: "", fadhlatAlBadan: "", infialatNafsaniyah: ""
  }
};

const mizajOptions = [
  { value: "Damvi", english: "Sanguine", qualities: "Hot + Moist", humor: "Blood" },
  { value: "Safravi", english: "Choleric", qualities: "Hot + Dry", humor: "Yellow Bile" },
  { value: "Balghami", english: "Phlegmatic", qualities: "Cold + Moist", humor: "Phlegm" },
  { value: "Saudavi", english: "Melancholic", qualities: "Cold + Dry", humor: "Black Bile" }
];

const ajnasFields = [
  ["malmas", "Malmas", "Touch", "Describe skin temperature, softness or hardness"],
  ["lahmWaShahm", "Lahm wa Shahm", "Flesh & Fat", "Describe muscle and fat characteristics"],
  ["ashar", "Ash'ar", "Hair", "Describe hair colour, texture and growth"],
  ["laun", "Laun", "Complexion", "Describe complexion"],
  ["hayatAlAza", "Hay'at al-Aza", "Physique / Stature", "Describe chest, veins, joints and body structure"],
  ["kayfiyatAlInfial", "Kayfiyat al-Infial", "Organ Responsiveness", "Describe how quickly or slowly organs respond"],
  ["naumWaYaqzah", "Naum wa Yaqzah", "Sleep & Wakefulness", "Describe sleep and wakefulness pattern"],
  ["afalAlAza", "Af'al al-Aza", "Bodily Functions", "Describe strength, speed and perfection of functions"],
  ["fadhlatAlBadan", "Fadhlat al-Badan", "Excreta", "Describe urine, sweat and fecal characteristics"],
  ["infialatNafsaniyah", "Infi'alat Nafsaniyah", "Psychic Reactions", "Describe anger, anxiety, calmness or other reactions"]
];

const qualityOptions = ["Low", "Normal", "Increased"];

function MizajSection({ data = {}, onChange }) {
  const [formData, setFormData] = useState({
    ...initialData, ...data,
    qualities: { ...initialData.qualities, ...(data.qualities || {}) },
    ajnas: { ...initialData.ajnas, ...(data.ajnas || {}) }
  });

  useEffect(() => {
    setFormData({
      ...initialData, ...data,
      qualities: { ...initialData.qualities, ...(data.qualities || {}) },
      ajnas: { ...initialData.ajnas, ...(data.ajnas || {}) }
    });
  }, [data]);

  const selectedMizaj = useMemo(
    () => mizajOptions.find(x => x.value === formData.primaryMizaj),
    [formData.primaryMizaj]
  );

  const assessment = useMemo(() => ({
    primaryMizaj: selectedMizaj?.value || "",
    qualities: Object.entries(formData.qualities)
      .filter(([, value]) => value)
      .map(([key, value]) => ({ key, value })),
    completedAjnas: ajnasFields.filter(([key]) =>
      formData.ajnas?.[key]?.trim()
    ).length
  }), [formData, selectedMizaj]);

  const updateForm = updated => {
    setFormData(updated);
    onChange?.(updated);
  };

  const saveAssessment = () => {
    const finalData = { ...formData, assessment };
    setFormData(finalData);
    onChange?.(finalData);
    alert("Mizaj Assessment saved successfully.");
  };

  const resetAssessment = () => {
    setFormData(initialData);
    onChange?.(initialData);
  };

  return (
    <section className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
      <div className="bg-gradient-to-r from-emerald-700 via-emerald-600 to-cyan-600 px-6 py-7 text-white">
        <div className="flex items-center gap-4">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white/15 text-2xl">☯</div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-emerald-100">Section 08</p>
            <h2 className="mt-1 text-2xl font-bold">Mizaj (Temperament)</h2>
            <p className="mt-1 text-sm text-emerald-50">Assessment of temperament and its related characteristics</p>
          </div>
        </div>
      </div>

      <div className="p-5 sm:p-7">
        <div className="grid gap-6 xl:grid-cols-[1.15fr_0.85fr]">
          <div className="space-y-6">
            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-5">
              <h3 className="font-bold text-slate-800">Mizaj (Temperament)</h3>
              <p className="text-xs text-slate-500">Select the primary temperament identified by the doctor.</p>

              <div className="mt-5 grid gap-3 sm:grid-cols-2">
                {mizajOptions.map(option => {
                  const selected = formData.primaryMizaj === option.value;
                  return (
                    <label key={option.value} className={`cursor-pointer rounded-2xl border p-4 transition ${selected ? "border-emerald-500 bg-emerald-50 shadow-sm" : "border-slate-200 bg-white hover:border-emerald-300"}`}>
                      <div className="flex items-start gap-3">
                        <input
                          type="radio"
                          name="primaryMizaj"
                          checked={selected}
                          onChange={() => updateForm({ ...formData, primaryMizaj: option.value })}
                          className="mt-1 h-4 w-4 accent-emerald-600"
                        />
                        <div>
                          <p className="font-bold text-slate-800">
                            {option.value} <span className="font-medium text-slate-500">({option.english})</span>
                          </p>
                          <p className="mt-1 text-sm font-semibold text-emerald-700">{option.qualities}</p>
                          <p className="mt-1 text-xs text-slate-500">Humor: {option.humor}</p>
                        </div>
                      </div>
                    </label>
                  );
                })}
              </div>
            </div>

            <div className="rounded-2xl border border-slate-200 bg-white p-5">
              <h3 className="font-bold text-slate-800">Four Basic Qualities</h3>
              <p className="mt-1 text-xs text-slate-500">Assess the observed degree of each basic quality.</p>
              <div className="mt-5 grid gap-4 sm:grid-cols-2">
                <QualityField title="Hararat" english="Heat" value={formData.qualities.hararat} onChange={v => updateForm({ ...formData, qualities: { ...formData.qualities, hararat: v } })} />
                <QualityField title="Burudat" english="Coldness" value={formData.qualities.burudat} onChange={v => updateForm({ ...formData, qualities: { ...formData.qualities, burudat: v } })} />
                <QualityField title="Yubusat" english="Dryness" value={formData.qualities.yubusat} onChange={v => updateForm({ ...formData, qualities: { ...formData.qualities, yubusat: v } })} />
                <QualityField title="Rutubat" english="Moisture" value={formData.qualities.rutubat} onChange={v => updateForm({ ...formData, qualities: { ...formData.qualities, rutubat: v } })} />
              </div>
            </div>

            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-5">
              <h3 className="font-bold text-slate-800">Ajnas-e-Mizaj (Temperamental Characteristics)</h3>
              <p className="mt-1 text-xs text-slate-500">Clinical observations supporting the temperament assessment.</p>

              <div className="mt-5 space-y-4">
                {ajnasFields.map(([key, title, english, placeholder]) => (
                  <div key={key}>
                    <label className="mb-2 block text-sm font-bold text-slate-700">
                      {title} <span className="font-medium text-slate-500">({english})</span>
                    </label>
                    <textarea
                      rows={2}
                      value={formData.ajnas?.[key] || ""}
                      onChange={e => updateForm({ ...formData, ajnas: { ...formData.ajnas, [key]: e.target.value } })}
                      placeholder={placeholder}
                      className="w-full resize-y rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm leading-6 text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-emerald-500 focus:ring-4 focus:ring-emerald-100"
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="h-fit rounded-2xl border border-slate-200 bg-white p-5 xl:sticky xl:top-5">
            <h3 className="text-lg font-bold text-slate-800">Mizaj Assessment Summary</h3>
            <p className="mt-1 text-xs text-slate-500">Summary of the doctor's assessment</p>

            {!selectedMizaj ? (
              <div className="mt-5 rounded-2xl border border-dashed border-slate-300 bg-slate-50 px-5 py-10 text-center">
                <div className="text-3xl">🧭</div>
                <p className="mt-3 text-sm font-semibold text-slate-600">Mizaj not selected</p>
                <p className="mt-1 text-xs text-slate-400">Select the primary Mizaj to generate the assessment summary.</p>
              </div>
            ) : (
              <div className="mt-5 space-y-4">
                <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-5">
                  <p className="text-xs font-semibold uppercase tracking-wide text-emerald-700">Primary Mizaj</p>
                  <h4 className="mt-2 text-2xl font-bold text-slate-800">{selectedMizaj.value}</h4>
                  <p className="mt-1 text-sm font-medium text-slate-600">({selectedMizaj.english})</p>
                  <div className="mt-4 rounded-xl bg-white/80 p-3">
                    <p className="text-xs font-semibold text-slate-500">Quality Combination</p>
                    <p className="mt-1 font-bold text-emerald-700">{selectedMizaj.qualities}</p>
                  </div>
                  <div className="mt-3 rounded-xl bg-white/80 p-3">
                    <p className="text-xs font-semibold text-slate-500">Associated Humor</p>
                    <p className="mt-1 font-semibold text-slate-700">{selectedMizaj.humor}</p>
                  </div>
                </div>

                <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                  <h4 className="font-bold text-slate-800">Basic Qualities</h4>
                  <div className="mt-3 space-y-2">
                    <SummaryRow label="Hararat (Heat)" value={formData.qualities.hararat} />
                    <SummaryRow label="Burudat (Coldness)" value={formData.qualities.burudat} />
                    <SummaryRow label="Yubusat (Dryness)" value={formData.qualities.yubusat} />
                    <SummaryRow label="Rutubat (Moisture)" value={formData.qualities.rutubat} />
                  </div>
                </div>

                <div className="rounded-2xl border border-cyan-200 bg-cyan-50/50 p-4">
                  <h4 className="font-bold text-slate-800">Ajnas-e-Mizaj Observations</h4>
                  <p className="mt-2 text-sm text-slate-600">{assessment.completedAjnas} of {ajnasFields.length} characteristics documented.</p>
                  <div className="mt-3 h-2 overflow-hidden rounded-full bg-slate-200">
                    <div className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-cyan-500" style={{ width: `${(assessment.completedAjnas / ajnasFields.length) * 100}%` }} />
                  </div>
                </div>

                <div className="rounded-2xl border border-blue-200 bg-blue-50 p-4">
                  <p className="text-xs font-semibold uppercase tracking-wide text-blue-700">Clinical Interpretation</p>
                  <p className="mt-2 text-sm leading-6 text-slate-700">
                    The selected temperament is <strong>{selectedMizaj.value} ({selectedMizaj.english})</strong>,
                    characterized by <strong>{selectedMizaj.qualities}</strong> and associated with <strong>{selectedMizaj.humor}</strong>.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="mt-6 rounded-2xl border border-blue-200 bg-gradient-to-r from-blue-50 to-cyan-50 p-5">
          <h3 className="font-bold text-blue-800">Ajnas-e-Mizaj (Temperamental Characteristics)</h3>
          <p className="mt-1 text-sm leading-6 text-slate-600">
            These observations support the doctor's assessment of Mizaj. The final clinical interpretation remains the responsibility of the treating doctor.
          </p>
        </div>

        <div className="mt-6 flex flex-col-reverse gap-3 sm:flex-row sm:items-center sm:justify-between">
          <button type="button" onClick={resetAssessment} className="rounded-xl border border-slate-300 bg-white px-6 py-3 text-sm font-bold text-slate-600 hover:bg-slate-50">
            ↻ Reset
          </button>
          <button type="button" onClick={saveAssessment} className="rounded-xl bg-gradient-to-r from-emerald-600 to-cyan-600 px-7 py-3 text-sm font-bold text-white shadow-md hover:-translate-y-0.5 hover:shadow-lg">
            ✓ Save Mizaj Assessment
          </button>
        </div>
      </div>
    </section>
  );
}

const QualityField = ({ title, english, value, onChange }) => (
  <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
    <label className="block text-sm font-bold text-slate-700">
      {title} <span className="font-medium text-slate-500">({english})</span>
    </label>
    <div className="mt-3 flex flex-wrap gap-2">
      {qualityOptions.map(option => (
        <label key={option} className={`cursor-pointer rounded-lg border px-3 py-2 text-xs font-semibold transition ${value === option ? "border-emerald-500 bg-emerald-100 text-emerald-800" : "border-slate-200 bg-white text-slate-600 hover:border-emerald-300"}`}>
          <input type="radio" name={title} checked={value === option} onChange={() => onChange(option)} className="mr-2 accent-emerald-600" />
          {option}
        </label>
      ))}
    </div>
  </div>
);

const SummaryRow = ({ label, value }) => (
  <div className="flex items-center justify-between gap-3 rounded-xl bg-white px-3 py-2.5">
    <span className="text-xs font-medium text-slate-600">{label}</span>
    <span className={`rounded-lg px-2.5 py-1 text-xs font-bold ${value ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-400"}`}>
      {value || "Not assessed"}
    </span>
  </div>
);

export default MizajSection;
