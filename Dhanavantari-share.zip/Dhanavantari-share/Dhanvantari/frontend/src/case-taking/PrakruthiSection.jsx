import React, { useMemo, useState } from "react";

/*
  PRAKRUTHI ASSESSMENT

  Each option is independently selectable.
  The Prakruthi result is calculated from the
  total number of selected checkboxes.
*/

const prakruthiData = [
  {
    id: 1,
    characteristic: "Body Frame",
    vata: [
      "Thin and Lean",
      "Bones and veins appear prominent",
    ],
    pitta: [
      "Medium",
      "Balanced muscle and fat distribution",
    ],
    kapha: [
      "Well Built",
      "Strong and stable Physique",
    ],
  },

  {
    id: 2,
    characteristic: "Type of Hair",
    vata: [
      "Dry and with Split Ends",
    ],
    pitta: [
      "Normal, Thin, More Hair Fall",
    ],
    kapha: [
      "Greasy, Heavy",
    ],
  },

  {
    id: 3,
    characteristic: "Colour of Hair",
    vata: [
      "Pale Brown and Brittle",
      "Hair colour appear dull or uneven",
    ],
    pitta: [
      "Red or Brown",
      "Hair turn grey early",
    ],
    kapha: [
      "Jet Black",
      "Colour remains stable for long time",
    ],
  },

  {
    id: 4,
    characteristic: "Skin",
    vata: [
      "Dry, Rough, Prone to cracking and dehydration",
      "Feels cool to touch",
    ],
    pitta: [
      "Soft, More Sweating, Acne",
      "Reacts quickly to heat and sun",
    ],
    kapha: [
      "Moist, Greasy",
      "Naturally oily with good elasticity",
    ],
  },

  {
    id: 5,
    characteristic: "Complexion",
    vata: [
      "Dark, Blackish",
      "Skin may look dull or uneven",
    ],
    pitta: [
      "Pink to Red",
      "Coppery complexion",
    ],
    kapha: [
      "Fair to whitish, glowing complexion",
      "Even-toned, clear and naturally bright",
    ],
  },

  {
    id: 6,
    characteristic: "Body Weight",
    vata: [
      "Low, Difficult to Put on weight",
    ],
    pitta: [
      "Medium, Can Easily Lose or Gain Weight",
    ],
    kapha: [
      "Overweight, Difficult to Lose Weight",
    ],
  },

  {
    id: 7,
    characteristic: "Nails",
    vata: [
      "Blackish, Small, Brittle",
    ],
    pitta: [
      "Reddish, Small",
    ],
    kapha: [
      "Pinkish, Big, Smooth",
    ],
  },

  {
    id: 8,
    characteristic: "Size and Color of the Teeth",
    vata: [
      "Very Big or very Small, Irregular, Blackish",
    ],
    pitta: [
      "Medium Sized, Yellowish",
    ],
    kapha: [
      "Large, Shining White",
    ],
  },

  {
    id: 9,
    characteristic: "Pace of Performing Work",
    vata: [
      "Fast, Always in Hurry",
    ],
    pitta: [
      "Medium, Energetic",
    ],
    kapha: [
      "Slow, Steady",
    ],
  },

  {
    id: 10,
    characteristic: "Mental Activity",
    vata: [
      "Quick, Restless",
    ],
    pitta: [
      "Smart Intellect, Aggressive",
    ],
    kapha: [
      "Calm, Stable",
    ],
  },

  {
    id: 11,
    characteristic: "Memory",
    vata: [
      "Short Term Bad",
    ],
    pitta: [
      "Good Memory",
    ],
    kapha: [
      "Long Term is Best",
    ],
  },

  {
    id: 12,
    characteristic: "Grasping Power",
    vata: [
      "Grasps Quickly but not Completely",
      "Forgets Quickly",
    ],
    pitta: [
      "Grasps Quickly but Completely",
      "Good Memory",
    ],
    kapha: [
      "Grasps Late",
      "Retains for Longer Time",
    ],
  },

  {
    id: 13,
    characteristic: "Sleep Pattern",
    vata: [
      "Interrupted, Less",
    ],
    pitta: [
      "Moderate",
    ],
    kapha: [
      "Sleepy, Lazy",
    ],
  },

  {
    id: 14,
    characteristic: "Intolerance to Weather Conditions",
    vata: [
      "Aversion to Cold",
    ],
    pitta: [
      "Aversion to Heat",
    ],
    kapha: [
      "Aversion to Moist, Rainy and cool weather",
    ],
  },

  {
    id: 15,
    characteristic: "Reactions Under Adverse Situation",
    vata: [
      "Anxiety, Worry, Irritability",
    ],
    pitta: [
      "Anger, Aggression",
    ],
    kapha: [
      "Calm, Reclusive, Sometimes Depressive",
    ],
  },

  {
    id: 16,
    characteristic: "Mood",
    vata: [
      "Changes very quickly",
      "Frequent mood swings",
      "Can shift from excitement to anxiety fast",
    ],
    pitta: [
      "Changes slowly",
      "Mood is intense but focused",
      "Prone to irritation or anger when disturbed",
    ],
    kapha: [
      "Stable and steady mood",
      "Calm and composed nature",
      "Rarely disturbed, emotionally balanced",
    ],
  },

  {
    id: 17,
    characteristic: "Eating Habit",
    vata: [
      "Eats Quickly Without Chewing Properly",
    ],
    pitta: [
      "Eats at a Moderate Speed",
    ],
    kapha: [
      "Chews Food Properly",
    ],
  },

  {
    id: 18,
    characteristic: "Hunger",
    vata: [
      "Irregular hunger pattern",
      "May feel hungry at odd times or forget to eat",
      "Appetite fluctuates frequently",
    ],
    pitta: [
      "Strong, sharp and sudden hunger",
      "Cannot tolerate skipping meals",
      "Gets irritable when hungry",
    ],
    kapha: [
      "Mild or slow hunger",
      "Can easily skip meals",
      "Appetite remains steady and controlled",
    ],
  },

  {
    id: 19,
    characteristic: "Body Temperature",
    vata: [
      "Less than Normal",
      "Hands and Feet are Cold",
    ],
    pitta: [
      "More than Normal",
      "Face and Forehead Hot",
    ],
    kapha: [
      "Normal",
      "Hands and Feet Slightly Cold",
    ],
  },

  {
    id: 20,
    characteristic: "Joints",
    vata: [
      "Dry and weak joints",
      "Cracking or clicking sounds on movement",
      "Prone to stiffness and pain",
    ],
    pitta: [
      "Strong and flexible joints",
      "Moderate lubrication",
      "May develop inflammation with overuse",
    ],
    kapha: [
      "Large, well-lubricated and stable joints",
      "Can bear heavy weight easily",
      "Less prone to wear and tear",
    ],
  },

  {
    id: 21,
    characteristic: "Nature",
    vata: [
      "Timid, nervous and sometimes insecure",
      "Easily worried or fearful",
      "Can feel jealous or anxious",
    ],
    pitta: [
      "Bold, confident and fearless",
      "Strong sense of ego and leadership",
      "Competitive by nature",
    ],
    kapha: [
      "Calm, patient and forgiving",
      "Grateful, compassionate and loyal",
      "Not greedy, emotionally steady",
    ],
  },

  {
    id: 22,
    characteristic: "Body Energy",
    vata: [
      "Becomes Low in Evening",
      "Fatigues After Less Work",
    ],
    pitta: [
      "Moderate",
      "Gets Tired After Medium Work",
    ],
    kapha: [
      "Excellent Energy Throughout Day",
      "Not Easily Fatigued",
    ],
  },

  {
    id: 23,
    characteristic: "Eyeball",
    vata: [
      "Unsteady",
      "Fast Moving",
    ],
    pitta: [
      "Moving Slowly",
    ],
    kapha: [
      "Steady",
    ],
  },

  {
    id: 24,
    characteristic: "Quality of Voice",
    vata: [
      "Dry, rough or hoarse voice",
      "Speech may break or lack clarity",
      "Tone often changes while talking",
    ],
    pitta: [
      "Sharp, fast and commanding voice",
      "Clear pronunciation with strong expression",
      "Can sound authoritative or intense",
    ],
    kapha: [
      "Soft, deep and pleasant voice",
      "Slow, steady and soothing tone",
      "Speech is clear and well-modulated",
    ],
  },

  {
    id: 25,
    characteristic: "Dreams",
    vata: [
      "Sky, Wind",
      "Flying Objects",
      "Confusion",
    ],
    pitta: [
      "Fire, Light, Bright Colors, Violence",
      "Violence, competition or intense action",
      "Vivid and emotionally charged dreams",
    ],
    kapha: [
      "Dreams of water bodies, gardens and greenery",
      "Pleasant scenes and close relationships",
      "Calm, stable and less frequent dreams",
    ],
  },

  {
    id: 26,
    characteristic: "Social Relations",
    vata: [
      "Makes few friends",
      "Prefers solitude or small groups",
      "Relationships may be short-lived",
    ],
    pitta: [
      "Has a good number of friends",
      "Enjoys social interaction with purpose",
      "Can be dominant in relationships",
    ],
    kapha: [
      "Loves to socialize",
      "Forms deep, long-lasting relationships",
      "Loyal, caring and dependable friend",
    ],
  },

  {
    id: 27,
    characteristic: "Wealth",
    vata: [
      "Spends money impulsively",
      "Little long-term planning for savings",
      "Finances may fluctuate",
    ],
    pitta: [
      "Saves money but spends on valuable or quality items",
      "Practical and goal-oriented with finances",
      "Balanced approach to wealth",
    ],
    kapha: [
      "Strong tendency to save",
      "Careful, conservative spending habits",
      "Builds wealth steadily over time",
    ],
  },

  {
    id: 28,
    characteristic: "Bowel Movements",
    vata: [
      "Dry, hard, Blackish, Scanty Stools",
    ],
    pitta: [
      "Soft, Yellowish, Loose Stools",
    ],
    kapha: [
      "Heavy, Thick, Stick Stools",
    ],
  },

  {
    id: 29,
    characteristic: "Walking Pace",
    vata: [
      "Quick, Fast With long Steps",
    ],
    pitta: [
      "Average, Steady",
    ],
    kapha: [
      "Slow with Short Steps",
    ],
  },

  {
    id: 30,
    characteristic: "Communication Skills",
    vata: [
      "Talks fast and jumps between topics",
      "Speech may be unclear or irrelevant",
      "Expressive",
    ],
    pitta: [
      "Clear, logical and persuasive speaker",
      "Strong argumentative and debating skills",
      "Confident and expressive",
    ],
    kapha: [
      "Speaks less but with authority",
      "Firm, calm and well-thought words",
      "Communicates steadily",
    ],
  },
];

 const gunaData = {
  Vata: [
    "Ruksha (Dry)",
    "Laghu (Light)",
    "Shita (Cold)",
    "Khara (Rough)",
    "Sukshma (Subtle)",
    "Chala (Constant movement)",
    "Sara (Lubricated movement)",
    "Vishada (Clear / dry)",
  ],

  Pitta: [
    "Sasneha (Slightly unctuous)",
    "Tikshna (Sharp)",
    "Ushna (Hot)",
    "Laghu (Light)",
    "Visram (Foul / fermented)",
    "Sara (Slippery)",
    "Drava (Liquid)",
    "Amla (Sour)",
    "Katu (Pungent)",
  ],

  Kapha: [
    "Snigdha (Unctuous)",
    "Shita (Cold)",
    "Guru (Heavy)",
    "Manda (Dull / slow)",
    "Shlakshna (Smooth)",
    "Mrtsna (Greasy)",
    "Sthira (Stable)",
    "Hema (Very cold)",
    "Madhura (Sweet)",
    "Ojas (Pleasantness / vitality)",
    "Mrdu (Soft)",
  ],
};

const PrakruthiSection = ({ data = {}, onChange }) => {
  const [selected, setSelected] = useState(data.selected || {});

  const handleCheckbox = (rowId, dosha, optionIndex) => {
    const key = `${rowId}-${dosha}-${optionIndex}`;

    const updated = {
      ...selected,
      [key]: !selected[key],
    };

    setSelected(updated);

    if (onChange) {
      onChange({
        ...data,
        selected: updated,
      });
    }
  };

  // const counts = useMemo(() => {
  //   const result = {
  //     vata: 0,
  //     pitta: 0,
  //     kapha: 0,
  //   };
  const counts = {
  vata: Object.keys(selected).filter(
    (key) => key.toLowerCase().includes("vata") && selected[key]
  ).length,

  pitta: Object.keys(selected).filter(
    (key) => key.toLowerCase().includes("pitta") && selected[key]
  ).length,

  kapha: Object.keys(selected).filter(
    (key) => key.toLowerCase().includes("kapha") && selected[key]
  ).length,
};

  

  const dominantPrakruthi = useMemo(() => {
    const entries = Object.entries(counts);

    const highest = Math.max(
      counts.vata,
      counts.pitta,
      counts.kapha
    );

    if (highest === 0) {
      return "Not Assessed";
    }

    const dominant = entries
      .filter(([, count]) => count === highest)
      .map(([dosha]) => dosha);

    if (dominant.length === 1) {
      return `${capitalize(dominant[0])} Prakruthi`;
    }

    if (dominant.length === 2) {
      return `${capitalize(dominant[0])} - ${capitalize(
        dominant[1]
      )} Dual Prakruthi`;
    }

    return "Tridosha / Mixed Prakruthi";
  }, [counts]);

  const resetAssessment = () => {
    setSelected({});

    if (onChange) {
      onChange({
        ...data,
        selected: {},
      });
    }
  };

  const totalSelections =
    counts.vata + counts.pitta + counts.kapha;

  return (
    <section className="rounded-3xl bg-white p-4 shadow-sm ring-1 ring-slate-200 sm:p-6">

      {/* ================= HEADER ================= */}
      <div className="mb-6 rounded-2xl bg-gradient-to-r from-emerald-50 via-white to-cyan-50 p-5 ring-1 ring-emerald-100">

        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">

          <div>
            <p className="text-sm font-bold uppercase tracking-wider text-emerald-600">
              Section 08
            </p>

            <h2 className="mt-1 text-2xl font-bold text-slate-800 sm:text-3xl">
              Prakruthi Assessment
            </h2>

            <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-500">
              Select the characteristics that best describe the
              patient's predominant nature. The Prakruthi result
              is calculated automatically from the selected
              options.
            </p>
          </div>

          <div className="rounded-2xl bg-white px-5 py-4 text-center shadow-sm ring-1 ring-slate-200">
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">
              Total Selections
            </p>

            <p className="mt-1 text-3xl font-bold text-emerald-600">
              {totalSelections}
            </p>
          </div>

        </div>
      </div>

      {/* ================= RESULT ================= */}
      <div className="mb-6 grid gap-4 md:grid-cols-4">

        <DoshaCount
          name="Vata"
          count={counts.vata}
          icon="◉"
          type="vata"
        />

        <DoshaCount
          name="Pitta"
          count={counts.pitta}
          icon="◈"
          type="pitta"
        />

        <DoshaCount
          name="Kapha"
          count={counts.kapha}
          icon="◆"
          type="kapha"
        />

        <div className="rounded-2xl border border-amber-200 bg-amber-50 p-5">

          <p className="text-xs font-bold uppercase tracking-wide text-amber-700">
            Prakruthi Result
          </p>

          <p className="mt-2 text-xl font-bold text-slate-800">
            {dominantPrakruthi}
          </p>

          <p className="mt-1 text-xs text-slate-500">
            Based on highest number of selected options
          </p>

        </div>

      </div>

      {/* ================= TABLE ================= */}
      <div className="overflow-x-auto rounded-2xl border border-slate-200">

        <table className="min-w-[1050px] w-full border-collapse">

          <thead>
            <tr className="bg-slate-50">

              <th className="w-14 border-b border-r border-slate-200 px-3 py-4 text-center text-sm font-bold text-slate-700">
                #
              </th>

              <th className="w-56 border-b border-r border-slate-200 px-4 py-4 text-left text-sm font-bold text-slate-700">
                Characteristics
              </th>

              <th className="w-72 border-b border-r border-slate-200 bg-cyan-50 px-4 py-4 text-left text-sm font-bold text-cyan-700">
                Vata
              </th>

              <th className="w-72 border-b border-r border-slate-200 bg-orange-50 px-4 py-4 text-left text-sm font-bold text-orange-700">
                Pitta
              </th>

              <th className="w-72 border-b border-slate-200 bg-emerald-50 px-4 py-4 text-left text-sm font-bold text-emerald-700">
                Kapha
              </th>

            </tr>
          </thead>

          <tbody>
            {/* GUNA ROW */}
<tr className="bg-emerald-50">
  <td className="border border-slate-200 p-3 text-center font-bold">
    —
  </td>

  <td className="border border-slate-200 p-3">
    <div className="font-bold text-slate-800">
      Guna
    </div>
    <div className="text-xs text-slate-500">
      Qualities
    </div>
  </td>

  {/* VATA GUNA */}
  <td className="border border-slate-200 p-3 align-top">
    {gunaData.Vata.map((guna, index) => {
      const key = `guna-vata-${index}`;

      return (
        <label
          key={key}
          className="flex cursor-pointer items-start gap-2 py-1.5 text-sm text-slate-700"
        >
          <input
            type="checkbox"
            checked={selected[key] || false}
            onChange={() => {
                const updated = {
                  ...selected,
                  [key]: !selected[key],
                };

                setSelected(updated);

                if (onChange) {
                  onChange({
                    ...data,
                    selected: updated,
                  });
                }
              }}
            className="mt-1 h-4 w-4"
          />

          <span>{guna}</span>
        </label>
      );
    })}
  </td>

  {/* PITTA GUNA */}
  <td className="border border-slate-200 p-3 align-top">
    {gunaData.Pitta.map((guna, index) => {
      const key = `guna-pitta-${index}`;

      return (
        <label
          key={key}
          className="flex cursor-pointer items-start gap-2 py-1.5 text-sm text-slate-700"
        >
          <input
            type="checkbox"
            checked={selected[key] || false}
           onChange={() => {
              const updated = {
                ...selected,
                [key]: !selected[key],
              };

              setSelected(updated);

              if (onChange) {
                onChange({
                  ...data,
                  selected: updated,
                });
              }
            }}
            className="mt-1 h-4 w-4"
          />

          <span>{guna}</span>
        </label>
      );
    })}
  </td>

  {/* KAPHA GUNA */}
  <td className="border border-slate-200 p-3 align-top">
    {gunaData.Kapha.map((guna, index) => {
      const key = `guna-kapha-${index}`;

      return (
        <label
          key={key}
          className="flex cursor-pointer items-start gap-2 py-1.5 text-sm text-slate-700"
        >
          <input
            type="checkbox"
            checked={selected[key] || false}
            onChange={() => {
              const updated = {
                ...selected,
                [key]: !selected[key],
              };

              setSelected(updated);

              if (onChange) {
                onChange({
                  ...data,
                  selected: updated,
                });
              }
            }}
          className="mt-1 h-4 w-4"
          />

          <span>{guna}</span>
        </label>
      );
    })}
  </td>
</tr>

            {prakruthiData.map((row, rowIndex) => (

              <tr
                key={row.id}
                className={
                  rowIndex % 2 === 0
                    ? "bg-white"
                    : "bg-slate-50/70"
                }
              >

                {/* Number */}
                <td className="border-b border-r border-slate-200 px-3 py-5 text-center text-sm font-semibold text-slate-500">
                  {row.id}
                </td>

                {/* Characteristic */}
                <td className="border-b border-r border-slate-200 px-4 py-5 align-middle">

                  <p className="font-semibold leading-6 text-slate-700">
                    {row.characteristic}
                  </p>

                </td>

                {/* Vata */}
                <DoshaCell
                  options={row.vata}
                  rowId={row.id}
                  dosha="vata"
                  selected={selected}
                  onChange={handleCheckbox}
                />

                {/* Pitta */}
                <DoshaCell
                  options={row.pitta}
                  rowId={row.id}
                  dosha="pitta"
                  selected={selected}
                  onChange={handleCheckbox}
                />

                {/* Kapha */}
                <DoshaCell
                  options={row.kapha}
                  rowId={row.id}
                  dosha="kapha"
                  selected={selected}
                  onChange={handleCheckbox}
                />

              </tr>

            ))}

          </tbody>

        </table>

      </div>

      {/* ================= INFORMATION ================= */}
      <div className="mt-6 rounded-2xl border border-amber-100 bg-amber-50 p-5">

        <div className="flex gap-3">

          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-amber-100 text-lg">
            ℹ️
          </div>

          <div>

            <h3 className="font-bold text-slate-800">
              Prakruthi Assessment
            </h3>

            <p className="mt-1 text-sm leading-6 text-slate-600">
              Select the characteristics that best match the
              patient's observed or reported nature. The system
              counts every selected option under Vata, Pitta and
              Kapha and displays the highest count as the
              predominant Prakruthi.
            </p>

          </div>

        </div>

      </div>

      {/* ================= ACTIONS ================= */}
      <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:justify-between">

        <button
          type="button"
          onClick={resetAssessment}
          className="rounded-xl border border-slate-200 bg-white px-6 py-3 text-sm font-bold text-slate-600 transition hover:bg-slate-50"
        >
          ↻ Reset Assessment
        </button>

        <button
            type="button"
            onClick={() => {
              const assessment = {
                selected,
                counts,
                dominantPrakruthi,
                totalSelections,
              };

              if (onChange) {
                onChange({
                  ...data,
                  selected,
                  assessment,
                });
              }

              alert("Prakruthi Assessment saved successfully!");
            }}
            className="rounded-xl bg-gradient-to-r from-emerald-600 to-cyan-600 px-7 py-3 text-sm font-bold text-white shadow-md transition hover:-translate-y-0.5 hover:shadow-lg"
          >
            ✓ Save Prakruthi Assessment
          </button>

      </div>

    </section>
  );
};


/* ================= DOSHA COUNT ================= */

const DoshaCount = ({ name, count, icon, type }) => {

  const styles = {
    vata: "border-cyan-200 bg-cyan-50 text-cyan-700",
    pitta: "border-orange-200 bg-orange-50 text-orange-700",
    kapha: "border-emerald-200 bg-emerald-50 text-emerald-700",
  };

  return (
    <div className={`rounded-2xl border p-5 ${styles[type]}`}>

      <div className="flex items-center justify-between">

        <div className="flex items-center gap-3">

          <span className="text-xl">
            {icon}
          </span>

          <span className="font-bold">
            {name}
          </span>

        </div>

        <span className="text-3xl font-bold">
          {count}
        </span>

      </div>

      <p className="mt-2 text-xs opacity-70">
        selected options
      </p>

    </div>
  );
};


/* ================= DOSHA CELL ================= */

const DoshaCell = ({
  options,
  rowId,
  dosha,
  selected,
  onChange,
}) => {

  return (
    <td className="border-b border-r border-slate-200 px-4 py-4 align-top">

      <div className="space-y-3">

        {options.map((option, index) => {

          const key = `${rowId}-${dosha}-${index}`;

          return (
            <label
              key={key}
              className={`flex cursor-pointer items-start gap-3 rounded-xl border p-3 transition ${
                selected[key]
                  ? "border-emerald-300 bg-emerald-50 shadow-sm"
                  : "border-transparent hover:border-slate-200 hover:bg-white"
              }`}
            >

              <input
                type="checkbox"
                checked={Boolean(selected[key])}
                onChange={() =>
                  onChange(rowId, dosha, index)
                }
                className="mt-1 h-4 w-4 shrink-0 accent-emerald-600"
              />

              <span className="text-sm leading-6 text-slate-700">
                {option}
              </span>

            </label>
          );

        })}

      </div>

    </td>
  );
};


/* ================= HELPER ================= */

const capitalize = (value) => {
  return value.charAt(0).toUpperCase() + value.slice(1);
};

export default PrakruthiSection;