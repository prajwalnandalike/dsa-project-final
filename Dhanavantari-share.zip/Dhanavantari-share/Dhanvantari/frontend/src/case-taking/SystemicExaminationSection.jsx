import React, { useState } from "react";

const initialData = {
  cardiovascular: {
    inspection: "",
    palpation: "",
    percussion: "",
    auscultation: "",
  },

  respiratory: {
    inspection: "",
    palpation: "",
    percussion: "",
    auscultation: "",
  },

  gastrointestinal: {
    inspection: "",
    palpation: "",
    percussion: "",
    auscultation: "",
  },

  nervous: {
    higherFunctions: "",
    cranialNerves: "",
    motorSystem: "",
    sensorySystem: "",
    reflexes: "",
    coordination: "",
    gait: "",
  },

  musculoskeletal: {
    inspection: "",
    palpation: "",
    movements: "",
    musclePower: "",
    joints: "",
  },

  genitourinary: {
    inspection: "",
    palpation: "",
    tenderness: "",
    otherFindings: "",
  },

  endocrine: {
    thyroid: "",
    lymphNodes: "",
    otherFindings: "",
  },

  otherSystems: "",
};

const systems = [
  {
    key: "cardiovascular",
    title: "Cardiovascular System",
    icon: "♥",
    fields: [
      ["inspection", "Inspection"],
      ["palpation", "Palpation"],
      ["percussion", "Percussion"],
      ["auscultation", "Auscultation"],
    ],
  },
  {
    key: "respiratory",
    title: "Respiratory System",
    icon: "◉",
    fields: [
      ["inspection", "Inspection"],
      ["palpation", "Palpation"],
      ["percussion", "Percussion"],
      ["auscultation", "Auscultation"],
    ],
  },
  {
    key: "gastrointestinal",
    title: "Gastrointestinal System",
    icon: "◆",
    fields: [
      ["inspection", "Inspection"],
      ["palpation", "Palpation"],
      ["percussion", "Percussion"],
      ["auscultation", "Auscultation"],
    ],
  },
  {
    key: "nervous",
    title: "Nervous System",
    icon: "✦",
    fields: [
      ["higherFunctions", "Higher Functions"],
      ["cranialNerves", "Cranial Nerves"],
      ["motorSystem", "Motor System"],
      ["sensorySystem", "Sensory System"],
      ["reflexes", "Reflexes"],
      ["coordination", "Coordination"],
      ["gait", "Gait"],
    ],
  },
  {
    key: "musculoskeletal",
    title: "Musculoskeletal System",
    icon: "◇",
    fields: [
      ["inspection", "Inspection"],
      ["palpation", "Palpation"],
      ["movements", "Movements"],
      ["musclePower", "Muscle Power"],
      ["joints", "Joints"],
    ],
  },
  {
    key: "genitourinary",
    title: "Genitourinary System",
    icon: "◈",
    fields: [
      ["inspection", "Inspection"],
      ["palpation", "Palpation"],
      ["tenderness", "Tenderness"],
      ["otherFindings", "Other Findings"],
    ],
  },
  {
    key: "endocrine",
    title: "Endocrine System",
    icon: "⬡",
    fields: [
      ["thyroid", "Thyroid"],
      ["lymphNodes", "Lymph Nodes"],
      ["otherFindings", "Other Findings"],
    ],
  },
];

function SystemicExaminationSection({ data = {}, onChange }) {
  const [formData, setFormData] = useState({
    ...initialData,
    ...data,
  });

  const handleChange = (system, field, value) => {
    const updatedData = {
      ...formData,
      [system]: {
        ...formData[system],
        [field]: value,
      },
    };

    setFormData(updatedData);

    if (onChange) {
      onChange(updatedData);
    }
  };

  const handleOtherSystems = (value) => {
    const updatedData = {
      ...formData,
      otherSystems: value,
    };

    setFormData(updatedData);

    if (onChange) {
      onChange(updatedData);
    }
  };

  const resetAll = () => {
    setFormData(initialData);

    if (onChange) {
      onChange(initialData);
    }
  };

  const saveData = () => {
  const assessment = {
    cardiovascular: formData.cardiovascular,
    respiratory: formData.respiratory,
    gastrointestinal: formData.gastrointestinal,
    nervous: formData.nervous,
    musculoskeletal: formData.musculoskeletal,
    genitourinary: formData.genitourinary,
    endocrine: formData.endocrine,
    otherSystems: formData.otherSystems || "",
    assessedFields,
    totalFields,
  };

  const updatedData = {
    ...formData,
    assessment,
  };

  setFormData(updatedData);

  if (onChange) {
    onChange(updatedData);
  }

  alert("Systemic Examination assessment saved successfully.");
};

  

  const totalFields = systems.reduce(
    (total, system) => total + system.fields.length,
    0
  );

  const assessedFields = systems.reduce((total, system) => {
    return (
      total +
      system.fields.filter(
        ([key]) =>
          formData[system.key]?.[key] !== ""
      ).length
    );
  }, 0);

  const getSystemProgress = (system) => {
    const completed = system.fields.filter(
      ([key]) =>
        formData[system.key]?.[key] !== ""
    ).length;

    return `${completed}/${system.fields.length}`;
  };

  return (
    <div className="w-full bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">

      {/* HEADER */}
      <div className="px-6 py-5 bg-gradient-to-r from-emerald-50 to-blue-50 border-b">

        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">

          <div>
            <h2 className="text-2xl font-bold text-slate-800">
              Systemic Examination
            </h2>

            <p className="text-sm text-slate-600 mt-1">
              System-wise clinical examination and observations
            </p>
          </div>

          <div className="bg-white rounded-xl px-4 py-3 border border-emerald-100">

            <p className="text-xs text-slate-500">
              Assessment Progress
            </p>

            <p className="text-lg font-bold text-emerald-700">
              {assessedFields} / {totalFields}
            </p>

          </div>

        </div>
      </div>

      {/* CONTENT */}
      <div className="p-5">

        <div className="grid grid-cols-1 xl:grid-cols-[1fr_320px] gap-5">

          {/* LEFT SIDE */}
          <div className="space-y-5">

            {systems.map((system) => (

              <div
                key={system.key}
                className="border border-slate-200 rounded-xl overflow-hidden"
              >

                {/* SYSTEM HEADER */}
                <div className="px-5 py-4 bg-slate-50 border-b flex items-center justify-between">

                  <div className="flex items-center gap-3">

                    <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center text-xl text-emerald-700">
                      {system.icon}
                    </div>

                    <div>
                      <h3 className="font-bold text-slate-800">
                        {system.title}
                      </h3>

                      <p className="text-xs text-slate-500">
                        Systemic clinical assessment
                      </p>
                    </div>

                  </div>

                  <span className="text-xs font-semibold px-3 py-1 rounded-full bg-white border text-slate-600">
                    {getSystemProgress(system)}
                  </span>

                </div>

                {/* FIELDS */}
                <div className="p-5 grid grid-cols-1 md:grid-cols-2 gap-5">

                  {system.fields.map(([key, label]) => (

                    <div
                      key={key}
                      className={
                        label.includes("System") ||
                        label === "Other Findings"
                          ? "md:col-span-2"
                          : ""
                      }
                    >

                      <label className="block text-sm font-semibold text-slate-700 mb-2">
                        {label}
                      </label>

                      <textarea
                        rows="3"
                        value={
                          formData[system.key]?.[key] || ""
                        }
                        onChange={(e) =>
                          handleChange(
                            system.key,
                            key,
                            e.target.value
                          )
                        }
                        placeholder={`Enter ${label.toLowerCase()} findings...`}
                        className="w-full border border-slate-300 rounded-lg px-3 py-2.5 text-sm outline-none resize-none focus:ring-2 focus:ring-emerald-300"
                      />

                    </div>

                  ))}

                </div>

              </div>

            ))}

            {/* OTHER SYSTEMS */}
            <div className="border border-slate-200 rounded-xl overflow-hidden">

              <div className="px-5 py-4 bg-slate-50 border-b">

                <h3 className="font-bold text-slate-800">
                  Other Systemic Findings
                </h3>

                <p className="text-xs text-slate-500 mt-1">
                  Record findings not covered above
                </p>

              </div>

              <div className="p-5">

                <textarea
                  rows="5"
                  value={formData.otherSystems}
                  onChange={(e) =>
                    handleOtherSystems(e.target.value)
                  }
                  placeholder="Enter additional systemic examination findings..."
                  className="w-full border border-slate-300 rounded-lg px-3 py-3 text-sm outline-none resize-none focus:ring-2 focus:ring-emerald-300"
                />

              </div>

            </div>

          </div>

          {/* RIGHT SIDE */}
          <div className="space-y-4">

            {/* SUMMARY */}
            <div className="border rounded-xl overflow-hidden">

              <div className="px-4 py-3 bg-blue-50 border-b">

                <h3 className="font-bold text-blue-800">
                  Systemic Examination Summary
                </h3>

              </div>

              <div className="p-3 space-y-2">

                {systems.map((system) => {

                  const completed =
                    system.fields.filter(
                      ([key]) =>
                        formData[system.key]?.[key] !== ""
                    ).length;

                  return (
                    <div
                      key={system.key}
                      className="border rounded-lg px-3 py-3"
                    >

                      <div className="flex items-center justify-between">

                        <div className="flex items-center gap-2">

                          <span className="text-lg text-emerald-600">
                            {system.icon}
                          </span>

                          <span className="text-sm font-semibold text-slate-700">
                            {system.title}
                          </span>

                        </div>

                        <span className="text-xs font-bold text-emerald-700">
                          {completed}/
                          {system.fields.length}
                        </span>

                      </div>

                      <div className="mt-2 h-1.5 bg-slate-100 rounded-full overflow-hidden">

                        <div
                          className="h-full bg-emerald-500 rounded-full"
                          style={{
                            width: `${
                              (completed /
                                system.fields.length) *
                              100
                            }%`,
                          }}
                        />

                      </div>

                    </div>
                  );
                })}

              </div>
            </div>

            {/* CLINICAL INSIGHT */}
            <div className="border rounded-xl bg-amber-50 border-amber-200 p-4">

              <h3 className="font-bold text-amber-800 mb-2">
                Clinical Insight
              </h3>

              <p className="text-sm text-slate-700 leading-6">
                Record relevant findings systematically for
                each body system. The examining clinician can
                add detailed observations wherever required.
              </p>

            </div>

            {/* QUICK STATUS */}
            <div className="border rounded-xl bg-emerald-50 border-emerald-200 p-4">

              <h3 className="font-bold text-emerald-800 mb-3">
                Assessment Status
              </h3>

              <div className="space-y-3">

                <div className="flex justify-between">
                  <span className="text-sm text-slate-600">
                    Systems
                  </span>

                  <span className="font-semibold text-slate-800">
                    {systems.length}
                  </span>
                </div>

                <div className="flex justify-between">
                  <span className="text-sm text-slate-600">
                    Completed Fields
                  </span>

                  <span className="font-semibold text-emerald-700">
                    {assessedFields}
                  </span>
                </div>

                <div className="flex justify-between">
                  <span className="text-sm text-slate-600">
                    Remaining
                  </span>

                  <span className="font-semibold text-slate-800">
                    {totalFields - assessedFields}
                  </span>
                </div>

              </div>

            </div>

          </div>

        </div>

        {/* BUTTONS */}
        <div className="flex flex-col sm:flex-row justify-between gap-3 mt-6">

          <button
            type="button"
            onClick={resetAll}
            className="px-6 py-3 border border-slate-300 rounded-xl font-semibold text-slate-700 hover:bg-slate-50"
          >
            ↻ Reset All
          </button>

          <button
            type="button"
            onClick={saveData}
            className="px-7 py-3 rounded-xl font-semibold text-white bg-emerald-600 hover:bg-emerald-700"
          >
            ✓ Save Systemic Examination
          </button>

        </div>

      </div>
    </div>
  );
}

export default SystemicExaminationSection;