import React from "react";

const HistoryPresentIllnessSection = ({ data = {}, onChange }) => {
  const updateField = (field, value) => {
    if (onChange) {
      onChange({
        ...data,
        [field]: value,
      });
    }
  };

  return (
    <section className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">

      {/* Header */}
      <div className="mb-6 flex items-center gap-4">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-100 font-bold text-emerald-700">
          03
        </div>

        <div>
          <h2 className="text-xl font-bold text-slate-800">
            History of Present Illness
          </h2>

          <p className="text-sm text-slate-500">
            Record the development and progression of the present illness.
          </p>
        </div>
      </div>

      <div className="space-y-5">

        {/* Onset */}
        <div>
          <label className="mb-2 block text-sm font-semibold text-slate-600">
            Onset of Illness
          </label>

          <textarea
            value={data.onset || ""}
            onChange={(e) => updateField("onset", e.target.value)}
            placeholder="Describe when and how the illness started..."
            rows={3}
            className="w-full resize-none rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-emerald-400 focus:bg-white focus:ring-2 focus:ring-emerald-100"
          />
        </div>

        {/* Course */}
        <div>
          <label className="mb-2 block text-sm font-semibold text-slate-600">
            Course and Progression
          </label>

          <textarea
            value={data.course || ""}
            onChange={(e) => updateField("course", e.target.value)}
            placeholder="Describe how the condition has progressed over time..."
            rows={4}
            className="w-full resize-none rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-emerald-400 focus:bg-white focus:ring-2 focus:ring-emerald-100"
          />
        </div>

        {/* Associated complaints */}
        <div>
          <label className="mb-2 block text-sm font-semibold text-slate-600">
            Associated Complaints
          </label>

          <textarea
            value={data.associatedComplaints || ""}
            onChange={(e) =>
              updateField("associatedComplaints", e.target.value)
            }
            placeholder="Record other complaints associated with the present illness..."
            rows={3}
            className="w-full resize-none rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-emerald-400 focus:bg-white focus:ring-2 focus:ring-emerald-100"
          />
        </div>

        {/* Aggravating / relieving factors */}
        <div className="grid gap-5 md:grid-cols-2">

          <div>
            <label className="mb-2 block text-sm font-semibold text-slate-600">
              Aggravating Factors
            </label>

            <textarea
              value={data.aggravatingFactors || ""}
              onChange={(e) =>
                updateField("aggravatingFactors", e.target.value)
              }
              placeholder="Factors that worsen the complaint..."
              rows={3}
              className="w-full resize-none rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-emerald-400 focus:bg-white focus:ring-2 focus:ring-emerald-100"
            />
          </div>

          <div>
            <label className="mb-2 block text-sm font-semibold text-slate-600">
              Relieving Factors
            </label>

            <textarea
              value={data.relievingFactors || ""}
              onChange={(e) =>
                updateField("relievingFactors", e.target.value)
              }
              placeholder="Factors that relieve the complaint..."
              rows={3}
              className="w-full resize-none rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-emerald-400 focus:bg-white focus:ring-2 focus:ring-emerald-100"
            />
          </div>

        </div>

        {/* Treatment already taken */}
        <div>
          <label className="mb-2 block text-sm font-semibold text-slate-600">
            Treatment Taken for Present Illness
          </label>

          <textarea
            value={data.previousTreatment || ""}
            onChange={(e) =>
              updateField("previousTreatment", e.target.value)
            }
            placeholder="Record any treatment, medication, or other management already taken..."
            rows={4}
            className="w-full resize-none rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-emerald-400 focus:bg-white focus:ring-2 focus:ring-emerald-100"
          />
        </div>

        {/* Response */}
        <div>
          <label className="mb-2 block text-sm font-semibold text-slate-600">
            Response to Previous Treatment
          </label>

          <textarea
            value={data.treatmentResponse || ""}
            onChange={(e) =>
              updateField("treatmentResponse", e.target.value)
            }
            placeholder="Describe the patient's response to previous treatment..."
            rows={3}
            className="w-full resize-none rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-emerald-400 focus:bg-white focus:ring-2 focus:ring-emerald-100"
          />
        </div>

        {/* Additional details */}
        <div>
          <label className="mb-2 block text-sm font-semibold text-slate-600">
            Additional History
          </label>

          <textarea
            value={data.additionalHistory || ""}
            onChange={(e) =>
              updateField("additionalHistory", e.target.value)
            }
            placeholder="Add any other relevant details about the present illness..."
            rows={4}
            className="w-full resize-none rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-emerald-400 focus:bg-white focus:ring-2 focus:ring-emerald-100"
          />
        </div>

      </div>
    </section>
  );
};

export default HistoryPresentIllnessSection;