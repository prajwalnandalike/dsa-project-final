import React, { useState } from "react";

const initialData = {
  mindDosha: [],
  doshaNotes: "",
  rasaFindings: [],
  raktaFindings: [],
  mamsaFindings: [],
  medaFindings: [],
  asthiFindings: [],
  majjaFindings: [],
  shukraFindings: [],
  purishaFrequency: "",
  purishaConsistency: "",
  purishaColour: "",
  purishaSmell: "",
  constipation: "",
  diarrhoea: "",
  incompleteEvacuation: "",
  swedaQuantity: "",
  swedaDistribution: "",
  swedaSmell: "",
  mutraFrequency: "",
  mutraQuantity: "",
  mutraColour: "",
  mutraBurning: "",
  mutraUrgency: "",
  mutraRetention: "",
  malaNotes: "",
};

const mindDoshas = [
  { key: "Tamas", title: "Tamas", description: "Inertia, dullness, sleep, darkness" },
  { key: "Rajas", title: "Rajas", description: "Momentum, desire, action" },
  { key: "Sattva", title: "Sattva", description: "Peaceful, clear, balanced, steady" },
];

const rasaData = [
  ["Ashraddha", "Disinclination for food"],
  ["Aruchi", "Anorexia"],
  ["Asya Vairasya", "Foul taste in mouth"],
  ["Arasanjnata", "Lack of taste sensing capacity"],
  ["Hrullasa", "Nausea"],
  ["Gaurava", "Heaviness"],
  ["Tandra", "Drowsiness, fatigue"],
  ["Angamarda", "Malaise, bodyache"],
  ["Jwara", "Fever"],
  ["Tama", "Darkness in front of eyes"],
  ["Pandutva", "Anaemia, pale discolouration of skin"],
  ["Srotasam Rodha", "Obstruction of body channels"],
  ["Klaibya", "Impotency"],
  ["Krushangata", "Emaciation, shrunken body parts"],
];

const raktaData = [
  ["Kushta", "Skin diseases"],
  ["Visarpa", "Acute spreading diseases of the skin"],
  ["Pidaka", "Carbuncle, pimples"],
  ["Raktapitta", "Bleeding disorders"],
  ["Asrugdhara", "Menorrhagia, heavy periods"],
  ["Guda Medhra Paka", "Inflammation and suppuration"],
  ["Asya Paka", "Mouth ulcers"],
  ["Pleeha", "Splenomegaly"],
  ["Gulma", "Tumors of the abdomen"],
  ["Vidradhi", "Abscess"],
  ["Neelika", "Blue moles"],
  ["Kaamala", "Jaundice"],
  ["Vyanga", "Freckles"],
  ["Piplava", "Port wine mark"],
  ["Tilakaalaka", "Black mole"],
  ["Dadru", "Ringworm"],
  ["Charmadala", "Dermatitis, skin tags"],
  ["Shvitra", "Leucoderma"],
  ["Pama", "Papules"],
  ["Kotha", "Urticaria"],
  ["Asra Mandala", "Red circular patches"],
];

const mamsaData = [
  ["Adhimamsa", "Granuloma"],
  ["Arbuda", "Myoma"],
  ["Keela", "Piles"],
  ["Gala Shalooka", "Uvulitis"],
  ["Gala Shundika", "Tonsillitis"],
  ["Pootimamsa", "Sloughing of flesh"],
  ["Alaji", "Boils"],
  ["Ganda", "Goiter"],
  ["Gandamala", "Cervical adenitis"],
  ["Upajihvika", "Inflammation of epiglottis"],
];

const medaData = [
  ["Prameha", "Premonitory signs and symptoms of Prameha"],
  ["Urinary tract disorders", "Related urinary tract symptoms"],
  ["Diabetes mellitus", "Related diabetes symptoms"],
];

const asthiData = [
  ["Adhyasthi", "Hypertrophy of the bones"],
  ["Adhi Danta", "Excess teeth"],
  ["Dantabheda", "Cracking sensation in teeth"],
  ["Asthibheda", "Crackling sensation in bone"],
  ["Shoola", "Pain in bone"],
  ["Vivarnata", "Discoloration of hair"],
  ["Hair / nail / beard deformity", "Deformity of hair, nails and beard"],
];

const majjaData = [
  ["Parva Ruk", "Pain in small joints"],
  ["Bhrama", "Delusion, dizziness"],
  ["Murcha", "Fainting, loss of consciousness"],
  ["Tamo Darshana", "Seeing darkness in front of eyes"],
];

const shukraData = [
  ["Klaibya", "Impotent"],
  ["Aharshana", "Lack of erection and enjoyment in sex"],
  ["Progeny", "Possible sick, sterile, short-lived or disfigured progeny"],
  ["Conception", "Difficulty in conception or pregnancy loss"],
  ["Shukra vitiation", "Vitiation of Shukra affecting couple and progeny"],
];

const dhatuGroups = [
  { key: "rasaFindings", title: "Rasa Dhatu", subtitle: "Rasa Dhatu findings", data: rasaData },
  { key: "raktaFindings", title: "Rakta Dhatu", subtitle: "Rakta Pradoshaja Vyadhis", data: raktaData },
  { key: "mamsaFindings", title: "Mamsa Dhatu", subtitle: "Mamsa-related findings", data: mamsaData },
  { key: "medaFindings", title: "Meda Dhatu", subtitle: "Premonitory signs and symptoms", data: medaData },
  { key: "asthiFindings", title: "Asthi Dhatu", subtitle: "Asthi-related findings", data: asthiData },
  { key: "majjaFindings", title: "Majja Dhatu", subtitle: "Majja Pradoshaja Vikara", data: majjaData },
  { key: "shukraFindings", title: "Shukra Dhatu", subtitle: "Shukra-related findings", data: shukraData },
];

function DoshaDhatuMalaSection({ data = {}, onChange }) {
  const [formData, setFormData] = useState({ ...initialData, ...data });
  const [activeTab, setActiveTab] = useState("dosha");

  const updateData = (updatedData) => {
    setFormData(updatedData);
    if (onChange) onChange(updatedData);
  };

  const handleChange = (key, value) => {
    updateData({ ...formData, [key]: value });
  };

  const toggleFinding = (groupKey, value) => {
    const current = formData[groupKey] || [];
    const updated = current.includes(value)
      ? current.filter((item) => item !== value)
      : [...current, value];

    updateData({ ...formData, [groupKey]: updated });
  };

  const resetAll = () => {
    setFormData(initialData);
    if (onChange) onChange(initialData);
  };

  const saveData = () => {
  const assessment = {
    mindDoshas: formData.mindDosha || [],
    mindDoshaCount: selectedMindDosha,
    dhatuFindingsCount: selectedDhatuCount,

    malaSummary: {
      purisha: formData.purishaConsistency || "Not assessed",
      sweda: formData.swedaQuantity || "Not assessed",
      mutra: formData.mutraFrequency || "Not assessed",
    },

    malaFieldsCompleted: malaCompleted,
    totalMalaFields: malaFields.length,
  };

  const updatedData = {
    ...formData,
    assessment,
  };

  setFormData(updatedData);

  if (onChange) {
    onChange(updatedData);
  }

  alert("Dosha, Dhatu & Mala assessment saved successfully.");
};

  const selectedDhatuCount = dhatuGroups.reduce(
    (total, group) => total + (formData[group.key]?.length || 0),
    0
  );

  const selectedMindDosha = formData.mindDosha?.length || 0;

  const malaFields = [
    "purishaFrequency", "purishaConsistency", "purishaColour", "purishaSmell",
    "constipation", "diarrhoea", "incompleteEvacuation",
    "swedaQuantity", "swedaDistribution", "swedaSmell",
    "mutraFrequency", "mutraQuantity", "mutraColour",
    "mutraBurning", "mutraUrgency", "mutraRetention",
  ];

  const malaCompleted = malaFields.filter((key) => formData[key] !== "").length;

  return (
    <div className="w-full bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
      <div className="px-6 py-5 bg-gradient-to-r from-emerald-50 to-blue-50 border-b">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold text-slate-800">Dosha, Dhatu & Mala</h2>
            <p className="text-sm text-slate-600 mt-1">
              Assessment of Mind Doshas, Dhatu findings and Mala
            </p>
          </div>
          <div className="bg-white rounded-xl px-4 py-3 border border-emerald-100">
            <p className="text-xs text-slate-500">Combined Sections</p>
            <p className="text-lg font-bold text-emerald-700">10 • 11 • 12</p>
          </div>
        </div>
      </div>

      <div className="px-5 pt-5">
        <div className="grid grid-cols-3 gap-2 bg-slate-100 rounded-xl p-1">
          {[
            ["dosha", "10. Dosha", "text-emerald-700"],
            ["dhatu", "11. Dhatu", "text-blue-700"],
            ["mala", "12. Mala", "text-amber-700"],
          ].map(([key, label, activeText]) => (
            <button
              key={key}
              type="button"
              onClick={() => setActiveTab(key)}
              className={`py-3 rounded-lg text-sm font-bold ${
                activeTab === key
                  ? `bg-white ${activeText} shadow-sm`
                  : "text-slate-600"
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      <div className="p-5">
        {activeTab === "dosha" && (
          <div className="grid grid-cols-1 xl:grid-cols-[1fr_320px] gap-5">
            <div className="border rounded-xl overflow-hidden">
              <div className="px-5 py-4 bg-slate-50 border-b">
                <h3 className="font-bold text-slate-800">3 Mind Doshas</h3>
                <p className="text-xs text-slate-500 mt-1">
                  Select the observed mental state
                </p>
              </div>

              <div className="p-5 space-y-4">
                {mindDoshas.map((dosha) => (
                  <label
                    key={dosha.key}
                    className={`flex gap-4 p-4 border rounded-xl cursor-pointer ${
                      formData.mindDosha.includes(dosha.key)
                        ? "border-emerald-400 bg-emerald-50"
                        : "border-slate-200 bg-white"
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={formData.mindDosha.includes(dosha.key)}
                      onChange={() => toggleFinding("mindDosha", dosha.key)}
                      className="mt-1 w-4 h-4"
                    />
                    <div>
                      <h4 className="font-bold text-slate-800">{dosha.title}</h4>
                      <p className="text-sm text-slate-600 mt-1">{dosha.description}</p>
                    </div>
                  </label>
                ))}

                <div className="pt-2">
                  <label className="block text-sm font-semibold text-slate-700 mb-2">
                    Doctor's Dosha Assessment
                  </label>
                  <textarea
                    rows="6"
                    value={formData.doshaNotes}
                    onChange={(e) => handleChange("doshaNotes", e.target.value)}
                    placeholder="Enter the doctor's Dosha assessment and clinical observations..."
                    className="w-full border border-slate-300 rounded-xl px-4 py-3 text-sm resize-y outline-none focus:ring-2 focus:ring-emerald-300"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="border rounded-xl overflow-hidden">
                <div className="px-4 py-3 bg-emerald-50 border-b">
                  <h3 className="font-bold text-emerald-800">Dosha Summary</h3>
                </div>

                <div className="p-4">
                  {mindDoshas.map((dosha) => (
                    <div key={dosha.key} className="flex items-center justify-between py-3 border-b last:border-b-0">
                      <span className="font-semibold text-slate-700">{dosha.title}</span>
                      <span className={`text-xs px-3 py-1 rounded-full ${
                        formData.mindDosha.includes(dosha.key)
                          ? "bg-emerald-100 text-emerald-700"
                          : "bg-slate-100 text-slate-500"
                      }`}>
                        {formData.mindDosha.includes(dosha.key) ? "Selected" : "Not selected"}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="border rounded-xl bg-blue-50 border-blue-200 p-4">
                <h3 className="font-bold text-blue-800 mb-2">Assessment</h3>
                <p className="text-sm text-slate-700">
                  Mind Doshas selected: <strong>{selectedMindDosha}</strong>
                </p>
              </div>
            </div>
          </div>
        )}

        {activeTab === "dhatu" && (
          <div className="grid grid-cols-1 xl:grid-cols-[1fr_320px] gap-5">
            <div className="space-y-5">
              {dhatuGroups.map((group) => (
                <div key={group.key} className="border rounded-xl overflow-hidden">
                  <div className="px-5 py-4 bg-slate-50 border-b flex justify-between items-center">
                    <div>
                      <h3 className="font-bold text-slate-800">{group.title}</h3>
                      <p className="text-xs text-slate-500 mt-1">{group.subtitle}</p>
                    </div>
                    <span className="text-xs font-bold text-blue-700">
                      {formData[group.key]?.length || 0} selected
                    </span>
                  </div>

                  <div className="p-5 grid grid-cols-1 md:grid-cols-2 gap-3">
                    {group.data.map(([term, meaning]) => (
                      <label
                        key={term}
                        className={`flex gap-3 p-3 border rounded-lg cursor-pointer ${
                          formData[group.key]?.includes(term)
                            ? "bg-blue-50 border-blue-300"
                            : "bg-white border-slate-200"
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={formData[group.key]?.includes(term) || false}
                          onChange={() => toggleFinding(group.key, term)}
                          className="mt-1 w-4 h-4"
                        />
                        <div>
                          <p className="font-semibold text-sm text-slate-800">{term}</p>
                          <p className="text-xs text-slate-500 mt-1">{meaning}</p>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <div className="space-y-4">
              <div className="border rounded-xl overflow-hidden">
                <div className="px-4 py-3 bg-blue-50 border-b">
                  <h3 className="font-bold text-blue-800">Dhatu Summary</h3>
                </div>

                <div className="p-3 space-y-2">
                  {dhatuGroups.map((group) => (
                    <div key={group.key} className="flex justify-between items-center border rounded-lg px-3 py-3">
                      <span className="text-sm font-semibold text-slate-700">
                        {group.title.replace(" Dhatu", "")}
                      </span>
                      <span className="text-xs font-bold text-blue-700">
                        {formData[group.key]?.length || 0}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="border rounded-xl bg-amber-50 border-amber-200 p-4">
                <h3 className="font-bold text-amber-800 mb-2">Selected Findings</h3>
                <p className="text-sm text-slate-700">
                  Total selected Dhatu findings: <strong>{selectedDhatuCount}</strong>
                </p>
              </div>
            </div>
          </div>
        )}

        {activeTab === "mala" && (
          <div className="grid grid-cols-1 xl:grid-cols-[1fr_320px] gap-5">
            <div className="space-y-5">
              <div className="border rounded-xl overflow-hidden">
                <div className="px-5 py-4 bg-amber-50 border-b">
                  <h3 className="font-bold text-amber-800">Purisha</h3>
                  <p className="text-xs text-slate-500">Stool examination</p>
                </div>

                <div className="p-5 grid grid-cols-1 md:grid-cols-2 gap-5">
                  <SelectField label="Frequency" value={formData.purishaFrequency}
                    options={["Normal", "Increased", "Reduced"]}
                    onChange={(value) => handleChange("purishaFrequency", value)} />

                  <SelectField label="Consistency" value={formData.purishaConsistency}
                    options={["Normal", "Hard", "Loose", "Watery", "Mixed"]}
                    onChange={(value) => handleChange("purishaConsistency", value)} />

                  <SelectField label="Colour" value={formData.purishaColour}
                    options={["Normal", "Dark", "Yellow", "Pale", "Other"]}
                    onChange={(value) => handleChange("purishaColour", value)} />

                  <SelectField label="Smell" value={formData.purishaSmell}
                    options={["Normal", "Foul", "Strong", "Other"]}
                    onChange={(value) => handleChange("purishaSmell", value)} />

                  <SelectField label="Constipation" value={formData.constipation}
                    options={["Absent", "Present"]}
                    onChange={(value) => handleChange("constipation", value)} />

                  <SelectField label="Diarrhoea" value={formData.diarrhoea}
                    options={["Absent", "Present"]}
                    onChange={(value) => handleChange("diarrhoea", value)} />

                  <SelectField label="Incomplete Evacuation" value={formData.incompleteEvacuation}
                    options={["Absent", "Present"]}
                    onChange={(value) => handleChange("incompleteEvacuation", value)} />
                </div>
              </div>

              <div className="border rounded-xl overflow-hidden">
                <div className="px-5 py-4 bg-blue-50 border-b">
                  <h3 className="font-bold text-blue-800">Sweda</h3>
                  <p className="text-xs text-slate-500">Sweat examination</p>
                </div>

                <div className="p-5 grid grid-cols-1 md:grid-cols-2 gap-5">
                  <SelectField label="Sweating" value={formData.swedaQuantity}
                    options={["Normal", "Excessive sweating", "Reduced sweating"]}
                    onChange={(value) => handleChange("swedaQuantity", value)} />

                  <SelectField label="Distribution" value={formData.swedaDistribution}
                    options={["Normal", "Localized", "Generalized", "Unequal"]}
                    onChange={(value) => handleChange("swedaDistribution", value)} />

                  <SelectField label="Smell" value={formData.swedaSmell}
                    options={["Normal", "Abnormal", "Strong", "Other"]}
                    onChange={(value) => handleChange("swedaSmell", value)} />
                </div>
              </div>

              <div className="border rounded-xl overflow-hidden">
                <div className="px-5 py-4 bg-emerald-50 border-b">
                  <h3 className="font-bold text-emerald-800">Mutra</h3>
                  <p className="text-xs text-slate-500">Urine examination</p>
                </div>

                <div className="p-5 grid grid-cols-1 md:grid-cols-2 gap-5">
                  <SelectField label="Frequency" value={formData.mutraFrequency}
                    options={["Normal", "Increased", "Reduced"]}
                    onChange={(value) => handleChange("mutraFrequency", value)} />

                  <SelectField label="Quantity" value={formData.mutraQuantity}
                    options={["Normal", "Increased", "Reduced"]}
                    onChange={(value) => handleChange("mutraQuantity", value)} />

                  <SelectField label="Colour" value={formData.mutraColour}
                    options={["Normal", "Pale", "Dark", "Yellow", "Other"]}
                    onChange={(value) => handleChange("mutraColour", value)} />

                  <SelectField label="Burning" value={formData.mutraBurning}
                    options={["Absent", "Present"]}
                    onChange={(value) => handleChange("mutraBurning", value)} />

                  <SelectField label="Urgency" value={formData.mutraUrgency}
                    options={["Absent", "Present"]}
                    onChange={(value) => handleChange("mutraUrgency", value)} />

                  <SelectField label="Retention" value={formData.mutraRetention}
                    options={["Absent", "Present"]}
                    onChange={(value) => handleChange("mutraRetention", value)} />
                </div>
              </div>

              <div className="border rounded-xl overflow-hidden">
                <div className="px-5 py-4 bg-slate-50 border-b">
                  <h3 className="font-bold text-slate-800">Mala Clinical Notes</h3>
                </div>

                <div className="p-5">
                  <textarea
                    rows="5"
                    value={formData.malaNotes}
                    onChange={(e) => handleChange("malaNotes", e.target.value)}
                    placeholder="Enter additional observations related to Purisha, Sweda and Mutra..."
                    className="w-full border border-slate-300 rounded-xl px-4 py-3 text-sm resize-y outline-none focus:ring-2 focus:ring-emerald-300"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="border rounded-xl overflow-hidden">
                <div className="px-4 py-3 bg-amber-50 border-b">
                  <h3 className="font-bold text-amber-800">Mala Summary</h3>
                </div>

                <div className="p-4 space-y-3">
                  <SummaryItem label="Purisha" value={formData.purishaConsistency || "Not assessed"} />
                  <SummaryItem label="Sweda" value={formData.swedaQuantity || "Not assessed"} />
                  <SummaryItem label="Mutra" value={formData.mutraFrequency || "Not assessed"} />
                </div>
              </div>

              <div className="border rounded-xl bg-blue-50 border-blue-200 p-4">
                <h3 className="font-bold text-blue-800 mb-2">Assessment Progress</h3>
                <p className="text-sm text-slate-700">
                  {malaCompleted} / {malaFields.length} Mala fields completed
                </p>
              </div>
            </div>
          </div>
        )}

        <div className="flex flex-col sm:flex-row justify-between gap-3 mt-6">
          <button
            type="button"
            onClick={resetAll}
            className="px-6 py-3 border border-slate-300 rounded-xl font-semibold text-slate-700 hover:bg-slate-50"
          >
            ↻ Reset All
          </button>

          <button
            type="button"
            onClick={saveData}
            className="px-7 py-3 rounded-xl font-semibold text-white bg-emerald-600 hover:bg-emerald-700"
          >
            ✓ Save Dosha, Dhatu & Mala
          </button>
        </div>
      </div>
    </div>
  );
}

function SelectField({ label, value, options, onChange }) {
  return (
    <div>
      <label className="block text-sm font-semibold text-slate-700 mb-2">{label}</label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full border border-slate-300 rounded-lg px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-emerald-300"
      >
        <option value="">Select</option>
        {options.map((option) => (
          <option key={option} value={option}>{option}</option>
        ))}
      </select>
    </div>
  );
}

function SummaryItem({ label, value }) {
  return (
    <div className="flex items-center justify-between gap-3 border rounded-lg px-3 py-3">
      <span className="text-sm font-semibold text-slate-700">{label}</span>
      <span className="text-xs text-right text-slate-500">{value}</span>
    </div>
  );
}

export default DoshaDhatuMalaSection;
