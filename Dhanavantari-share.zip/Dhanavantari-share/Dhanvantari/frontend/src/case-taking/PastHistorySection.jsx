import React, { useState } from "react";

const illnessOptions = [
  "Diabetes Mellitus",
  "Hypertension",
  "Heart Disease",
  "Kidney Disease",
  "Liver Disease",
  "Respiratory Disease",
  "Thyroid Disease",
  "Neurological Disease",
  "Gastrointestinal Disease",
  "Psychiatric Illness",
  "Infectious Diseases",
];

const allergyOptions = [
  "Drug Allergy",
  "Food Allergy",
  "Environmental Allergy",
  "Other Allergy",
];

const PastHistorySection = ({ data = {}, onChange }) => {
  const [formData, setFormData] = useState(data);

  const updateField = (field, value) => {
    const updated = {
      ...formData,
      [field]: value,
    };

    setFormData(updated);

    if (onChange) {
      onChange(updated);
    }
  };

  const toggleMultiSelect = (field, value) => {
    const current = formData[field] || [];

    const updated = current.includes(value)
      ? current.filter((item) => item !== value)
      : [...current, value];

    updateField(field, updated);
  };

  return (
    <section className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">

      {/* Header */}
      <div className="mb-6 flex items-center gap-4">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-100 font-bold text-emerald-700">
          04
        </div>

        <div>
          <h2 className="text-xl font-bold text-slate-800">
            Past History
          </h2>

          <p className="text-sm text-slate-500">
            Record previous illnesses, treatments, procedures and other significant history.
          </p>
        </div>
      </div>

      {/* Previous Illnesses */}
      <div className="mb-6 rounded-xl border border-slate-200 bg-slate-50 p-5">

        <h3 className="mb-4 font-bold text-slate-700">
          Previous Illnesses
        </h3>

        <label className="mb-3 block text-sm font-semibold text-slate-600">
          Select applicable illnesses
        </label>

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">

          {illnessOptions.map((illness) => (
            <label
              key={illness}
              className="flex cursor-pointer items-center gap-3 rounded-lg border border-slate-200 bg-white p-3 transition hover:border-emerald-300"
            >
              <input
                type="checkbox"
                checked={(formData.previousIllnesses || []).includes(illness)}
                onChange={() =>
                  toggleMultiSelect("previousIllnesses", illness)
                }
                className="h-4 w-4 accent-emerald-600"
              />

              <span className="text-sm text-slate-700">
                {illness}
              </span>
            </label>
          ))}

        </div>

        {/* Other Illness */}
        <div className="mt-4">
          <label className="mb-2 block text-sm font-semibold text-slate-600">
            Other Illnesses
          </label>

          <input
            type="text"
            value={formData.otherIllnesses || ""}
            onChange={(e) =>
              updateField("otherIllnesses", e.target.value)
            }
            placeholder="Enter any other previous illness"
            className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100"
          />
        </div>
      </div>

      {/* Hospitalization */}
      <YesNoSection
        title="Previous Hospitalization"
        value={formData.previousHospitalization}
        onChange={(value) =>
          updateField("previousHospitalization", value)
        }
      />

      {formData.previousHospitalization === "yes" && (
        <div className="mb-6 grid gap-5 rounded-xl border border-emerald-100 bg-emerald-50/40 p-5 md:grid-cols-2">

          <Input
            label="Hospital Name"
            value={formData.hospitalName}
            onChange={(value) =>
              updateField("hospitalName", value)
            }
            placeholder="Enter hospital name"
          />

          <Input
            label="Date / Year"
            value={formData.hospitalizationDate}
            onChange={(value) =>
              updateField("hospitalizationDate", value)
            }
            placeholder="e.g. 2023"
          />

          <div className="md:col-span-2">
            <Textarea
              label="Reason"
              value={formData.hospitalizationReason}
              onChange={(value) =>
                updateField("hospitalizationReason", value)
              }
              placeholder="Reason for hospitalization"
            />
          </div>

          <div className="md:col-span-2">
            <Textarea
              label="Treatment Received"
              value={formData.hospitalizationTreatment}
              onChange={(value) =>
                updateField("hospitalizationTreatment", value)
              }
              placeholder="Describe treatment received"
            />
          </div>

        </div>
      )}

      {/* Surgeries */}
      <YesNoSection
        title="Previous Surgeries"
        value={formData.previousSurgery}
        onChange={(value) =>
          updateField("previousSurgery", value)
        }
      />

      {formData.previousSurgery === "yes" && (
        <div className="mb-6 grid gap-5 rounded-xl border border-emerald-100 bg-emerald-50/40 p-5 md:grid-cols-2">

          <Input
            label="Type of Surgery"
            value={formData.surgeryType}
            onChange={(value) =>
              updateField("surgeryType", value)
            }
            placeholder="Enter type of surgery"
          />

          <Input
            label="Date / Year"
            value={formData.surgeryDate}
            onChange={(value) =>
              updateField("surgeryDate", value)
            }
            placeholder="e.g. 2021"
          />

          <div className="md:col-span-2">
            <Textarea
              label="Reason"
              value={formData.surgeryReason}
              onChange={(value) =>
                updateField("surgeryReason", value)
              }
              placeholder="Reason for surgery"
            />
          </div>

          <div className="md:col-span-2">
            <Textarea
              label="Outcome"
              value={formData.surgeryOutcome}
              onChange={(value) =>
                updateField("surgeryOutcome", value)
              }
              placeholder="Describe the outcome"
            />
          </div>

        </div>
      )}

      {/* Injuries */}
      <YesNoSection
        title="Previous Injuries / Trauma"
        value={formData.previousTrauma}
        onChange={(value) =>
          updateField("previousTrauma", value)
        }
      />

      {formData.previousTrauma === "yes" && (
        <div className="mb-6 grid gap-5 rounded-xl border border-emerald-100 bg-emerald-50/40 p-5 md:grid-cols-2">

          <Input
            label="Type of Injury"
            value={formData.injuryType}
            onChange={(value) =>
              updateField("injuryType", value)
            }
            placeholder="e.g. fracture, accident"
          />

          <Input
            label="Site"
            value={formData.injurySite}
            onChange={(value) =>
              updateField("injurySite", value)
            }
            placeholder="Body site"
          />

          <Input
            label="Date / Year"
            value={formData.injuryDate}
            onChange={(value) =>
              updateField("injuryDate", value)
            }
            placeholder="e.g. 2020"
          />

          <Textarea
            label="Treatment"
            value={formData.injuryTreatment}
            onChange={(value) =>
              updateField("injuryTreatment", value)
            }
            placeholder="Treatment received"
          />

        </div>
      )}

      {/* Previous Medications */}
      <YesNoSection
        title="Previous Medications"
        value={formData.previousMedications}
        onChange={(value) =>
          updateField("previousMedications", value)
        }
      />

      {formData.previousMedications === "yes" && (
        <div className="mb-6 rounded-xl border border-emerald-100 bg-emerald-50/40 p-5">

          <div className="grid gap-5 md:grid-cols-2">

            <Input
              label="Medicine Name"
              value={formData.medicineName}
              onChange={(value) =>
                updateField("medicineName", value)
              }
              placeholder="Enter medicine name"
            />

            <Input
              label="Dose"
              value={formData.medicineDose}
              onChange={(value) =>
                updateField("medicineDose", value)
              }
              placeholder="Enter dose"
            />

            <Input
              label="Duration"
              value={formData.medicineDuration}
              onChange={(value) =>
                updateField("medicineDuration", value)
              }
              placeholder="e.g. 10 days"
            />

            <Input
              label="Reason"
              value={formData.medicineReason}
              onChange={(value) =>
                updateField("medicineReason", value)
              }
              placeholder="Reason for medication"
            />

          </div>
        </div>
      )}

      {/* Allergies */}
      <YesNoSection
        title="Allergies"
        value={formData.hasAllergies}
        onChange={(value) =>
          updateField("hasAllergies", value)
        }
      />

      {formData.hasAllergies === "yes" && (
        <div className="mb-6 rounded-xl border border-emerald-100 bg-emerald-50/40 p-5">

          <label className="mb-3 block text-sm font-semibold text-slate-600">
            Allergy Type
          </label>

          <div className="grid gap-3 sm:grid-cols-2">

            {allergyOptions.map((allergy) => (
              <label
                key={allergy}
                className="flex cursor-pointer items-center gap-3 rounded-lg border border-slate-200 bg-white p-3"
              >
                <input
                  type="checkbox"
                  checked={(formData.allergyTypes || []).includes(allergy)}
                  onChange={() =>
                    toggleMultiSelect("allergyTypes", allergy)
                  }
                  className="h-4 w-4 accent-emerald-600"
                />

                <span className="text-sm text-slate-700">
                  {allergy}
                </span>
              </label>
            ))}

          </div>

          <div className="mt-4">
            <Textarea
              label="Allergy Details"
              value={formData.allergyDetails}
              onChange={(value) =>
                updateField("allergyDetails", value)
              }
              placeholder="Specify allergen and reaction, if known"
            />
          </div>

        </div>
      )}

      {/* Blood Transfusion */}
      <YesNoSection
        title="Previous Blood Transfusion"
        value={formData.bloodTransfusion}
        onChange={(value) =>
          updateField("bloodTransfusion", value)
        }
      />

      {formData.bloodTransfusion === "yes" && (
        <div className="mb-6 grid gap-5 rounded-xl border border-emerald-100 bg-emerald-50/40 p-5 md:grid-cols-2">

          <Input
            label="Reason"
            value={formData.transfusionReason}
            onChange={(value) =>
              updateField("transfusionReason", value)
            }
            placeholder="Reason for transfusion"
          />

          <Input
            label="Date / Year"
            value={formData.transfusionDate}
            onChange={(value) =>
              updateField("transfusionDate", value)
            }
            placeholder="e.g. 2022"
          />

        </div>
      )}

      {/* Other Significant History */}
      <div className="rounded-xl border border-slate-200 bg-slate-50 p-5">

        <h3 className="mb-4 font-bold text-slate-700">
          Other Significant History
        </h3>

        <Textarea
          label="Details"
          value={formData.otherSignificantHistory}
          onChange={(value) =>
            updateField("otherSignificantHistory", value)
          }
          placeholder="Record any other significant history..."
        />

      </div>

    </section>
  );
};


/* Yes / No component */
const YesNoSection = ({ title, value, onChange }) => {
  return (
    <div className="mb-4 rounded-xl border border-slate-200 bg-slate-50 p-5">

      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">

        <h3 className="font-bold text-slate-700">
          {title}
        </h3>

        <div className="flex gap-3">

          <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2">
            <input
              type="radio"
              name={title}
              checked={value === "yes"}
              onChange={() => onChange("yes")}
              className="accent-emerald-600"
            />
            <span className="text-sm font-medium">Yes</span>
          </label>

          <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2">
            <input
              type="radio"
              name={title}
              checked={value === "no"}
              onChange={() => onChange("no")}
              className="accent-emerald-600"
            />
            <span className="text-sm font-medium">No</span>
          </label>

        </div>

      </div>
    </div>
  );
};


/* Input */
const Input = ({ label, value, onChange, placeholder }) => {
  return (
    <div>
      <label className="mb-2 block text-sm font-semibold text-slate-600">
        {label}
      </label>

      <input
        type="text"
        value={value || ""}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100"
      />
    </div>
  );
};


/* Textarea */
const Textarea = ({ label, value, onChange, placeholder }) => {
  return (
    <div>
      <label className="mb-2 block text-sm font-semibold text-slate-600">
        {label}
      </label>

      <textarea
        value={value || ""}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        rows={3}
        className="w-full resize-none rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100"
      />
    </div>
  );
};

export default PastHistorySection;