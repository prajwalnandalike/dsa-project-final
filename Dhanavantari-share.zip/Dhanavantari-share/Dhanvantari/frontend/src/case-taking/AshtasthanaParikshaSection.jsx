import React, { useState } from "react";

const nadiData = [
  {
    value: "Vataja Nadi",
    label: "Vataja Nadi",
    reference: "Snake and leech",
  },
  {
    value: "Pittaja Nadi",
    label: "Pittaja Nadi",
    reference: "Crow, lark and frog",
  },
  {
    value: "Kaphaja Nadi",
    label: "Kaphaja Nadi",
    reference: "Swan, pigeon and cock",
  },
  {
    value: "Vata-Kaphaja Nadi",
    label: "Vata-Kaphaja Nadi",
    reference: "Snake and swan",
  },
  {
    value: "Pitta-Kaphaja Nadi",
    label: "Pitta-Kaphaja Nadi",
    reference: "Monkey and swan",
  },
  {
    value: "Vata-Pittaja Nadi",
    label: "Vata-Pittaja Nadi",
    reference: "Snake and frog",
  },
  {
    value: "Sannipatja Nadi",
    label: "Sannipatja Nadi",
    reference: "Wood pecker",
  },
];

const mutraData = [
  {
    value: "Pandu",
    label: "Pandu (Vata)",
    reference: "Vata – Pandu",
  },
  {
    value: "Phenayukta",
    label: "Phenayukta (Kapha)",
    reference: "Kapha – Phenayukta",
  },
  {
    value: "Rakta",
    label: "Rakta (Pitta)",
    reference: "Pitta – Rakta",
  },
  {
    value: "Mixed",
    label: "Mixed (Dwandaja)",
    reference: "Mixed / as per predominant dosha",
  },
  {
    value: "Krishna",
    label: "Krishna (Sannipataja)",
    reference: "Sannipataja – Krishna",
  },
];

const malaData = [
  {
    value: "Dridha-Shushka",
    label: "Dridha, Shushka (Vata)",
    reference: "Vata vikara – hard and dry",
  },
  {
    value: "Peeta",
    label: "Peeta (Pitta)",
    reference: "Pitta vikara – yellowish",
  },
  {
    value: "Shweta",
    label: "Shweta (Kapha)",
    reference: "Kapha vikara – white",
  },
  {
    value: "SarvaLakshana",
    label: "Sarva lakshana (Tridosha)",
    reference: "Tridosha – all symptoms",
  },
  {
    value: "Trutita-Fenila-Ruksha-Dhumala",
    label: "Trutita, Fenila, Ruksha, Dhumala",
    reference: "Vata prakopa – broken, frothy, dry, smoky",
  },
  {
    value: "Kapisha",
    label: "Kapisha (Vata-Kapha)",
    reference: "Vata-Kapha",
  },
  {
    value: "Baddha-Trutita-Peeta-Shyam",
    label: "Baddha, Trutita, Peeta, Shyam",
    reference: "Pitta-Vata – binding, broken, yellowish, dark",
  },
  {
    value: "Peeta-Sweta-Ishat-Sandra-Picchhila",
    label: "Peeta, Sweta, Ishat Sandra, Picchhila",
    reference: "Kapha-Pitta – yellowish, white, slightly dense, slimy",
  },
  {
    value: "Shyama-Trutita-Pittabha-Baddha-Sweta",
    label: "Shyama, Trutita, Pittabha, Baddha, Sweta",
    reference: "Tridoshaja",
  },
];

const jihvaData = [
  {
    value: "Vataja",
    label: "Cold, rough and cracked",
    reference: "Vataja – brown or black",
  },
  {
    value: "Pittaja",
    label: "Reddish and blackish",
    reference: "Pittaja",
  },
  {
    value: "Kaphaja",
    label: "Whitish and sticky",
    reference: "Kaphaja",
  },
  {
    value: "Sannipataja",
    label: "Blackish, Kantaka (thorny) and dry",
    reference: "Sannipataja",
  },
  {
    value: "Dwandaja",
    label: "Mixed symptoms and sign",
    reference: "Dwandaja",
  },
];

const shabdaData = [
  {
    value: "Guru",
    label: "Guru (heavy)",
    reference: "Kapha",
  },
  {
    value: "SphutaVakhtra",
    label: "Sphuta vaktra (cracked)",
    reference: "Pitta",
  },
  {
    value: "Loose-Rough",
    label: "Devoid of these two qualities (loose or rough)",
    reference: "Vata",
  },
];

const sparshaData = [
  {
    value: "Cold-Rough",
    label: "Cold and rough",
    reference: "Vataja",
  },
  {
    value: "Hot-Moist",
    label: "Hot and moist",
    reference: "Pittaja",
  },
  {
    value: "Wet-Cold",
    label: "Wet and cold",
    reference: "Kaphaja",
  },
];

const drikaData = [
  {
    value: "Vata",
    label: "Vata",
    reference:
      "Dhumra (smoky), Aruna (pink), Nila (blue), Ruksha (dry), Chanchala (unsteady), Antapravista (sunken), Roudra (terrifying), Antarjwala (glowy inside)",
  },
  {
    value: "Pitta",
    label: "Pitta",
    reference:
      "Aruna (pink), Haridra (yellow), Rakta (red), Malina (dirty), Tikshna (penetrating), Dipa dwesha (dislikes light), Dahayukta (burning)",
  },
  {
    value: "Kapha",
    label: "Kapha",
    reference:
      "Sweta (whitish), Dhavala (glistening), Pluta (watery), Snigdha (greasy), Sthira (steady), Santa (affectionate), Jyotish (lustreless), Kandyukta (itchy)",
  },
  {
    value: "Dwandaja",
    label: "Dwandaja",
    reference: "Mixed lakshana of involved Dosha",
  },
  {
    value: "Sannipataja",
    label: "Sannipataja",
    reference: "Rakta (red), Roudra (horrifying), sunken and lustreless",
  },
];

const akritiData = [
  {
    value: "Kapha",
    label: "Kapha",
    reference:
      "Saumya, snigdha, well built body and joints, tolerant to hunger, thirst, hardship, hot sun.",
  },
  {
    value: "Pitta",
    label: "Pittaja",
    reference:
      "Hungry and thirsty, fair in colour, brave, Swabhimani, less hair",
  },
  {
    value: "Vata",
    label: "Vataja",
    reference:
      "Vibhu, ashukari, balvana, prone to many diseases, split hair and dry skin with Dhusara Varna, dislikes cold, Pralapa, unstable Dhriti, Smriti, Buddhi, Cheshta etc.",
  },
];

const initialData = {
  nadi: "",
  mutra: "",
  mala: "",
  jihva: "",
  shabda: "",
  sparsha: "",
  drika: "",
  akriti: "",
  sparshaNotes: "",
  drikaNotes: "",
  akritiNotes: "",
};

const examinationRows = [
  {
    key: "nadi",
    number: 1,
    title: "Nadi",
    subtitle: "Pulse examination",
    icon: "〽",
  },
  {
    key: "mutra",
    number: 2,
    title: "Mutra",
    subtitle: "Urine examination",
    icon: "💧",
  },
  {
    key: "mala",
    number: 3,
    title: "Mala",
    subtitle: "Stool examination",
    icon: "▰",
  },
  {
    key: "jihva",
    number: 4,
    title: "Jihva",
    subtitle: "Tongue examination",
    icon: "👅",
  },
  {
    key: "shabda",
    number: 5,
    title: "Shabda",
    subtitle: "Voice examination",
    icon: "🔊",
  },
  {
    key: "sparsha",
    number: 6,
    title: "Sparsha",
    subtitle: "Touch examination",
    icon: "✋",
  },
  {
    key: "drika",
    number: 7,
    title: "Drika",
    subtitle: "Eye examination",
    icon: "👁",
  },
  {
    key: "akriti",
    number: 8,
    title: "Akriti",
    subtitle: "Body appearance",
    icon: "♙",
  },
];

function AshtasthanaParikshaSection({ data = {}, onChange }) {
  const [formData, setFormData] = useState({
    ...initialData,
    ...data,
  });

  const handleChange = (key, value) => {
    const updatedData = {
      ...formData,
      [key]: value,
    };

    setFormData(updatedData);

    if (onChange) {
      onChange(updatedData);
    }
  };

  const resetAll = () => {
    setFormData(initialData);

    if (onChange) {
      onChange(initialData);
    }
  };
const saveData = () => {
  const assessment = {
    nadi: formData.nadi || "Not assessed",
    mutra: formData.mutra || "Not assessed",
    mala: formData.mala || "Not assessed",
    jihva: formData.jihva || "Not assessed",
    shabda: formData.shabda || "Not assessed",
    sparsha: formData.sparsha || "Not assessed",
    drika: formData.drika || "Not assessed",
    akriti: formData.akriti || "Not assessed",
    assessedCount,
  };

  const updatedData = {
    ...formData,
    assessment,
  };

  setFormData(updatedData);

  if (onChange) {
    onChange(updatedData);
  }

  alert("Ashtasthana Pariksha assessment saved successfully.");
};
  

  const getOptions = (key) => {
    switch (key) {
      case "nadi":
        return nadiData;

      case "mutra":
        return mutraData;

      case "mala":
        return malaData;

      case "jihva":
        return jihvaData;

      case "shabda":
        return shabdaData;

      case "sparsha":
        return sparshaData;

      case "drika":
        return drikaData;

      case "akriti":
        return akritiData;

      default:
        return [];
    }
  };

  const getSelectedReference = (key) => {
    const options = getOptions(key);

    const selected = options.find(
      (item) => item.value === formData[key]
    );

    return selected?.reference || "";
  };

  const assessedCount = Object.keys(initialData).filter(
    (key) =>
      [
        "nadi",
        "mutra",
        "mala",
        "jihva",
        "shabda",
        "sparsha",
        "drika",
        "akriti",
      ].includes(key) && formData[key]
  ).length;

  return (
    <div className="w-full bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">

      {/* HEADER */}
      <div className="px-6 py-5 bg-gradient-to-r from-emerald-50 to-blue-50 border-b">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">

          <div>
            <h2 className="text-2xl font-bold text-slate-800">
              Ashtasthana Pariksha
            </h2>

            <p className="text-sm text-slate-600 mt-1">
              Eight-fold examination: Nadi, Mutra, Mala, Jihva,
              Shabda, Sparsha, Drika and Akriti
            </p>
          </div>

          <div className="bg-white rounded-xl px-4 py-3 border border-emerald-100">
            <p className="text-xs text-slate-500">
              Assessment Progress
            </p>

            <p className="text-lg font-bold text-emerald-700">
              {assessedCount} / 8
            </p>
          </div>

        </div>
      </div>

      {/* MAIN CONTENT */}
      <div className="p-5">

        <div className="grid grid-cols-1 xl:grid-cols-[1fr_330px] gap-5">

          {/* LEFT */}
          <div className="border rounded-xl overflow-hidden">

            {/* TABLE HEADER */}
            <div className="hidden lg:grid grid-cols-[55px_160px_220px_1fr] bg-slate-100 border-b text-sm font-semibold text-slate-700">

              <div className="p-3">#</div>

              <div className="p-3">
                Parameter
              </div>

              <div className="p-3">
                Observation
              </div>

              <div className="p-3">
                Reference / Findings
              </div>

            </div>

            {/* ROWS */}
            {examinationRows.map((row) => {
              const options = getOptions(row.key);

              return (
                <div
                  key={row.key}
                  className="grid grid-cols-1 lg:grid-cols-[55px_160px_220px_1fr] border-b last:border-b-0"
                >

                  {/* NUMBER */}
                  <div className="p-4 bg-slate-50 font-bold text-slate-600">
                    {row.number}
                  </div>

                  {/* PARAMETER */}
                  <div className="p-4 bg-slate-50">

                    <div className="text-emerald-700 text-2xl mb-1">
                      {row.icon}
                    </div>

                    <h3 className="font-bold text-slate-800">
                      {row.title}
                    </h3>

                    <p className="text-xs text-slate-500 mt-1">
                      {row.subtitle}
                    </p>

                  </div>

                  {/* OBSERVATION */}
                  <div className="p-4">

                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      {row.key === "nadi" && "Nadi type"}

                      {row.key === "mutra" &&
                        "Urine colour / appearance"}

                      {row.key === "mala" &&
                        "Mala Lakshana"}

                      {row.key === "jihva" &&
                        "Tongue appearance"}

                      {row.key === "shabda" &&
                        "Voice quality"}

                      {row.key === "sparsha" &&
                        "Touch"}

                      {row.key === "drika" &&
                        "Dominant feature"}

                      {row.key === "akriti" &&
                        "Body type"}
                    </label>

                    <select
                      value={formData[row.key]}
                      onChange={(e) =>
                        handleChange(row.key, e.target.value)
                      }
                      className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-emerald-300"
                    >
                      <option value="">
                        Select
                      </option>

                      {options.map((option) => (
                        <option
                          key={option.value}
                          value={option.value}
                        >
                          {option.label}
                        </option>
                      ))}
                    </select>

                    {/* EXTRA NOTES */}
                    {(row.key === "drika" ||
                      row.key === "akriti") && (
                      <input
                        type="text"
                        value={formData[`${row.key}Notes`]}
                        onChange={(e) =>
                          handleChange(
                            `${row.key}Notes`,
                            e.target.value
                          )
                        }
                        placeholder={
                          row.key === "drika"
                            ? "Additional eye observations..."
                            : "Additional body observations..."
                        }
                        className="w-full mt-3 border border-slate-300 rounded-lg px-3 py-2 text-sm"
                      />
                    )}

                    {row.key === "sparsha" && (
                      <textarea
                        value={formData.sparshaNotes}
                        onChange={(e) =>
                          handleChange(
                            "sparshaNotes",
                            e.target.value
                          )
                        }
                        rows="2"
                        placeholder="Additional touch observations..."
                        className="w-full mt-3 border border-slate-300 rounded-lg px-3 py-2 text-sm"
                      />
                    )}

                  </div>

                  {/* REFERENCE */}
                  <div className="p-4 bg-slate-50/50">

                    <div className="space-y-2">

                      {options.map((option) => (
                        <label
                          key={option.value}
                          className="flex items-start gap-2 text-sm cursor-pointer"
                        >

                          <input
                            type="radio"
                            name={row.key}
                            value={option.value}
                            checked={
                              formData[row.key] ===
                              option.value
                            }
                            onChange={(e) =>
                              handleChange(
                                row.key,
                                e.target.value
                              )
                            }
                            className="mt-1"
                          />

                          <span className="text-slate-700">
                            <span className="font-medium">
                              {option.label}
                            </span>

                            <span className="block text-xs text-slate-500 mt-0.5">
                              {option.reference}
                            </span>
                          </span>

                        </label>
                      ))}

                    </div>

                  </div>

                </div>
              );
            })}
          </div>

          {/* RIGHT SIDE */}
          <div className="space-y-4">

            {/* SUMMARY */}
            <div className="border rounded-xl overflow-hidden">

              <div className="px-4 py-3 bg-blue-50 border-b">
                <h3 className="font-bold text-blue-800">
                  Ashtasthana Summary
                </h3>
              </div>

              <div className="p-3 space-y-2">

                {examinationRows.map((row) => {

                  const selectedOption = getOptions(row.key).find(
                    (item) =>
                      item.value === formData[row.key]
                  );

                  return (
                    <div
                      key={row.key}
                      className="flex items-center justify-between border rounded-lg px-3 py-3"
                    >

                      <div className="flex items-center gap-3">

                        <span className="text-xl">
                          {row.icon}
                        </span>

                        <span className="font-semibold text-slate-700">
                          {row.title}
                        </span>

                      </div>

                      <div className="text-right">

                        <p className="text-sm font-bold text-slate-700">
                          {selectedOption
                            ? selectedOption.label
                            : "-"}
                        </p>

                        <p className="text-xs text-slate-500">
                          {selectedOption
                            ? selectedOption.reference
                            : "Not assessed"}
                        </p>

                      </div>

                    </div>
                  );
                })}

              </div>
            </div>

            {/* CLINICAL INSIGHT */}
            <div className="border rounded-xl bg-amber-50 border-amber-200 p-4">

              <h3 className="font-bold text-amber-800 mb-2">
                Clinical Insight
              </h3>

              <p className="text-sm text-slate-700 leading-6">
                Ashtasthana Pariksha helps in understanding
                the dominance and variation of Doshas through
                observational examination.
              </p>

            </div>

            {/* NADI REFERENCE */}
            <div className="border rounded-xl bg-blue-50 border-blue-200 p-4">

              <h3 className="font-bold text-blue-800 mb-3">
                Nadi Reference
              </h3>

              <div className="space-y-2 text-sm">

                {nadiData.map((item) => (
                  <div
                    key={item.value}
                    className="flex justify-between gap-3"
                  >
                    <span className="font-medium text-slate-700">
                      {item.label}
                    </span>

                    <span className="text-slate-600 text-right">
                      {item.reference}
                    </span>
                  </div>
                ))}

              </div>

            </div>

          </div>
        </div>

        {/* SELECTED REFERENCE */}
        <div className="mt-5 border rounded-xl bg-slate-50 p-4">

          <h3 className="font-bold text-slate-800 mb-3">
            Selected Reference
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">

            {examinationRows.slice(0, 4).map((row) => (

              <div
                key={row.key}
                className="bg-white border rounded-lg p-3"
              >

                <p className="text-xs text-slate-500">
                  {row.title}
                </p>

                <p className="text-sm font-semibold text-slate-800 mt-1">
                  {getSelectedReference(row.key) ||
                    "Not selected"}
                </p>

              </div>

            ))}

          </div>

        </div>

        {/* BUTTONS */}
        <div className="flex flex-col sm:flex-row justify-between gap-3 mt-6">

          <button
            type="button"
            onClick={resetAll}
            className="px-6 py-3 border border-slate-300 rounded-xl font-semibold text-slate-700 hover:bg-slate-50"
          >
            ↻ Reset All
          </button>

          <button
            type="button"
            onClick={saveData}
            className="px-7 py-3 rounded-xl font-semibold text-white bg-emerald-600 hover:bg-emerald-700"
          >
            ✓ Save Ashtasthana Pariksha
          </button>

        </div>

      </div>
    </div>
  );
}

export default AshtasthanaParikshaSection;