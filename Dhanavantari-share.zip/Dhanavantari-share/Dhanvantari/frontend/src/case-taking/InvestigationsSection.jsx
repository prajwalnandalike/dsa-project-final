import React, { useState } from "react";

const investigationGroups = [
  {
    title: "Blood Tests",
    options: [
      "CBC",
      "LFT",
      "RFT",
      "Blood Glucose",
      "HbA1c",
      "Lipid Profile",
      "ESR",
      "CRP",
    ],
  },
  {
    title: "Urine Tests",
    options: [
      "Urine Routine",
      "Urine Microscopy",
      "Urine Culture",
      "Other Urine Test",
    ],
  },
  {
    title: "Imaging",
    options: [
      "X-ray",
      "Ultrasound",
      "CT",
      "MRI",
    ],
  },
  {
    title: "Other Investigations",
    options: [],
  },
];

const InvestigationsSection = ({ data = [], onChange }) => {
  const [investigations, setInvestigations] = useState(data);

  const updateInvestigations = (updated) => {
    setInvestigations(updated);

    if (onChange) {
      onChange(updated);
    }
  };

  const addInvestigation = (name = "") => {
    updateInvestigations([
      ...investigations,
      {
        type: "",
        name,
        date: "",
        result: "",
        unit: "",
        referenceRange: "",
        remarks: "",
        report: null,
      },
    ]);
  };

  const updateInvestigation = (index, field, value) => {
    const updated = [...investigations];

    updated[index] = {
      ...updated[index],
      [field]: value,
    };

    updateInvestigations(updated);
  };

  const removeInvestigation = (index) => {
    const updated = investigations.filter(
      (_, itemIndex) => itemIndex !== index
    );

    updateInvestigations(updated);
  };
  const saveData = () => {
  const completedInvestigations = investigations.filter(
    (item) => item.name || item.result || item.remarks
  );

  const assessment = {
    totalInvestigations: investigations.length,
    completedInvestigations: completedInvestigations.length,
    investigations: completedInvestigations.map((item) => ({
      name: item.name || "Unnamed Investigation",
      type: item.type || "Other",
      result: item.result || "",
      unit: item.unit || "",
      referenceRange: item.referenceRange || "",
      remarks: item.remarks || "",
      date: item.date || "",
    })),
  };

        const updatedData = {
          investigations,
          assessment,
        };

        if (onChange) {
          onChange(updatedData);
        }

        alert("Investigations assessment saved successfully.");
      };




  const selectPredefinedInvestigation = (name, type) => {
    const existing = investigations.some(
      (item) => item.name === name
    );

    if (!existing) {
      addInvestigation(name);
    }
  };

  return (
    <section className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">

      {/* Header */}
      <div className="mb-6 flex items-center gap-4">

        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-100 font-bold text-emerald-700">
          23
        </div>

        <div>
          <h2 className="text-xl font-bold text-slate-800">
            Investigations
          </h2>

          <p className="text-sm text-slate-500">
            Select common investigations or add a custom investigation.
          </p>
        </div>

      </div>

      {/* Quick Investigation Selection */}
      <div className="space-y-6">

        {investigationGroups.map((group) => (

          <div
            key={group.title}
            className="rounded-xl border border-slate-200 bg-slate-50 p-5"
          >

            <h3 className="mb-4 font-bold text-slate-700">
              {group.title}
            </h3>

            {group.options.length > 0 ? (

              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">

                {group.options.map((option) => {

                  const selected = investigations.some(
                    (item) => item.name === option
                  );

                  return (
                    <label
                      key={option}
                      className={`flex cursor-pointer items-center gap-3 rounded-lg border p-3 transition ${
                        selected
                          ? "border-emerald-400 bg-emerald-50"
                          : "border-slate-200 bg-white hover:border-emerald-300"
                      }`}
                    >

                      <input
                        type="checkbox"
                        checked={selected}
                        onChange={() =>
                          selected
                            ? updateInvestigations(
                                investigations.filter(
                                  (item) => item.name !== option
                                )
                              )
                            : selectPredefinedInvestigation(
                                option,
                                group.title
                              )
                        }
                        className="h-4 w-4 accent-emerald-600"
                      />

                      <span className="text-sm font-medium text-slate-700">
                        {option}
                      </span>

                    </label>
                  );
                })}

              </div>

            ) : (

              <button
                type="button"
                onClick={() => addInvestigation()}
                className="rounded-xl border border-dashed border-emerald-300 bg-emerald-50 px-5 py-3 text-sm font-bold text-emerald-700 transition hover:bg-emerald-100"
              >
                + Add Other Investigation
              </button>

            )}



          </div>

        ))}

      </div>

      {/* Investigation Details */}
      {investigations.length > 0 && (
        <div className="mt-6">

          <div className="mb-4 flex items-center justify-between">

            <div>
              <h3 className="font-bold text-slate-800">
                Investigation Details
              </h3>

              <p className="text-xs text-slate-500">
                Enter the result and supporting information.
              </p>
            </div>

            <span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-bold text-emerald-700">
              {investigations.length} Selected
            </span>

          </div>

          <div className="space-y-5">

            {investigations.map((item, index) => (

              <div
                key={index}
                className="rounded-xl border border-slate-200 bg-slate-50 p-5"
              >

                {/* Investigation title */}
                <div className="mb-5 flex items-center justify-between">

                  <div>
                    <p className="text-xs font-semibold uppercase tracking-wide text-emerald-600">
                      Investigation {index + 1}
                    </p>

                    <h4 className="mt-1 font-bold text-slate-800">
                      {item.name || "Custom Investigation"}
                    </h4>
                  </div>

                  <button
                    type="button"
                    onClick={() => removeInvestigation(index)}
                    className="text-sm font-semibold text-red-500 hover:text-red-700"
                  >
                    Remove
                  </button>

                </div>

                <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">

                  {/* Type */}
                  <Select
                    label="Investigation Type"
                    value={item.type}
                    onChange={(value) =>
                      updateInvestigation(index, "type", value)
                    }
                    options={[
                      "Blood Test",
                      "Urine Test",
                      "Imaging",
                      "Pathology",
                      "Other",
                    ]}
                  />

                  {/* Name */}
                  <Input
                    label="Investigation Name"
                    value={item.name}
                    onChange={(value) =>
                      updateInvestigation(index, "name", value)
                    }
                    placeholder="Investigation name"
                  />

                  {/* Date */}
                  <div>
                    <label className="mb-2 block text-sm font-semibold text-slate-600">
                      Date
                    </label>

                    <input
                      type="date"
                      value={item.date || ""}
                      onChange={(e) =>
                        updateInvestigation(
                          index,
                          "date",
                          e.target.value
                        )
                      }
                      className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100"
                    />
                  </div>

                  {/* Result */}
                  <Input
                    label="Result / Value"
                    value={item.result}
                    onChange={(value) =>
                      updateInvestigation(index, "result", value)
                    }
                    placeholder="Enter result or value"
                  />

                  {/* Unit */}
                  <Input
                    label="Unit"
                    value={item.unit}
                    onChange={(value) =>
                      updateInvestigation(index, "unit", value)
                    }
                    placeholder="e.g. mg/dL"
                  />

                  {/* Reference Range */}
                  <Input
                    label="Reference Range"
                    value={item.referenceRange}
                    onChange={(value) =>
                      updateInvestigation(
                        index,
                        "referenceRange",
                        value
                      )
                    }
                    placeholder="Enter reference range"
                  />

                  {/* Remarks */}
                  <div className="md:col-span-2 lg:col-span-3">

                    <label className="mb-2 block text-sm font-semibold text-slate-600">
                      Remarks
                    </label>

                    <textarea
                      value={item.remarks || ""}
                      onChange={(e) =>
                        updateInvestigation(
                          index,
                          "remarks",
                          e.target.value
                        )
                      }
                      placeholder="Add clinical remarks or observations..."
                      rows={3}
                      className="w-full resize-none rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100"
                    />

                  </div>

                  {/* Upload */}
                  <div className="md:col-span-2 lg:col-span-3">

                    <label className="mb-2 block text-sm font-semibold text-slate-600">
                      Upload Report
                    </label>

                    <input
                      type="file"
                      accept=".pdf,.jpg,.jpeg,.png"
                      onChange={(e) =>
                        updateInvestigation(
                          index,
                          "report",
                          e.target.files?.[0] || null
                        )
                      }
                      className="block w-full rounded-xl border border-dashed border-slate-300 bg-white px-4 py-3 text-sm text-slate-600 file:mr-4 file:rounded-lg file:border-0 file:bg-emerald-50 file:px-4 file:py-2 file:font-semibold file:text-emerald-700"
                    />

                  </div>

                </div>

              </div>

            ))}

          </div>

        </div>
      )}

      {/* Add Investigation */}
      <button
        type="button"
        onClick={() => addInvestigation()}
        className="mt-6 flex items-center gap-2 rounded-xl bg-gradient-to-r from-emerald-600 to-cyan-600 px-5 py-3 text-sm font-bold text-white shadow-md transition hover:-translate-y-0.5 hover:shadow-lg"
      >
        <span className="text-lg">+</span>
        Add Investigation
      </button>
      <div className="mt-6 flex justify-end">
          <button
            type="button"
            onClick={saveData}
            className="rounded-xl bg-emerald-600 px-7 py-3 font-semibold text-white hover:bg-emerald-700"
          >
            ✓ Save Investigations Assessment
          </button>
        </div>

    </section>
  );
};


/* Select */
const Select = ({ label, value, onChange, options }) => {
  return (
    <div>

      <label className="mb-2 block text-sm font-semibold text-slate-600">
        {label}
      </label>

      <select
        value={value || ""}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100"
      >
        <option value="">
          Select {label}
        </option>

        {options.map((option) => (
          <option key={option} value={option}>
            {option}
          </option>
        ))}
      </select>

    </div>
  );
};


/* Input */
const Input = ({ label, value, onChange, placeholder }) => {
  return (
    <div>

      <label className="mb-2 block text-sm font-semibold text-slate-600">
        {label}
      </label>

      <input
        type="text"
        value={value || ""}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100"
      />

    </div>
  );
};

export default InvestigationsSection;