import React, { useState } from "react";

const DashavidhaParikshaSection = ({ data = {}, onChange }) => {
  const [form, setForm] = useState(data);

  const update = (key, value) => {
    const updated = { ...form, [key]: value };
    setForm(updated);
    onChange?.(updated);
  };

  const saveData = () => {
  const assessment = {
    sara: form.sara || "Not assessed",
    samhanana: form.samhanana || "Not assessed",
    pramana: form.proportion || "Not assessed",
    satmya: form.satmyaDiet || "Not assessed",
    sattva: form.sattva || "Not assessed",
    aharaShakti: form.aharaShakti || "Not assessed",
    vyayamaShakti: form.vyayamaShakti || "Not assessed",
    vaya: form.vaya || "Not assessed",
  };

  const updatedData = {
    ...form,
    assessment,
  };

  setForm(updatedData);
  onChange?.(updatedData);

  alert("Dashavidha Pariksha assessment saved successfully.");
};

  const saraOptions = [
    "Tvak Sara",
    "Rasa Sara",
    "Mamsa Sara",
    "Meda Sara",
    "Asthi Sara",
    "Majja Sara",
    "Shukra Sara",
    "Sattva Sara",
  ];

  const saraFeatures = {
    "Tvak Sara": [
      "Unctuous",
      "Smooth",
      "Soft",
      "Clear",
      "Fine",
      "Lustrous",
    ],
    "Rasa Sara": [
      "Unctuousness",
      "Red color",
      "Beautiful dazzling appearance",
      "Happiness",
      "Great genius",
      "Enthusiasm",
      "Tenderness",
      "Moderate strength",
    ],
    "Mamsa Sara": [
      "Stability",
      "Heaviness",
      "Beautiful appearance",
      "Plumpness",
      "Forgiveness",
      "Patience",
      "Non-greediness",
      "Wealth",
      "Knowledge",
      "Happiness",
      "Strength",
      "Longevity",
    ],
    "Meda Sara": [
      "Abundance of unctuousness",
      "Unctuous complexion",
      "Unctuous voice",
      "Unctuous eyes",
      "Unctuous hair",
      "Unctuous nails",
      "Unctuous teeth",
      "Unctuous lips",
      "Unctuous urine",
      "Unctuous feces",
      "Health",
      "Power",
      "Happiness",
    ],
    "Asthi Sara": [
      "Robust heels",
      "Robust ankles",
      "Robust knees",
      "Robust forearms",
      "Strong collar-bones",
      "Strong chin",
      "Strong head",
      "Strong joints",
      "Strong bones",
      "Strong nails",
      "Strong teeth",
      "Enthusiasm",
      "Active nature",
      "Longevity",
    ],
    "Majja Sara": [
      "Softness of organs",
      "Strength",
      "Unctuousness",
      "Good complexion",
      "Good voice",
      "Robust joints",
      "Long joints",
      "Rounded joints",
      "Longevity",
      "Learning",
      "Knowledge",
      "Progeny",
      "Honor",
    ],
    "Shukra Sara": [
      "Gentleness",
      "Gentle look",
      "Attractive eyes",
      "Cheerfulness",
      "Unctuous teeth",
      "Round teeth",
      "Strong teeth",
      "Even teeth",
      "Beautiful teeth",
      "Clean complexion",
      "Unctuous complexion",
      "Clean voice",
      "Large buttocks",
      "Strength",
      "Health",
      "Wealth",
      "Children",
    ],
    "Sattva Sara": [
      "Good memory",
      "Devotion",
      "Gratefulness",
      "Wisdom",
      "Purity",
      "Excessive enthusiasm",
      "Skill",
      "Courage",
      "Valour in fighting",
      "Virtuous acts",
    ],
  };

  const selectOptions = (key, options) => (
    <select
      value={form[key] || ""}
      onChange={(e) => update(key, e.target.value)}
      className="w-full rounded-xl border border-slate-300 px-4 py-3"
    >
      <option value="">Select</option>
      {options.map((option) => (
        <option key={option} value={option}>
          {option}
        </option>
      ))}
    </select>
  );

  return (
    <section className="rounded-3xl bg-white p-4 shadow-sm ring-1 ring-slate-200 sm:p-6">

      {/* HEADER */}
      <div className="mb-6 rounded-2xl bg-gradient-to-r from-emerald-50 to-cyan-50 p-5">
        <p className="text-sm font-bold uppercase tracking-wider text-emerald-600">
          Section 17
        </p>

        <h2 className="mt-1 text-2xl font-bold text-slate-800">
          Dashavidha Pariksha
        </h2>

        <p className="mt-2 text-sm text-slate-600">
          Ten-fold clinical examination used for assessing the patient's
          strength, constitution and clinical condition.
        </p>
      </div>

      {/* MAIN GRID */}
      <div className="grid gap-6 lg:grid-cols-[1fr_300px]">

        {/* LEFT */}
        <div className="space-y-6">

          {/* SARA */}
          <div className="rounded-2xl border border-slate-200 p-5">
            <h3 className="mb-4 text-xl font-bold text-emerald-700">
              1. Sara
            </h3>

            <label className="mb-2 block text-sm font-semibold text-slate-700">
              Select Sara
            </label>

            {selectOptions("sara", saraOptions)}

            {form.sara && (
              <div className="mt-5 rounded-xl bg-emerald-50 p-4">
                <h4 className="mb-3 font-bold text-emerald-800">
                  {form.sara} Lakshana
                </h4>

                <div className="grid gap-2 sm:grid-cols-2">
                  {saraFeatures[form.sara].map((feature) => (
                    <label
                      key={feature}
                      className="flex items-start gap-2 rounded-lg bg-white p-2"
                    >
                      <input
                        type="checkbox"
                        checked={
                          form.saraFeatures?.includes(feature) || false
                        }
                        onChange={(e) => {
                          const current = form.saraFeatures || [];

                          const updated = e.target.checked
                            ? [...current, feature]
                            : current.filter((item) => item !== feature);

                          update("saraFeatures", updated);
                        }}
                        className="mt-1"
                      />

                      <span className="text-sm text-slate-700">
                        {feature}
                      </span>
                    </label>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* SAMHANANA */}
          <div className="rounded-2xl border border-slate-200 p-5">
            <h3 className="mb-4 text-xl font-bold text-emerald-700">
              2. Samhanana
            </h3>

            <div className="grid gap-3 sm:grid-cols-3">
              {["Pravara", "Madhyama", "Heena"].map((option) => (
                <label
                  key={option}
                  className="flex cursor-pointer items-center gap-2 rounded-xl border p-3"
                >
                  <input
                    type="radio"
                    name="samhanana"
                    checked={form.samhanana === option}
                    onChange={() => update("samhanana", option)}
                  />
                  {option}
                </label>
              ))}
            </div>
          </div>

          {/* PRAMANA */}
          <div className="rounded-2xl border border-slate-200 p-5">
            <h3 className="mb-4 text-xl font-bold text-emerald-700">
              3. Pramana
            </h3>

            <div className="grid gap-4 sm:grid-cols-3">
              <div>
                <label className="mb-2 block text-sm font-semibold">
                  Height
                </label>
                <input
                  type="text"
                  placeholder="e.g. 165 cm"
                  value={form.height || ""}
                  onChange={(e) => update("height", e.target.value)}
                  className="w-full rounded-xl border px-4 py-3"
                />
              </div>

              <div>
                <label className="mb-2 block text-sm font-semibold">
                  Body Measurements
                </label>
                <input
                  type="text"
                  placeholder="Enter measurements"
                  value={form.measurements || ""}
                  onChange={(e) =>
                    update("measurements", e.target.value)
                  }
                  className="w-full rounded-xl border px-4 py-3"
                />
              </div>

              <div>
                <label className="mb-2 block text-sm font-semibold">
                  Proportion
                </label>
                {selectOptions("proportion", [
                  "Proportionate",
                  "Disproportionate",
                ])}
              </div>
            </div>
          </div>

          {/* SATMYA */}
          <div className="rounded-2xl border border-slate-200 p-5">
            <h3 className="mb-4 text-xl font-bold text-emerald-700">
              4. Satmya
            </h3>

            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-2 block text-sm font-semibold">
                  Diet
                </label>
                {selectOptions("satmyaDiet", [
                  "Highly Suitable",
                  "Moderately Suitable",
                  "Less Suitable",
                ])}
              </div>

              <div>
                <label className="mb-2 block text-sm font-semibold">
                  Taste
                </label>
                {selectOptions("satmyaTaste", [
                  "Sweet",
                  "Sour",
                  "Salty",
                  "Pungent",
                  "Bitter",
                  "Astringent",
                ])}
              </div>

              <div>
                <label className="mb-2 block text-sm font-semibold">
                  Habits
                </label>
                {selectOptions("satmyaHabits", [
                  "Suitable",
                  "Moderately Suitable",
                  "Unsuitable",
                ])}
              </div>

              <div>
                <label className="mb-2 block text-sm font-semibold">
                  Lifestyle
                </label>
                {selectOptions("satmyaLifestyle", [
                  "Suitable",
                  "Moderately Suitable",
                  "Unsuitable",
                ])}
              </div>
            </div>
          </div>

          {/* SATTVA */}
          <div className="rounded-2xl border border-slate-200 p-5">
            <h3 className="mb-4 text-xl font-bold text-emerald-700">
              5. Sattva
            </h3>

            <div className="grid gap-3 sm:grid-cols-3">
              {["Pravara", "Madhyama", "Heena"].map((option) => (
                <label
                  key={option}
                  className="flex cursor-pointer items-center gap-2 rounded-xl border p-3"
                >
                  <input
                    type="radio"
                    name="sattva"
                    checked={form.sattva === option}
                    onChange={() => update("sattva", option)}
                  />
                  {option}
                </label>
              ))}
            </div>
          </div>

          {/* AHARA SHAKTI */}
          <div className="rounded-2xl border border-slate-200 p-5">
            <h3 className="mb-4 text-xl font-bold text-emerald-700">
              6. Ahara Shakti
            </h3>

            {selectOptions("aharaShakti", [
              "Pravara",
              "Madhyama",
              "Heena",
            ])}
          </div>

          {/* VYAYAMA SHAKTI */}
          <div className="rounded-2xl border border-slate-200 p-5">
            <h3 className="mb-4 text-xl font-bold text-emerald-700">
              7. Vyayama Shakti
            </h3>

            {selectOptions("vyayamaShakti", [
              "Pravara",
              "Madhyama",
              "Heena",
            ])}
          </div>

          {/* VAYA */}
          <div className="rounded-2xl border border-slate-200 p-5">
            <h3 className="mb-4 text-xl font-bold text-emerald-700">
              8. Vaya
            </h3>

            {selectOptions("vaya", [
              "Bala",
              "Madhyama",
              "Vriddha",
            ])}
          </div>

        </div>

        {/* RIGHT RESULT */}
        <aside className="h-fit rounded-2xl bg-gradient-to-b from-emerald-50 to-cyan-50 p-5 lg:sticky lg:top-6">
          <h3 className="mb-5 text-xl font-bold text-slate-800">
            Dashavidha Result
          </h3>

          <div className="space-y-3">

            {[
              ["Sara", form.sara],
              ["Samhanana", form.samhanana],
              ["Pramana", form.proportion],
              ["Satmya", form.satmyaDiet],
              ["Sattva", form.sattva],
              ["Ahara Shakti", form.aharaShakti],
              ["Vyayama Shakti", form.vyayamaShakti],
              ["Vaya", form.vaya],
            ].map(([name, value]) => (
              <div
                key={name}
                className="rounded-xl bg-white p-3 shadow-sm"
              >
                <p className="text-xs font-semibold uppercase text-slate-500">
                  {name}
                </p>

                <p className="mt-1 font-bold text-emerald-700">
                  {value || "Not assessed"}
                </p>
              </div>
            ))}

          </div>

          <div className="mt-5 rounded-xl bg-white p-4">
            <p className="text-sm font-semibold text-slate-600">
              Assessment Status
            </p>

            <p className="mt-1 text-lg font-bold text-slate-800">
              {Object.keys(form).length > 0
                ? "Assessment in progress"
                : "Not Started"}
            </p>
          </div>
        </aside>

      </div>
      <div className="mt-6 flex justify-end">
  <button
    type="button"
    onClick={saveData}
    className="rounded-xl bg-emerald-600 px-7 py-3 font-semibold text-white hover:bg-emerald-700"
  >
    ✓ Save Dashavidha Assessment
  </button>
</div>
    </section>
  );
};

export default DashavidhaParikshaSection;