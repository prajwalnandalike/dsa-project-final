import React from "react";

const CommonPatientSection = ({ patient = {} }) => {
  const showGuardian =
    patient.registrationType === "guardian_assisted" ||
    patient.guardian?.name ||
    patient.guardian?.mobile;

  return (
    <section className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
      
      {/* Section Header */}
      <div className="mb-6 flex items-center gap-4">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-100 font-bold text-emerald-700">
          01
        </div>

        <div>
          <h2 className="text-xl font-bold text-slate-800">
            Patient
          </h2>

          <p className="text-sm text-slate-500">
            Patient information from the registered profile
          </p>
        </div>
      </div>

      {/* Patient Information */}
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">

        <ReadOnlyField
          label="Patient ID"
          value={patient.patientId}
        />

        <ReadOnlyField
          label="Patient Name"
          value={patient.patientName}
        />

        <ReadOnlyField
          label="Date of Birth"
          value={
            patient.dateOfBirth
              ? new Date(patient.dateOfBirth).toLocaleDateString()
              : ""
          }
        />

        <ReadOnlyField
          label="Age"
          value={patient.age}
        />

        <ReadOnlyField
          label="Gender"
          value={formatValue(patient.gender)}
        />

        <ReadOnlyField
          label="Mobile Number"
          value={patient.mobile}
        />

        <ReadOnlyField
          label="Email"
          value={patient.email}
        />

        <ReadOnlyField
          label="ABHA Number"
          value={patient.abhaNumber}
        />

        <ReadOnlyField
          label="Registration Type"
          value={formatValue(patient.registrationType)}
        />

      </div>

      {/* Address */}
      <div className="mt-5">
        <ReadOnlyField
          label="Address"
          value={patient.address}
          textarea
        />
      </div>

      {/* Guardian */}
      {showGuardian && (
        <div className="mt-6 rounded-xl border border-cyan-100 bg-cyan-50/50 p-5">

          <h3 className="mb-4 font-bold text-slate-800">
            Guardian Information
          </h3>

          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">

            <ReadOnlyField
              label="Guardian Name"
              value={patient.guardian?.name}
            />

            <ReadOnlyField
              label="Relationship"
              value={patient.guardian?.relationship}
            />

            <ReadOnlyField
              label="Guardian Mobile"
              value={patient.guardian?.mobile}
            />

          </div>
        </div>
      )}

    </section>
  );
};


/* Reusable read-only field */
const ReadOnlyField = ({ label, value, textarea = false }) => {
  return (
    <div>
      <label className="mb-2 block text-sm font-semibold text-slate-600">
        {label}
      </label>

      {textarea ? (
        <textarea
          value={value || "Not provided"}
          readOnly
          rows={3}
          className="w-full resize-none rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-700 outline-none"
        />
      ) : (
        <input
          type="text"
          value={value || "Not provided"}
          readOnly
          className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-700 outline-none"
        />
      )}
    </div>
  );
};


/* Convert stored enum values into readable text */
const formatValue = (value) => {
  if (!value) return "";

  return value
    .replaceAll("_", " ")
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
};


export default CommonPatientSection;