import React, { useState } from "react";

const lakshanas = {
  Vata: {
    vruddhi: [
      "Kasha (Emaciation)",
      "Karsnya (Darkness)",
      "Usnakamatva (Liking the hot)",
      "Kampa (Tremors)",
      "Anaha (Intestinal distention)",
      "Shakrt Grahana (Constipation)",
      "Bala Bhramsha (Loss of energy)",
      "Nidra Bhramsha (Disturbed sleep)",
      "Indriya Bhramsha (Impairment of senses)",
      "Pralapa (Excessive talking)",
      "Bhrama (Delusions / illusions)",
      "Dinata (Timidness / lowliness)",
    ],
    kshaya: [
      "Angasada (Debility or weakness of body parts)",
      "Alpam Bhashite Hitam (Speaking very little / avoiding talking)",
      "Sanjna Moha (Diminished alertness / confusion / loss of awareness)",
    ],
  },

  Pitta: {
    vruddhi: [
      "Peeta Vinmutra Netra Tvak (Yellow feces, urine, eyes and skin)",
      "Kshut (Hunger)",
      "Trt (Thirst)",
      "Daha (Burning sensation)",
      "Alpa Nidra (Less sleep / insomnia)",
    ],
    kshaya: [
      "Mando-Anala (Sluggish digestive fire / weakness of Agni)",
      "Sheetam (Excessive coldness / lack of body warmth)",
      "Prabha Hani (Loss of natural luster and skin glow)",
    ],
  },

  Kapha: {
    vruddhi: [
      "Sleshma Agni Sadanam (Displacement / impairment of Agni)",
      "Praseka (Excess saliva)",
      "Alasya (Laziness)",
      "Gaurava (Heaviness)",
      "Shvaitya (Paleness / whiteness)",
      "Shaitya (Coldness)",
      "Shlathangatva (Laxity / instability of body)",
      "Shwasa (Dyspnoea)",
      "Kasa (Cough)",
      "Atinidrata (Excessive sleep)",
    ],
    kshaya: [
      "Bhrama (Dizziness / vertigo)",
      "Shleshma Ashayana Shunyatvam (Emptiness of natural Kapha sites)",
      "Hrid Drava (Palpitations / rapid heartbeat)",
      "Shlatha Sandhita (Loose / unstable / cracking joints)",
    ],
  },
};

const VikruthiSection = ({ data = {}, onChange }) => {
  const [selected, setSelected] = useState(data.selected || {});

  const toggle = (dosha, type, index) => {
    const key = `${dosha}-${type}-${index}`;

    const updated = {
      ...selected,
      [key]: !selected[key],
    };

    setSelected(updated);

    onChange?.({
      ...data,
      selected: updated,
    });
  };

  const getCount = (dosha) =>
    Object.keys(selected).filter(
      (key) => key.startsWith(`${dosha}-`) && selected[key]
    ).length;

  const vataCount = getCount("Vata");
  const pittaCount = getCount("Pitta");
  const kaphaCount = getCount("Kapha");

  const total = vataCount + pittaCount + kaphaCount;

  const predominant =
    total === 0
      ? "No Vikruthi Selected"
      : [
          ["Vata", vataCount],
          ["Pitta", pittaCount],
          ["Kapha", kaphaCount],
        ].sort((a, b) => b[1] - a[1])[0][0];

  const maxRows = Math.max(
    lakshanas.Vata.vruddhi.length + lakshanas.Vata.kshaya.length,
    lakshanas.Pitta.vruddhi.length + lakshanas.Pitta.kshaya.length,
    lakshanas.Kapha.vruddhi.length + lakshanas.Kapha.kshaya.length
  );

  const getItems = (dosha) => [
    ...lakshanas[dosha].vruddhi.map((item) => ({
      type: "Vruddhi",
      text: item,
    })),
    ...lakshanas[dosha].kshaya.map((item) => ({
      type: "Kshaya",
      text: item,
    })),
  ];

  const renderDoshaCell = (dosha, rowIndex) => {
    const items = getItems(dosha);
    const item = items[rowIndex];

    if (!item) return null;

    const key = `${dosha}-${item.type === "Vruddhi" ? "vruddhi" : "kshaya"}-${item.type === "Vruddhi"
      ? lakshanas[dosha].vruddhi.indexOf(item.text)
      : lakshanas[dosha].kshaya.indexOf(item.text)}`;

    return (
      <label className="flex cursor-pointer items-start gap-2 py-2 text-sm text-slate-700">
        <input
          type="checkbox"
          checked={selected[key] || false}
          onChange={() =>
            toggle(
              dosha,
              item.type === "Vruddhi" ? "vruddhi" : "kshaya",
              item.type === "Vruddhi"
                ? lakshanas[dosha].vruddhi.indexOf(item.text)
                : lakshanas[dosha].kshaya.indexOf(item.text)
            )
          }
          className="mt-1 h-4 w-4"
        />

        <span>
          <span className="mr-1 font-medium text-slate-800">
            {item.text.split(" (")[0]}
          </span>
          <span className="text-slate-500">
            ({item.text.split(" (")[1]?.replace(")", "")})
          </span>
        </span>
      </label>
    );
  };

  const resetAll = () => {
    setSelected({});
    onChange?.({
      ...data,
      selected: {},
    });
  };

  return (
    <section className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">

      {/* Header */}
      <div className="mb-5 flex items-center justify-between rounded-xl bg-emerald-50 p-5">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">
            Vikruthi Assessment
          </h2>

          <p className="mt-1 text-sm text-slate-500">
            Select the Lakshanas present in the patient.
          </p>
        </div>

        <div className="hidden rounded-xl bg-white px-5 py-3 text-center shadow-sm md:block">
          <p className="text-sm italic text-emerald-700">
            “Assess the imbalance,
          </p>
          <p className="text-sm italic text-emerald-700">
            understand the condition”
          </p>
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-[1fr_270px]">

        {/* Table */}
        <div className="overflow-hidden rounded-xl border border-slate-200">

          <div className="grid grid-cols-4 border-b border-slate-200 bg-slate-50">

            <div className="p-4 font-bold text-slate-700">
              #
            </div>

            <div className="border-l border-slate-200 p-4 font-bold text-blue-700">
              🔵 Vata
            </div>

            <div className="border-l border-slate-200 p-4 font-bold text-orange-600">
              🔥 Pitta
            </div>

            <div className="border-l border-slate-200 p-4 font-bold text-emerald-700">
              🌿 Kapha
            </div>

          </div>

          {/* Vruddhi */}
          <div className="grid grid-cols-4 bg-blue-50/40">
            <div className="p-4 font-bold text-slate-700">
              Vruddhi
              <div className="text-xs font-normal text-slate-500">
                Increased
              </div>
            </div>

            <div className="border-l border-slate-200 p-3">
              {lakshanas.Vata.vruddhi.map((_, index) =>
                renderDoshaCell("Vata", index)
              )}
            </div>

            <div className="border-l border-slate-200 p-3">
              {lakshanas.Pitta.vruddhi.map((_, index) =>
                renderDoshaCell("Pitta", index)
              )}
            </div>

            <div className="border-l border-slate-200 p-3">
              {lakshanas.Kapha.vruddhi.map((_, index) =>
                renderDoshaCell("Kapha", index)
              )}
            </div>
          </div>

          {/* Kshaya */}
          <div className="grid grid-cols-4 border-t border-slate-200 bg-slate-50">
            <div className="p-4 font-bold text-slate-700">
              Kshaya
              <div className="text-xs font-normal text-slate-500">
                Decreased
              </div>
            </div>

            <div className="border-l border-slate-200 p-3">
              {lakshanas.Vata.kshaya.map((_, index) =>
                renderDoshaCell(
                  "Vata",
                  lakshanas.Vata.vruddhi.length + index
                )
              )}
            </div>

            <div className="border-l border-slate-200 p-3">
              {lakshanas.Pitta.kshaya.map((_, index) =>
                renderDoshaCell(
                  "Pitta",
                  lakshanas.Pitta.vruddhi.length + index
                )
              )}
            </div>

            <div className="border-l border-slate-200 p-3">
              {lakshanas.Kapha.kshaya.map((_, index) =>
                renderDoshaCell(
                  "Kapha",
                  lakshanas.Kapha.vruddhi.length + index
                )
              )}
            </div>
          </div>
        </div>

        {/* Result */}
        <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">

          <h3 className="mb-4 text-lg font-bold text-slate-800">
            📊 Vikruthi Result
          </h3>

          <div className="space-y-3">

            <ResultCard
              title="Vata"
              count={vataCount}
              symbol="🔵"
            />

            <ResultCard
              title="Pitta"
              count={pittaCount}
              symbol="🔥"
            />

            <ResultCard
              title="Kapha"
              count={kaphaCount}
              symbol="🌿"
            />

          </div>

          <div className="mt-5 rounded-xl border border-amber-200 bg-amber-50 p-4 text-center">

            <p className="text-sm font-semibold text-slate-600">
              Predominant Vikruthi
            </p>

            <p className="mt-2 text-xl font-bold text-amber-700">
              {predominant}
            </p>

            <p className="mt-1 text-xs text-slate-500">
              Based on selected Lakshanas ({total})
            </p>

          </div>

          <div className="mt-4 rounded-xl bg-white p-4 text-sm text-slate-600">
            <p className="font-semibold text-slate-800">
              Vikruthi Interpretation
            </p>

            <p className="mt-2">
              The assessment is calculated from the total number of
              selected Vruddhi and Kshaya Lakshanas under each Dosha.
            </p>
          </div>

        </div>
      </div>

      {/* Bottom */}
      <div className="mt-5 flex items-center justify-between rounded-xl bg-emerald-50 p-4">

        <p className="text-sm text-slate-600">
          Select the applicable Lakshanas based on the patient's
          clinical findings.
        </p>

        <button
          onClick={resetAll}
          className="rounded-xl border border-slate-300 bg-white px-5 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50"
        >
          Reset All
        </button>

        <button
              type="button"
              onClick={() => {
                const assessment = {
                  selected,
                  vataCount,
                  pittaCount,
                  kaphaCount,
                  total,
                  predominant,
                };

                onChange?.({
                  ...data,
                  selected,
                  assessment,
                });

                alert("Vikruthi Assessment saved successfully!");
              }}
              className="rounded-xl bg-gradient-to-r from-emerald-600 to-cyan-600 px-6 py-2.5 text-sm font-bold text-white shadow-md transition hover:-translate-y-0.5 hover:shadow-lg"
            >
              ✓ Save Vikruthi Assessment
            </button>

      </div>

    </section>
  );
};

const ResultCard = ({ title, count, symbol }) => (
  <div className="flex items-center justify-between rounded-xl border border-slate-200 bg-white p-4">
    <div className="flex items-center gap-3">
      <span className="text-xl">{symbol}</span>
      <span className="font-semibold text-slate-700">{title}</span>
    </div>

    <div className="text-right">
      <p className="text-xl font-bold text-slate-800">
        {count}
      </p>
      <p className="text-xs text-slate-500">
        selections
      </p>
    </div>
  </div>
);

export default VikruthiSection;