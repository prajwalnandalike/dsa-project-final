import React, { useState } from "react";

const hereditaryDiseases = [
  "Diabetes Mellitus",
  "Hypertension",
  "Heart Disease",
  "Kidney Disease",
  "Liver Disease",
  "Thyroid Disease",
  "Cancer",
  "Genetic Disorders",
  "Mental / Psychiatric Disorders",
];

const infectiousDiseases = [
  "Tuberculosis",
  "Hepatitis",
];

const FamilyHistorySection = ({ data = {}, onChange }) => {
  const [formData, setFormData] = useState(data);

  const updateField = (field, value) => {
    const updated = {
      ...formData,
      [field]: value,
    };

    setFormData(updated);

    if (onChange) {
      onChange(updated);
    }
  };

  const toggleCheckbox = (field, value) => {
    const current = formData[field] || [];

    const updated = current.includes(value)
      ? current.filter((item) => item !== value)
      : [...current, value];

    updateField(field, updated);
  };

  return (
    <section className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">

      {/* Header */}
      <div className="mb-6 flex items-center gap-4">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-100 font-bold text-emerald-700">
          05
        </div>

        <div>
          <h2 className="text-xl font-bold text-slate-800">
            Family History
          </h2>

          <p className="text-sm text-slate-500">
            Record relevant hereditary, familial and infectious diseases in the family.
          </p>
        </div>
      </div>

      {/* Hereditary / Familial Diseases */}
      <div className="mb-6 rounded-xl border border-slate-200 bg-slate-50 p-5">

        <h3 className="mb-1 font-bold text-slate-700">
          Hereditary / Familial Diseases
        </h3>

        <p className="mb-4 text-xs text-slate-500">
          Select all that are applicable.
        </p>

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">

          {hereditaryDiseases.map((disease) => (
            <label
              key={disease}
              className="flex cursor-pointer items-center gap-3 rounded-lg border border-slate-200 bg-white p-3 transition hover:border-emerald-300 hover:bg-emerald-50/30"
            >
              <input
                type="checkbox"
                checked={(formData.hereditaryDiseases || []).includes(
                  disease
                )}
                onChange={() =>
                  toggleCheckbox("hereditaryDiseases", disease)
                }
                className="h-4 w-4 accent-emerald-600"
              />

              <span className="text-sm text-slate-700">
                {disease}
              </span>
            </label>
          ))}

        </div>

        {/* Other Familial Diseases */}
        <div className="mt-4">

          <label className="mb-2 block text-sm font-semibold text-slate-600">
            Other Familial Diseases
          </label>

          <input
            type="text"
            value={formData.otherFamilialDiseases || ""}
            onChange={(e) =>
              updateField("otherFamilialDiseases", e.target.value)
            }
            placeholder="Enter any other familial disease"
            className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100"
          />

        </div>
      </div>

      {/* Infectious Diseases */}
      <div className="mb-6 rounded-xl border border-slate-200 bg-slate-50 p-5">

        <h3 className="mb-1 font-bold text-slate-700">
          Infectious Diseases in Family
        </h3>

        <p className="mb-4 text-xs text-slate-500">
          Select all that are applicable.
        </p>

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">

          {infectiousDiseases.map((disease) => (
            <label
              key={disease}
              className="flex cursor-pointer items-center gap-3 rounded-lg border border-slate-200 bg-white p-3 transition hover:border-emerald-300 hover:bg-emerald-50/30"
            >
              <input
                type="checkbox"
                checked={(formData.familyInfectiousDiseases || []).includes(
                  disease
                )}
                onChange={() =>
                  toggleCheckbox("familyInfectiousDiseases", disease)
                }
                className="h-4 w-4 accent-emerald-600"
              />

              <span className="text-sm text-slate-700">
                {disease}
              </span>
            </label>
          ))}

        </div>

        {/* Other Infectious Disease */}
        <div className="mt-4">

          <label className="mb-2 block text-sm font-semibold text-slate-600">
            Other Infectious Disease
          </label>

          <input
            type="text"
            value={formData.otherInfectiousDisease || ""}
            onChange={(e) =>
              updateField("otherInfectiousDisease", e.target.value)
            }
            placeholder="Enter other infectious disease"
            className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100"
          />

        </div>
      </div>

      {/* Similar Complaints */}
      <div className="mb-6 rounded-xl border border-slate-200 bg-slate-50 p-5">

        <h3 className="mb-4 font-bold text-slate-700">
          Similar Complaints in Family
        </h3>

        <div className="flex flex-wrap gap-3">

          <RadioOption
            name="similarComplaints"
            value="present"
            label="Present"
            checked={formData.similarComplaints === "present"}
            onChange={() =>
              updateField("similarComplaints", "present")
            }
          />

          <RadioOption
            name="similarComplaints"
            value="absent"
            label="Absent"
            checked={formData.similarComplaints === "absent"}
            onChange={() =>
              updateField("similarComplaints", "absent")
            }
          />

        </div>
      </div>

      {/* Consanguinity */}
      <div className="mb-6 rounded-xl border border-slate-200 bg-slate-50 p-5">

        <h3 className="mb-4 font-bold text-slate-700">
          Consanguinity
        </h3>

        <div className="flex flex-wrap gap-3">

          <RadioOption
            name="consanguinity"
            value="yes"
            label="Yes"
            checked={formData.consanguinity === "yes"}
            onChange={() =>
              updateField("consanguinity", "yes")
            }
          />

          <RadioOption
            name="consanguinity"
            value="no"
            label="No"
            checked={formData.consanguinity === "no"}
            onChange={() =>
              updateField("consanguinity", "no")
            }
          />

        </div>
      </div>

      {/* Other Significant Family History */}
      <div className="rounded-xl border border-slate-200 bg-slate-50 p-5">

        <h3 className="mb-4 font-bold text-slate-700">
          Other Significant Family History
        </h3>

        <textarea
          value={formData.otherSignificantFamilyHistory || ""}
          onChange={(e) =>
            updateField(
              "otherSignificantFamilyHistory",
              e.target.value
            )
          }
          placeholder="Enter any other significant family history..."
          rows={4}
          className="w-full resize-none rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100"
        />

      </div>

    </section>
  );
};


/* Reusable radio option */
const RadioOption = ({
  name,
  value,
  label,
  checked,
  onChange,
}) => {
  return (
    <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-slate-200 bg-white px-5 py-3 transition hover:border-emerald-300">
      <input
        type="radio"
        name={name}
        value={value}
        checked={checked}
        onChange={onChange}
        className="h-4 w-4 accent-emerald-600"
      />

      <span className="text-sm font-medium text-slate-700">
        {label}
      </span>
    </label>
  );
};

export default FamilyHistorySection;