import React, { useState } from "react";

const initialData = {
  agniType: "",
  agniAssessment: "",
  agniSymptoms: [],
  vatajaGrahani: [],
  pittajaGrahani: [],
  kaphajaGrahani: [],
  amaSymptoms: [],
  ajeernaSymptoms: [],
  amaNotes: "",
  ajeernaNotes: "",
  clinicalNotes: "",
};

const agniTypes = [
  {
    value: "samagni",
    title: "Samagni",
    description: "Balanced digestive function associated with balanced Tridoshas.",
  },
  {
    value: "vishamagni",
    title: "Vishamagni",
    description: "Irregular digestive function, associated with Vata predominance.",
  },
  {
    value: "tikshnagni",
    title: "Tikshnagni",
    description: "Strong/intense digestive function, associated with Pitta predominance.",
  },
  {
    value: "mandagni",
    title: "Mandagni",
    description: "Weak/sluggish digestive function, associated with Kapha predominance.",
  },
];

const vatajaGrahani = [
  ["Kanta Asya Shosha", "Dryness of throat and mouth"],
  ["Kshut", "Excessive hunger"],
  ["Trushna", "Excessive thirst"],
  ["Timira", "Appearance of darkness/visual disturbance"],
  ["Karnayo Swana", "Abnormal sound in the ears / tinnitus"],
  ["Parshwa Ruk", "Pain in the sides of the chest, thighs, pelvic region, cardiac region or neck"],
  ["Visuchika", "Severe diarrhoea / acute intestinal disturbance"],
  ["Hrut Shoola", "Pain in the cardiac region"],
  ["Karshya", "Emaciation"],
  ["Daurbalya", "Weakness"],
  ["Aruchi", "Distaste or anorexia"],
  ["Udara Shoola", "Abdominal pain"],
];

const pittajaGrahani = [
  ["Katu Ahara", "Pungent foods"],
  ["Amla Ahara", "Sour foods"],
  ["Vidahi Ahara", "Foods causing burning sensation"],
  ["Kshara Ahara", "Alkaline foods"],
  ["Ajirna", "Indigestion"],
  ["Ajeerna Mala", "Loose stool containing undigested material"],
  ["Peeta / Neela-Peeta Mala", "Bluish-yellow or yellow-coloured stool"],
  ["Durgandha Udgara", "Foul-smelling eructation"],
  ["Amla Rasa", "Sour taste associated with eructation"],
  ["Hrut Kanta Daha", "Burning sensation in cardiac region and throat"],
];

const kaphajaGrahani = [
  ["Guru Ahara", "Heavy foods"],
  ["Snigdha Ahara", "Excessively unctuous foods"],
  ["Sheeta Ahara", "Cold foods"],
  ["Ajirna", "Difficulty in digestion"],
  ["Hrullasa", "Nausea"],
  ["Chardi", "Vomiting"],
  ["Aruchi", "Anorexia"],
  ["Asya Lepa", "Stickiness/coating sensation in the mouth"],
  ["Madhura Asya", "Sweet taste in the mouth"],
  ["Kasa", "Cough"],
  ["Sthivana", "Excessive spitting/salivation"],
  ["Pinasa", "Chronic rhinitis"],
];

const amaSymptoms = [
  ["Vistambha", "Constipation / abdominal obstruction"],
  ["Praseka", "Excessive salivation"],
  ["Shoola", "Pain"],
  ["Vidaha", "Burning sensation"],
  ["Aruchi", "Anorexia"],
  ["Gaurava", "Heaviness"],
];

const ajeernaSymptoms = [
  ["Vishtambha", "Abdominal distension"],
  ["Sadana", "Feeling of prostration / exhaustion"],
  ["Shira Ruk", "Headache"],
  ["Murchha", "Fainting"],
  ["Bhrama", "Giddiness / dizziness"],
  ["Prishta-Kati Graha", "Stiffness of back and lumbar region"],
  ["Jrumbha", "Yawning"],
  ["Anga Marda", "Malaise / body ache"],
  ["Trishna", "Morbid thirst"],
  ["Jwara", "Fever"],
  ["Chardi", "Vomiting"],
  ["Pravahana", "Tenesmus / straining"],
  ["Aruchi", "Anorexia"],
  ["Avipaka", "Indigestion of food"],
];

const symptomGroups = [
  { key: "vatajaGrahani", title: "Vataja Grahani Lakshana", data: vatajaGrahani },
  { key: "pittajaGrahani", title: "Pittaja Grahani Lakshana", data: pittajaGrahani },
  { key: "kaphajaGrahani", title: "Kaphaja Grahani Lakshana", data: kaphajaGrahani },
];

function AgniAmaSection({ data = {}, onChange }) {
  const [formData, setFormData] = useState({ ...initialData, ...data });
  const [activeTab, setActiveTab] = useState("agni");

  const updateData = (updatedData) => {
    setFormData(updatedData);
    if (onChange) onChange(updatedData);
  };

  const handleChange = (key, value) => {
    updateData({ ...formData, [key]: value });
  };

  const toggleItem = (key, value) => {
    const current = formData[key] || [];
    const updated = current.includes(value)
      ? current.filter((item) => item !== value)
      : [...current, value];

    updateData({ ...formData, [key]: updated });
  };

  const resetAll = () => {
    setFormData(initialData);
    if (onChange) onChange(initialData);
  };

  const saveData = () => {
  const assessment = {
    agniType: formData.agniType || "Not assessed",
    agniAssessment: formData.agniAssessment || "",
    grahaniFindings: totalGrahaniSelected,
    amaFindings: formData.amaSymptoms?.length || 0,
    ajeernaFindings: formData.ajeernaSymptoms?.length || 0,
    clinicalNotes: formData.clinicalNotes || "",
  };

  const updatedData = {
    ...formData,
    assessment,
  };

  setFormData(updatedData);

  if (onChange) {
    onChange(updatedData);
  }

  alert("Agni & Ama assessment saved successfully.");
};
  const totalGrahaniSelected =
    formData.vatajaGrahani.length +
    formData.pittajaGrahani.length +
    formData.kaphajaGrahani.length;

  return (
    <div className="w-full bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
      <div className="px-6 py-5 bg-gradient-to-r from-orange-50 to-amber-50 border-b">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold text-slate-800">Agni & Ama</h2>
            <p className="text-sm text-slate-600 mt-1">
              Assessment of digestive function, Grahani Lakshana, Ama and Ajeerna
            </p>
          </div>

          <div className="bg-white rounded-xl px-4 py-3 border border-orange-100">
            <p className="text-xs text-slate-500">Combined Section</p>
            <p className="text-lg font-bold text-orange-700">11 • Agni & Ama</p>
          </div>
        </div>
      </div>

      <div className="px-5 pt-5">
        <div className="grid grid-cols-3 gap-2 bg-slate-100 rounded-xl p-1">
          {[
            ["agni", "Agni"],
            ["grahani", "Grahani"],
            ["ama", "Ama & Ajeerna"],
          ].map(([key, label]) => (
            <button
              key={key}
              type="button"
              onClick={() => setActiveTab(key)}
              className={`py-3 rounded-lg text-sm font-bold ${
                activeTab === key
                  ? "bg-white text-orange-700 shadow-sm"
                  : "text-slate-600"
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      <div className="p-5">
        {activeTab === "agni" && (
          <div className="grid grid-cols-1 xl:grid-cols-[1fr_320px] gap-5">
            <div className="border rounded-xl overflow-hidden">
              <div className="px-5 py-4 bg-orange-50 border-b">
                <h3 className="font-bold text-orange-800">
                  Agni Assessment
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Select the clinically assessed Agni type.
                </p>
              </div>

              <div className="p-5 space-y-3">
                {agniTypes.map((type) => (
                  <label
                    key={type.value}
                    className={`flex gap-4 p-4 border rounded-xl cursor-pointer ${
                      formData.agniType === type.value
                        ? "border-orange-400 bg-orange-50"
                        : "border-slate-200"
                    }`}
                  >
                    <input
                      type="radio"
                      name="agniType"
                      value={type.value}
                      checked={formData.agniType === type.value}
                      onChange={(e) =>
                        handleChange("agniType", e.target.value)
                      }
                      className="mt-1 w-4 h-4"
                    />

                    <div>
                      <h4 className="font-bold text-slate-800">
                        {type.title}
                      </h4>
                      <p className="text-sm text-slate-600 mt-1">
                        {type.description}
                      </p>
                    </div>
                  </label>
                ))}

                <div className="pt-3">
                  <label className="block text-sm font-semibold text-slate-700 mb-2">
                    Agni Assessment / Clinical Notes
                  </label>

                  <textarea
                    rows="6"
                    value={formData.agniAssessment}
                    onChange={(e) =>
                      handleChange("agniAssessment", e.target.value)
                    }
                    placeholder="Enter observations about appetite, digestion, bowel response to food and other clinical findings..."
                    className="w-full border border-slate-300 rounded-xl px-4 py-3 text-sm resize-y outline-none focus:ring-2 focus:ring-orange-300"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="border rounded-xl overflow-hidden">
                <div className="px-4 py-3 bg-orange-50 border-b">
                  <h3 className="font-bold text-orange-800">Agni Summary</h3>
                </div>

                <div className="p-4">
                  <div className="border rounded-lg p-4">
                    <p className="text-xs text-slate-500">Selected Agni</p>
                    <p className="text-lg font-bold text-slate-800 mt-1">
                      {agniTypes.find(
                        (item) => item.value === formData.agniType
                      )?.title || "Not assessed"}
                    </p>
                  </div>
                </div>
              </div>

              <div className="border rounded-xl bg-amber-50 border-amber-200 p-4">
                <h3 className="font-bold text-amber-800 mb-2">
                  Clinical Reminder
                </h3>
                <p className="text-sm text-slate-700">
                  Agni type should be confirmed by the treating doctor using
                  the complete case findings.
                </p>
              </div>
            </div>
          </div>
        )}

        {activeTab === "grahani" && (
          <div className="space-y-5">
            {symptomGroups.map((group) => (
              <SymptomGroup
                key={group.key}
                group={group}
                selected={formData[group.key]}
                onToggle={toggleItem}
              />
            ))}

            <div className="border rounded-xl bg-blue-50 border-blue-200 p-4">
              <p className="text-sm text-slate-700">
                Total Grahani findings selected:{" "}
                <strong>{totalGrahaniSelected}</strong>
              </p>
            </div>
          </div>
        )}

        {activeTab === "ama" && (
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
            <SymptomGroup
              group={{
                key: "amaSymptoms",
                title: "Ama Lakshana",
                data: amaSymptoms,
              }}
              selected={formData.amaSymptoms}
              onToggle={toggleItem}
            />

            <SymptomGroup
              group={{
                key: "ajeernaSymptoms",
                title: "Ajirna / Ajeerna Lakshana",
                data: ajeernaSymptoms,
              }}
              selected={formData.ajeernaSymptoms}
              onToggle={toggleItem}
            />

            <div className="border rounded-xl xl:col-span-2">
              <div className="px-5 py-4 bg-slate-50 border-b">
                <h3 className="font-bold text-slate-800">
                  Ama & Ajeerna Clinical Notes
                </h3>
              </div>

              <div className="p-5 grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">
                    Ama Notes
                  </label>
                  <textarea
                    rows="5"
                    value={formData.amaNotes}
                    onChange={(e) =>
                      handleChange("amaNotes", e.target.value)
                    }
                    placeholder="Enter additional clinical observations related to Ama..."
                    className="w-full border border-slate-300 rounded-xl px-4 py-3 text-sm resize-y outline-none focus:ring-2 focus:ring-orange-300"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">
                    Ajeerna Notes
                  </label>
                  <textarea
                    rows="5"
                    value={formData.ajeernaNotes}
                    onChange={(e) =>
                      handleChange("ajeernaNotes", e.target.value)
                    }
                    placeholder="Enter additional observations related to Ajeerna..."
                    className="w-full border border-slate-300 rounded-xl px-4 py-3 text-sm resize-y outline-none focus:ring-2 focus:ring-orange-300"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="border rounded-xl mt-6">
          <div className="px-5 py-4 bg-slate-50 border-b">
            <h3 className="font-bold text-slate-800">Doctor's Final Notes</h3>
          </div>

          <div className="p-5">
            <textarea
              rows="4"
              value={formData.clinicalNotes}
              onChange={(e) =>
                handleChange("clinicalNotes", e.target.value)
              }
              placeholder="Enter overall clinical interpretation of Agni, Grahani, Ama and Ajeerna..."
              className="w-full border border-slate-300 rounded-xl px-4 py-3 text-sm resize-y outline-none focus:ring-2 focus:ring-orange-300"
            />
          </div>
        </div>

        <div className="flex flex-col sm:flex-row justify-between gap-3 mt-6">
          <button
            type="button"
            onClick={resetAll}
            className="px-6 py-3 border border-slate-300 rounded-xl font-semibold text-slate-700 hover:bg-slate-50"
          >
            ↻ Reset All
          </button>

          <button
            type="button"
            onClick={saveData}
            className="px-7 py-3 rounded-xl font-semibold text-white bg-orange-600 hover:bg-orange-700"
          >
            ✓ Save Agni & Ama
          </button>
        </div>
      </div>
    </div>
  );
}

function SymptomGroup({ group, selected = [], onToggle }) {
  return (
    <div className="border rounded-xl overflow-hidden">
      <div className="px-5 py-4 bg-slate-50 border-b flex justify-between items-center">
        <div>
          <h3 className="font-bold text-slate-800">{group.title}</h3>
          <p className="text-xs text-slate-500 mt-1">
            Select observed findings
          </p>
        </div>

        <span className="text-xs font-bold text-orange-700">
          {selected.length} selected
        </span>
      </div>

      <div className="p-5 grid grid-cols-1 md:grid-cols-2 gap-3">
        {group.data.map(([term, meaning]) => (
          <label
            key={term}
            className={`flex gap-3 p-3 border rounded-lg cursor-pointer ${
              selected.includes(term)
                ? "bg-orange-50 border-orange-300"
                : "bg-white border-slate-200"
            }`}
          >
            <input
              type="checkbox"
              checked={selected.includes(term)}
              onChange={() => onToggle(group.key, term)}
              className="mt-1 w-4 h-4"
            />

            <div>
              <p className="font-semibold text-sm text-slate-800">{term}</p>
              <p className="text-xs text-slate-500 mt-1">{meaning}</p>
            </div>
          </label>
        ))}
      </div>
    </div>
  );
}

export default AgniAmaSection;
