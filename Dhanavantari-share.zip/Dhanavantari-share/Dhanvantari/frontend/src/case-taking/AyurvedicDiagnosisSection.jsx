import React, { useState } from "react";



const initialDiagnosis = {
  diagnosis: "",
  clinicalSummary: "",
};

function AyurvedicDiagnosisSection({ data = {}, onChange }) {
  const [generatingSummary, setGeneratingSummary] = useState(false);
      const [aiSummary, setAiSummary] = useState("");

      const handleGenerateSummary = async () => {
  try {
    if (!formData.diagnosis?.trim()) {
      alert("Please enter the Ayurvedic diagnosis first.");
      return;
    }

    setGeneratingSummary(true);
    setAiSummary("");

    const token = localStorage.getItem("token");

    const response = await fetch("/api/ai/clinical-summary", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        medicalSystem: "Ayurveda",
        diagnosis: formData.diagnosis,
        caseData: data,
      }),
    });

    const result = await response.json();

    if (!response.ok) {
      throw new Error(
        result.message || "Failed to generate clinical summary"
      );
    }

    const summary = result.clinicalSummary || "";

    setAiSummary(summary);
    updateField("clinicalSummary", summary);
  } catch (error) {
    console.error("AI summary error:", error);
    alert(error.message);
  } finally {
    setGeneratingSummary(false);
  }
};

     






  const [formData, setFormData] = useState({
    ...initialDiagnosis,
    ...(data.ayurvedicDiagnosis || {}),
  });

  const updateField = (field, value) => {
    const updated = {
      ...formData,
      [field]: value,
    };

    setFormData(updated);

    if (onChange) {
      onChange({
        ...data,
        ayurvedicDiagnosis: updated,
      });
    }
  };

  const resetAll = () => {
    setFormData(initialDiagnosis);

    if (onChange) {
      onChange({
        ...data,
        ayurvedicDiagnosis: initialDiagnosis,
      });
    }
  };

 const saveDiagnosis = () => {
  const finalDiagnosis = {
    ...formData,
    clinicalSummary: aiSummary || formData.clinicalSummary || "",
  };

  setFormData(finalDiagnosis);

  if (onChange) {
    onChange({
      ...data,
      ayurvedicDiagnosis: finalDiagnosis,
    });
  }

  alert("Ayurvedic Diagnosis saved successfully.");
};

  return (
    <section className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">

      {/* =====================================================
          HEADER
      ====================================================== */}
      <div className="bg-gradient-to-r from-emerald-700 via-emerald-600 to-cyan-600 px-6 py-7 text-white">

        <div className="flex items-center gap-4">

          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white/15 text-2xl shadow-inner backdrop-blur">
            🩺
          </div>

          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-emerald-100">
              Section 17
            </p>

            <h2 className="mt-1 text-2xl font-bold">
              Ayurvedic Diagnosis
            </h2>

            <p className="mt-1 text-sm text-emerald-50">
              Clinical interpretation and final Ayurvedic assessment
            </p>
          </div>

        </div>

      </div>

      {/* =====================================================
          CONTENT
      ====================================================== */}
      <div className="p-5 sm:p-7">

        <div className="grid gap-6 xl:grid-cols-[1.15fr_0.85fr]">

          {/* =================================================
              LEFT — DOCTOR INPUT
          ================================================= */}
          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-5">

            <div className="mb-6">
              <div className="flex items-center gap-3">

                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-100 text-lg">
                  ✍️
                </div>

                <div>
                  <h3 className="font-bold text-slate-800">
                    Doctor's Clinical Assessment
                  </h3>

                  <p className="text-xs text-slate-500">
                    Enter the final clinical interpretation based on the
                    completed case.
                  </p>
                </div>

              </div>
            </div>

            {/* Diagnosis */}
            <div className="mb-5">

              <label className="mb-2 block text-sm font-bold text-slate-700">
                Ayurvedic Diagnosis
              </label>

              <input
                type="text"
                value={formData.diagnosis || ""}
                onChange={(e) =>
                  updateField("diagnosis", e.target.value)
                }
                placeholder="Enter the final Ayurvedic diagnosis"
                className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-emerald-500 focus:ring-4 focus:ring-emerald-100"
              />

            </div>

            {/* Clinical Summary */}
            <div>

              <label className="mb-2 block text-sm font-bold text-slate-700">
                Clinical Summary
              </label>

              <textarea
                value={formData.clinicalSummary || ""}
                onChange={(e) =>
                  updateField("clinicalSummary", e.target.value)
                }
                rows={12}
                placeholder="Write the clinical summary based on the patient's history, examination, Prakruthi, Vikruthi, Dosha, Dhatu, Mala, Agni, Pariksha findings and investigations..."
                className="w-full resize-y rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm leading-6 text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-emerald-500 focus:ring-4 focus:ring-emerald-100"
              />

              <p className="mt-2 text-xs leading-5 text-slate-500">
                The doctor's clinical interpretation remains the primary
                clinical input. AI-assisted summarization can be performed
                later using the completed case information.
              </p>

            </div>
                          {aiSummary && (
                <div className="mt-4 rounded-xl border border-blue-200 bg-blue-50 p-4">
                  <div className="mb-2 flex items-center gap-2">
                    <span className="text-lg">✨</span>
                    <h4 className="font-bold text-blue-800">
                      AI-Generated Clinical Summary
                    </h4>
                  </div>

                  <textarea
                    value={aiSummary}
                    onChange={(e) => setAiSummary(e.target.value)}
                    rows={10}
                    className="w-full resize-y rounded-xl border border-blue-200 bg-white px-4 py-3 text-sm leading-6 text-slate-700 outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-100"
                  />

                  <p className="mt-2 text-xs text-blue-700">
                    Review and edit the AI-generated summary before using it clinically.
                  </p>
  </div>
)}




          </div>

          {/* =================================================
              RIGHT — ASSESSMENT SUMMARY
          ================================================= */}
          <AssessmentSummary data={data} />

        </div>

        {/* =================================================
            AI INFORMATION
        ================================================= */}
        <div className="mt-6 rounded-2xl border border-blue-200 bg-gradient-to-r from-blue-50 to-cyan-50 p-5">

          <div className="flex gap-4">

            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-blue-100 text-lg">
              ✨
            </div>

            <div>
              <h3 className="font-bold text-blue-800">
                AI-Assisted Clinical Mapping
              </h3>

              <p className="mt-1 text-sm leading-6 text-slate-600">
                The completed assessment can later be used for
                AI-assisted case summarization and clinical mapping.
                The doctor's diagnosis and clinical judgement remain
                the primary clinical input.
              </p>
            </div>

          </div>

        </div>

        {/* =================================================
            BUTTONS
        ================================================= */}
        <div className="mt-6 flex flex-col-reverse gap-3 sm:flex-row sm:items-center sm:justify-between">

          <button
            type="button"
            onClick={resetAll}
            className="rounded-xl border border-slate-300 bg-white px-6 py-3 text-sm font-bold text-slate-600 transition hover:bg-slate-50"
          >
            ↻ Reset
          </button>

          <button
            type="button"
            onClick={handleGenerateSummary}
            disabled={generatingSummary}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
          >
            {generatingSummary ? "Generating..." : "Generate Clinical Summary"}
          </button>

          <button
            type="button"
            onClick={saveDiagnosis}
            className="rounded-xl bg-gradient-to-r from-emerald-600 to-cyan-600 px-7 py-3 text-sm font-bold text-white shadow-md transition hover:-translate-y-0.5 hover:shadow-lg"
          >
            ✓ Save Diagnosis
          </button>

        </div>

      </div>

    </section>
  );
}


/* =========================================================
   ASSESSMENT SUMMARY
========================================================= */

const AssessmentSummary = ({ data }) => {

  const prakruthi = data.prakruthi?.assessment;
  const vikruthi = data.vikruthi?.assessment;

  const hasAssessment =
    prakruthi ||
    vikruthi ||
    data.doshaDhatuMala ||
    data.agniAma ||
    data.dashavidha ||
    data.ashtasthana ||
    data.generalExamination ||
    data.systemicExamination ||
    data.investigations;

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5">

      {/* Header */}
      <div className="mb-5 flex items-center justify-between">

        <div>
          <h3 className="text-lg font-bold text-slate-800">
            Assessment Summary
          </h3>

          <p className="mt-1 text-xs text-slate-500">
            Key findings from the completed case
          </p>
        </div>

        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600">
          ✓
        </div>

      </div>

      {!hasAssessment && (
        <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50 px-5 py-10 text-center">

          <div className="text-3xl">
            📋
          </div>

          <p className="mt-3 text-sm font-semibold text-slate-600">
            No assessment results yet
          </p>

          <p className="mt-1 text-xs text-slate-400">
            Complete the case assessment sections to see their results here.
          </p>

        </div>
      )}

      <div className="space-y-3">

        {/* PRAKRUTHI */}
        {prakruthi?.dominantPrakruthi && (
          <ResultCard
            title="Prakruthi"
            icon="🧘"
            color="emerald"
            result={prakruthi.dominantPrakruthi}
            subtitle={`${prakruthi.totalSelections || 0} characteristics assessed`}
          />
        )}

        {/* VIKRUTHI */}
        {vikruthi?.predominant && (
          <ResultCard
            title="Vikruthi"
            icon="📊"
            color="blue"
            result={vikruthi.predominant}
            subtitle={`${vikruthi.total || 0} findings assessed`}
          />
        )}

       {/* DOSHA, DHATU & MALA */}
          {data.doshaDhatuMala?.assessment && (
            <div className="rounded-xl border border-purple-200 bg-purple-50/50 p-4">

              <div className="flex items-center gap-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-purple-100 text-purple-700">
                  🧬
                </div>

                <div>
                  <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                    Dosha, Dhatu & Mala
                  </p>

                  <p className="mt-1 font-bold text-slate-800">
                    {data.doshaDhatuMala.assessment.mindDoshaCount || 0} Mind Dosha selected
                  </p>
                </div>
              </div>

              <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-3">

                <div className="rounded-lg bg-white p-3">
                  <p className="text-xs text-slate-400">Mind Dosha</p>
                  <p className="mt-1 text-sm font-semibold text-slate-700">
                    {data.doshaDhatuMala.assessment.mindDoshas?.join(", ") ||
                      "Not assessed"}
                  </p>
                </div>

                <div className="rounded-lg bg-white p-3">
                  <p className="text-xs text-slate-400">Dhatu Findings</p>
                  <p className="mt-1 text-sm font-semibold text-slate-700">
                    {data.doshaDhatuMala.assessment.dhatuFindingsCount || 0}
                  </p>
                </div>

                <div className="rounded-lg bg-white p-3">
                  <p className="text-xs text-slate-400">Mala</p>
                  <p className="mt-1 text-sm font-semibold text-slate-700">
                    {[
                      data.doshaDhatuMala.assessment.malaSummary?.purisha,
                      data.doshaDhatuMala.assessment.malaSummary?.sweda,
                      data.doshaDhatuMala.assessment.malaSummary?.mutra,
                    ]
                      .filter(
                        (value) => value && value !== "Not assessed"
                      )
                      .join(" • ") || "Not assessed"}
                  </p>
                </div>

              </div>

            </div>
          )}
          {/* AGNI & AMA */}
            {data.agniAma?.assessment && (
              <div className="rounded-xl border border-orange-200 bg-orange-50/50 p-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-orange-100 text-orange-700">
                    🔥
                  </div>

                  <div>
                    <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                      Agni & Ama
                    </p>

                    <p className="mt-1 font-bold text-slate-800">
                      {data.agniAma.assessment.agniType || "Not assessed"}
                    </p>
                  </div>
                </div>

                <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-3">
                  <div className="rounded-lg bg-white p-3">
                    <p className="text-xs text-slate-400">Grahani Findings</p>
                    <p className="mt-1 text-sm font-semibold text-slate-700">
                      {data.agniAma.assessment.grahaniFindings || 0}
                    </p>
                  </div>

                  <div className="rounded-lg bg-white p-3">
                    <p className="text-xs text-slate-400">Ama Findings</p>
                    <p className="mt-1 text-sm font-semibold text-slate-700">
                      {data.agniAma.assessment.amaFindings || 0}
                    </p>
                  </div>

                  <div className="rounded-lg bg-white p-3">
                    <p className="text-xs text-slate-400">Ajeerna Findings</p>
                    <p className="mt-1 text-sm font-semibold text-slate-700">
                      {data.agniAma.assessment.ajeernaFindings || 0}
                    </p>
                  </div>
                </div>

                {data.agniAma.assessment.agniAssessment && (
                  <div className="mt-3 rounded-lg bg-white p-3">
                    <p className="text-xs text-slate-400">Clinical Assessment</p>
                    <p className="mt-1 text-sm text-slate-700">
                      {data.agniAma.assessment.agniAssessment}
                    </p>
                  </div>
                )}
                {/* DASHAVIDHA PARIKSHA */}
{data.dashavidha?.assessment && (
  <div className="rounded-xl border border-emerald-200 bg-emerald-50/50 p-4">
    <div className="flex items-center gap-3">
      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-100 text-emerald-700">
        🩺
      </div>

      <div>
        <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
          Dashavidha Pariksha
        </p>
        <p className="mt-1 font-bold text-slate-800">
          Ten-fold clinical assessment completed
        </p>
      </div>
    </div>

    <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-4">
      {[
        ["Sara", data.dashavidha.assessment.sara],
        ["Samhanana", data.dashavidha.assessment.samhanana],
        ["Pramana", data.dashavidha.assessment.pramana],
        ["Satmya", data.dashavidha.assessment.satmya],
        ["Sattva", data.dashavidha.assessment.sattva],
        ["Ahara Shakti", data.dashavidha.assessment.aharaShakti],
        ["Vyayama Shakti", data.dashavidha.assessment.vyayamaShakti],
        ["Vaya", data.dashavidha.assessment.vaya],
      ].map(([label, value]) => (
        <div key={label} className="rounded-lg bg-white p-3">
          <p className="text-xs text-slate-400">{label}</p>
          <p className="mt-1 text-sm font-semibold text-slate-700">
            {value || "Not assessed"}
          </p>
        </div>
      ))}

      {/* ASHTASTHANA PARIKSHA */}
{data.ashtasthana?.assessment && (
  <div className="rounded-xl border border-cyan-200 bg-cyan-50/50 p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-cyan-100 text-cyan-700">
                🩺
              </div>

              <div>
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                  Ashtasthana Pariksha
                </p>
                <p className="mt-1 font-bold text-slate-800">
                  {data.ashtasthana.assessment.assessedCount || 0} / 8 examinations assessed
                </p>
              </div>
            </div>

            <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-4">
              {[
                ["Nadi", data.ashtasthana.assessment.nadi],
                ["Mutra", data.ashtasthana.assessment.mutra],
                ["Mala", data.ashtasthana.assessment.mala],
                ["Jihva", data.ashtasthana.assessment.jihva],
                ["Shabda", data.ashtasthana.assessment.shabda],
                ["Sparsha", data.ashtasthana.assessment.sparsha],
                ["Drika", data.ashtasthana.assessment.drika],
                ["Akriti", data.ashtasthana.assessment.akriti],
              ].map(([label, value]) => (
                <div key={label} className="rounded-lg bg-white p-3">
                  <p className="text-xs text-slate-400">{label}</p>
                  <p className="mt-1 text-sm font-semibold text-slate-700">
                    {value || "Not assessed"}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}
        {/* GENERAL EXAMINATION */}
{data.generalExamination?.assessment && (
  <div className="rounded-xl border border-teal-200 bg-teal-50/50 p-4">
    <div className="flex items-center gap-3">
      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-teal-100 text-teal-700">
        🩺
      </div>

      <div>
        <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
          General Examination
        </p>
        <p className="mt-1 font-bold text-slate-800">
          {data.generalExamination.assessment.assessedFields || 0} /{" "}
          {data.generalExamination.assessment.totalFields || 0} fields assessed
        </p>
      </div>
    </div>

    <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-4">
      {[
        ["Appearance", data.generalExamination.assessment.generalAppearance],
        ["Consciousness", data.generalExamination.assessment.consciousness],
        ["Orientation", data.generalExamination.assessment.orientation],
        ["Built", data.generalExamination.assessment.built],
        ["Nourishment", data.generalExamination.assessment.nourishment],
        ["Posture", data.generalExamination.assessment.posture],
        ["Gait", data.generalExamination.assessment.gait],
        ["Pallor", data.generalExamination.assessment.pallor],
        ["Icterus", data.generalExamination.assessment.icterus],
        ["Cyanosis", data.generalExamination.assessment.cyanosis],
        ["Clubbing", data.generalExamination.assessment.clubbing],
        ["Edema", data.generalExamination.assessment.edema],
      ].map(([label, value]) => (
        <div key={label} className="rounded-lg bg-white p-3">
          <p className="text-xs text-slate-400">{label}</p>
          <p className="mt-1 text-sm font-semibold text-slate-700">
            {value || "Not assessed"}
          </p>
        </div>
      ))}
    </div>

    <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-5">
      {[
        ["Temp", data.generalExamination.assessment.temperature],
        ["Pulse", data.generalExamination.assessment.pulse],
        ["Resp. Rate", data.generalExamination.assessment.respiratoryRate],
        ["BP", data.generalExamination.assessment.bloodPressure],
        ["SpO₂", data.generalExamination.assessment.spo2],
      ].map(([label, value]) => (
        <div key={label} className="rounded-lg bg-white p-3">
                <p className="text-xs text-slate-400">{label}</p>
                <p className="mt-1 text-sm font-semibold text-slate-700">
                  {value || "--"}
                </p>
              </div>
            ))}
          </div>

          {(data.generalExamination.assessment.height ||
            data.generalExamination.assessment.weight ||
            data.generalExamination.assessment.bmi) && (
            <div className="mt-3 rounded-lg bg-white p-3">
              <p className="text-xs text-slate-400">Anthropometry</p>
              <p className="mt-1 text-sm font-semibold text-slate-700">
                Height: {data.generalExamination.assessment.height || "--"} cm
                {" • "}
                Weight: {data.generalExamination.assessment.weight || "--"} kg
                {" • "}
                BMI: {data.generalExamination.assessment.bmi || "--"}
              </p>
            </div>
          )}
        </div>
      )}

      {/* SYSTEMIC EXAMINATION */}
{data.systemicExamination?.assessment && (
  <div className="rounded-xl border border-indigo-200 bg-indigo-50/50 p-4">
    <div className="flex items-center gap-3">
      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-indigo-100 text-indigo-700">
        🫀
      </div>

      <div>
        <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
          Systemic Examination
        </p>
        <p className="mt-1 font-bold text-slate-800">
          {data.systemicExamination.assessment.assessedFields || 0} /{" "}
          {data.systemicExamination.assessment.totalFields || 0} fields assessed
        </p>
      </div>
    </div>

    <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-4">
      {[
        ["Cardiovascular", data.systemicExamination.assessment.cardiovascular],
        ["Respiratory", data.systemicExamination.assessment.respiratory],
        ["Gastrointestinal", data.systemicExamination.assessment.gastrointestinal],
        ["Nervous", data.systemicExamination.assessment.nervous],
        ["Musculoskeletal", data.systemicExamination.assessment.musculoskeletal],
        ["Genitourinary", data.systemicExamination.assessment.genitourinary],
        ["Endocrine", data.systemicExamination.assessment.endocrine],
      ].map(([label, system]) => (
        <div key={label} className="rounded-lg bg-white p-3">
              <p className="text-xs text-slate-400">{label}</p>
              <p className="mt-1 text-sm font-semibold text-slate-700">
                {system
                  ? Object.values(system).filter(Boolean).length + " findings recorded"
                  : "Not assessed"}
              </p>
            </div>
          ))}
        </div>

        {data.systemicExamination.assessment.otherSystems && (
          <div className="mt-3 rounded-lg bg-white p-3">
            <p className="text-xs text-slate-400">Other Systemic Findings</p>
            <p className="mt-1 text-sm text-slate-700">
              {data.systemicExamination.assessment.otherSystems}
            </p>
          </div>
        )}
      </div>
    )}

    {/* INVESTIGATIONS */}
{data.investigations?.assessment && (
  <div className="rounded-xl border border-amber-200 bg-amber-50/50 p-4">
    <div className="flex items-center gap-3">
      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-amber-100 text-amber-700">
        🔬
      </div>

      <div>
        <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
          Investigations
        </p>
        <p className="mt-1 font-bold text-slate-800">
          {data.investigations.assessment.completedInvestigations || 0} /{" "}
          {data.investigations.assessment.totalInvestigations || 0} investigations recorded
        </p>
      </div>
    </div>

    <div className="mt-3 space-y-2">
      {(data.investigations.assessment.investigations || []).map(
        (item, index) => (
          <div
            key={index}
            className="rounded-lg bg-white p-3"
          >
            <p className="text-sm font-semibold text-slate-700">
              {item.name}
            </p>

            <p className="mt-1 text-xs text-slate-500">
              {item.type}
              {item.result && ` • Result: ${item.result}`}
              {item.unit && ` ${item.unit}`}
            </p>

            {item.remarks && (
              <p className="mt-1 text-xs text-slate-600">
                {item.remarks}
              </p>
            )}
          </div>
        )
      )}
    </div>
  </div>
)}

   









    </div>
  </div>
)}




              </div>
            )}
      </div>

    </div>
  );
};


/* =========================================================
   RESULT CARD
========================================================= */

const ResultCard = ({ title, icon, result, color, subtitle }) => {

  const colorClasses = {
    emerald: "border-emerald-200 bg-emerald-50/60",
    blue: "border-blue-200 bg-blue-50/60",
  };

  const iconClasses = {
    emerald: "bg-emerald-100 text-emerald-700",
    blue: "bg-blue-100 text-blue-700",
  };

  return (
    <div
      className={`rounded-xl border p-4 ${
        colorClasses[color]
      }`}
    >

      <div className="flex items-center gap-3">

        <div
          className={`flex h-9 w-9 items-center justify-center rounded-lg ${
            iconClasses[color]
          }`}
        >
          {icon}
        </div>

        <div className="min-w-0">

          <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
            {title}
          </p>

          <p className="mt-1 font-bold text-slate-800">
            {result}
          </p>
          {subtitle && (
              <p className="mt-1 text-xs text-slate-500">
                {subtitle}
              </p>
            )}

        </div>

      </div>

    </div>
  );
};


/* =========================================================
   SIMPLE RESULT
========================================================= */

const SimpleResult = ({ title, value }) => {

  return (
    <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">

      <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">
        {title}
      </p>

      <p className="mt-1 text-sm font-semibold text-slate-700">
        {value}
      </p>

    </div>
  );
};


/* =========================================================
   EXTRACT MEANINGFUL RESULT
========================================================= */

const getAssessmentText = (section) => {

  if (!section || typeof section !== "object") {
    return "Assessment completed";
  }

  if (section.assessment) {

    if (typeof section.assessment === "string") {
      return section.assessment;
    }

    if (section.assessment.result) {
      return section.assessment.result;
    }

    if (section.assessment.summary) {
      return section.assessment.summary;
    }

    if (section.assessment.interpretation) {
      return section.assessment.interpretation;
    }
  }

  if (section.result) {
    return section.result;
  }

  if (section.summary) {
    return section.summary;
  }

  if (section.interpretation) {
    return section.interpretation;
  }

  return "Assessment completed";
};


export default AyurvedicDiagnosisSection;