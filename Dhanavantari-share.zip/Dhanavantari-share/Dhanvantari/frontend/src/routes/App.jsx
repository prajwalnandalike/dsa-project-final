// import { useState } from 'react'
import { useEffect, useState } from 'react'
import '../css/index.css'
import logo from '../assets/dhanvantarilogo.jpeg'
import AdminLogin from '../pages/AdminLogin';
import AdminDashboard from '../pages/AdminDashboard';
import DoctorLogin from '../pages/DoctorLogin';
import PatientLogin from '../pages/PatientLogin';
import DoctorDashboard from '../pages/DoctorDashboard';
import InternLogin from '../pages/InternLogin';
import InternDashboard from '../pages/InternDashboard';
import CaseTaking from '../case-taking/CaseTaking';
import AdminSignup from '../pages/AdminSignup';
import AdminOTPVerification from '../pages/AdminOTPVerfication';
import DoctorsManagement from '../pages/DoctorsManagement';
import InternsManagement from '../pages/InternManagement';
import AddDoctor from '../pages/AddDoctor';
import AddIntern from '../pages/AddIntern';
import PatientsManagement from '../pages/PatientsManagement';
import AddPatient from '../pages/AddPatient';
// import CarePopup from '../components/carePopup';
function App() {
  const [page, setPage] = useState("home");
  const [adminPhone, setAdminPhone]=useState("")

// ================= signuppp PAGES =================
          if (page === "admin-signup") {
                  return (
                    
                      <AdminSignup  onBack={()=>setPage("admin")}
                      onSignupSuccess={()=>setPage("admin")}/> 

                    );
                  }
                  if (page === "admin-otp") {
                      return (
                        <AdminOTPVerification
                          phoneNumber={adminPhone}
                          onVerified={() => setPage("admin")}
                          onBack={() => setPage("admin-signup")}
                        />
                      );
                    }

  // ================= LOGIN PAGES =================

        if (page === "admin") {
          return (
            <div className="relative">
            
              <AdminLogin  onBack={()=>setPage("home")}
              onLoginSuccess={()=>setPage("admin-dashboard")}
              onSignup={()=>setPage("admin-signup")}
              /> 
            </div>
            );
          }
          if(page==="doctor-dashboard"){
            return <DoctorDashboard onStartCaseTaking={()=>setPage("case-taking")}/>
          }
          if(page==="case-taking"){
            return <CaseTaking/>
          }
          if(page==="add-patient"){
            return (
              <AddPatient
              onBack={()=>setPage("patient-management")}
              
              />
            )
          }
          if(page==="admin-dashboard"){
            return <AdminDashboard 
            onDashboard={()=>setPage("admin-dashboard")}
            onDoctors={()=>setPage("doctors-management")}
            onInterns={()=>setPage("interns-management")}
            onPatients={()=>setPage("patients-management")}
            />
          }
          if (page === "interns-management") {
              return (
                <InternsManagement
                  onBack={() => setPage("admin-dashboard")}
                  onAddIntern={()=>setPage("add-intern")}
                />
              );
            }

          if(page==="doctors-management"){
            return (
              <DoctorsManagement onBack={()=>setPage("admin-dashboard")}
              onAddDoctor={()=>setPage("add-doctor")}
              />
            )
          }
          if(page==="patients-management"){
            return (
              <PatientsManagement onBack={()=>setPage("admin-dashboard")}
              onNewPatient={()=>setPage("add-patient")}
              />
            )
          }

          if (page === "add-doctor") {
              return (
                <AddDoctor
                  onBack={() => setPage("doctors-management")}
                />
              );
            }

            if (page === "add-intern") {
              return (
                <AddIntern
                  onBack={() => setPage("interns-management")}
                />
              );
            }
          if(page==="intern-dashboard"){
            return <InternDashboard onStartCaseTaking={()=>setPage("case-taking")}/>
          }

            if (page === "doctor") {
              return (
                <div className="relative">
                  <DoctorLogin  onBack={()=>setPage("home")}
                    onLoginSuccess={()=>setPage("doctor-dashboard")}/>
                </div>
              );
            }

            if (page === "patient") {
              return (
                <div className="relative">
                  <PatientLogin  onBack={()=>setPage("home")} />
                </div>
              );
            }
            if (page === "intern") {
          return (
            <div className="relative">
              <InternLogin onBack={() => setPage("home")} 
                onLoginSuccess={()=>setPage("intern-dashboard")}/>
            </div>
          );
        }
          
              
          

  // ================= HOME PAGE =================

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-cyan-50">

      {/* ================= NAVBAR ================= */}

      <header className="flex items-center justify-between bg-gradient-to-r from-green-800 via-green-700 to-cyan-600 px-6 py-4 text-white shadow-lg">

        <div className="flex items-center gap-3">

          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/15 p-1">
            <img
              src={logo}
              alt="Dhanvantari Logo"
              className="h-full w-full rounded-lg object-contain"
            />
          </div>

          <div>
            <h1 className="text-xl font-bold">
              Dhanvantari
            </h1>

            <p className="text-xs text-green-100">
              Smart AYUSH Care Platform
            </p>
          </div>

        </div>

        <div className="hidden rounded-full bg-white/10 px-4 py-2 text-sm font-medium sm:block">
          Secure Healthcare
        </div>

      </header>


      {/* ================= MAIN ================= */}

      <main className="flex min-h-[calc(100vh-76px)] items-center justify-center px-5 py-12">

        <div className="w-full max-w-5xl">

          {/* Hero */}

          <div className="mb-10 text-center">

            <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-3xl bg-white p-2 shadow-xl">

              <img
                src={logo}
                alt="Dhanvantari Logo"
                className="h-full w-full rounded-2xl object-contain"
              />

            </div>

            <p className="text-sm font-bold uppercase tracking-[0.25em] text-emerald-600">
              DHANVANTARI
            </p>

            <h2 className="mt-3 text-4xl font-bold tracking-tight text-slate-800 sm:text-5xl">
              Smart AYUSH
              <span className="text-emerald-600"> Care Platform</span>
            </h2>

            <p className="mx-auto mt-4 max-w-2xl text-sm leading-7 text-slate-500 sm:text-base">
              A secure digital platform connecting hospitals, doctors,
              interns and patients for structured AYUSH healthcare.
            </p>

          </div>


          {/* Login Selection Card */}

          <div className="rounded-3xl bg-white p-6 shadow-2xl sm:p-10">

            <div className="mb-8 text-center">

              <p className="text-sm font-semibold uppercase tracking-wider text-emerald-600">
                Secure Access
              </p>

              <h3 className="mt-2 text-2xl font-bold text-slate-800">
                Choose your portal
              </h3>

              <p className="mt-2 text-sm text-slate-500">
                Select the account type you want to sign in with.
              </p>

            </div>


            {/* Login Cards */}

            <div className="grid grid-cols-1 gap-5 md:grid-cols-4">

              {/* ADMIN */}

              <LoginCard
                icon="🏥"
                title="Admin"
                description="Manage hospital, doctors, interns and patients."
                buttonText="Admin Login"
                onClick={() => setPage("admin")}
              />


              {/* DOCTOR */}

              <LoginCard
                icon="🩺"
                title="Doctor"
                description="Manage clinical cases, patients and AYUSH care."
                buttonText="Doctor Login"
                onClick={() => setPage("doctor")}
              />


              {/* PATIENT */}

              <LoginCard
                icon="👤"
                title="Patient"
                description="Access your healthcare information and care."
                buttonText="Patient Login"
                onClick={() => setPage("patient")}
              />

                   {/* INTERN */}

              <LoginCard
                icon="🎓"
                title="Intern"
                description="Assist doctors with patient care, case taking and AYUSH clinical work."
                buttonText="Intern Login"
                onClick={() => setPage("intern")}
              />

            </div>


            {/* Security Information */}

            <div className="mt-8 grid grid-cols-1 gap-3 sm:grid-cols-3">

              <InfoBadge
                icon="🔐"
                text="Secure Authentication"
              />

              <InfoBadge
                icon="🏥"
                text="Hospital-Based Access"
              />

              <InfoBadge
                icon="🛡️"
                text="Role-Based Security"
              />

            </div>

          </div>


          {/* Footer */}

          <p className="mt-8 text-center text-xs text-slate-400">
            Dhanvantari • Smart AYUSH Care Platform
          </p>

        </div>

      </main>

    </div>
  );
}


/* ================================================= */
/* LOGIN CARD */
/* ================================================= */

const LoginCard = ({
  icon,
  title,
  description,
  buttonText,
  onClick,
}) => {
  return (
    <div className="group rounded-2xl border border-slate-200 bg-slate-50 p-6 transition duration-300 hover:-translate-y-1 hover:border-emerald-200 hover:bg-white hover:shadow-xl">

      <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-100 text-2xl transition group-hover:bg-emerald-600 group-hover:text-white">
        {icon}
      </div>

      <h4 className="text-xl font-bold text-slate-800">
        {title}
      </h4>

      <p className="mt-2 min-h-[48px] text-sm leading-6 text-slate-500">
        {description}
      </p>

      <button
        onClick={onClick}
        className="mt-6 w-full rounded-xl bg-gradient-to-r from-green-700 to-emerald-600 px-4 py-3 text-sm font-bold text-white shadow-lg shadow-emerald-100 transition hover:from-green-800 hover:to-emerald-700"
      >
        {buttonText} →
      </button>

    </div>
  );
};


/* ================================================= */
/* INFO BADGE */
/* ================================================= */

const InfoBadge = ({ icon, text }) => {
  return (
    <div className="flex items-center justify-center gap-2 rounded-xl bg-slate-50 px-4 py-3 text-xs font-medium text-slate-600">
      <span className="text-base">
        {icon}
      </span>

      {text}
    </div>
  );
};


export default App;


