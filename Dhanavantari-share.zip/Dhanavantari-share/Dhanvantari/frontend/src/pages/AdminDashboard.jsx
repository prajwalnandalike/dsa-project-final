import React, {useEffect, useState} from "react";
import DoctorsManagement from "./DoctorsManagement";

const AdminDashboard = ({onDashboard, onDoctors, onInterns, onPatients}) => {
     const [doctorCount, setDoctorCount] = useState(0);
          const [internCount, setInternCount] = useState(0);
            const [patientCount, setPatientCount] = useState(0);
            const [admittedCount, setAdmittedCount]=useState(0);
            const [dischargedCount, setDischargedCount]=useState(0);
            const [surgeryCount, setSurgeryCount]=useState(0);
            const [staffCount, setStaffCount]=useState(0);
            const [caseCount, setCaseCount]=useState(0);
            const [monthlyTrend, setMonthlyTrend]=useState([]);
            const [recentPatients, setRecentPatients]=useState([]);
            const [auditLogs, setAuditLogs]=useState([]);

          useEffect(() => {
            const fetchStaffCounts = async () => {
              try {
                const token = localStorage.getItem("token");

                const doctorResponse = await fetch("/api/doctors", {
                  headers: {
                    Authorization: `Bearer ${token}`,
                  },
                });

                const doctorData = await doctorResponse.json();

                if (doctorResponse.ok) {
                  setDoctorCount(
                    (doctorData.doctors || []).filter(
                      (doctor) => doctor.isActive
                    ).length
                  );
                }

                const internResponse = await fetch("/api/interns", {
                  headers: {
                    Authorization: `Bearer ${token}`,
                  },
                });

                const internData = await internResponse.json();

                if (internResponse.ok) {
                  setInternCount(
                    (internData.interns || []).filter(
                      (intern) => intern.isActive
                    ).length
                  );
                }
                const patientResponse = await fetch("/api/patients", {
                          headers: {
                            Authorization: `Bearer ${token}`,
                          },
                        });

                        const patientData = await patientResponse.json();

                        if (patientResponse.ok) {
                          setPatientCount(patientData.stats?.registeredToday || 0);
                          setAdmittedCount(patientData.stats?.admittedPatients || 0);
                          setRecentPatients(patientData.patients || []);

                          const patients = patientData.patients || [];

                              const monthlyCounts = Array(12).fill(0);

                              patients.forEach((patient) => {
                                const month = new Date(patient.createdAt).getMonth();
                                monthlyCounts[month]++;
                              });

                              setMonthlyTrend(monthlyCounts);
                         }
                         const auditResponse = await fetch("/api/audit", {
                                  headers: {
                                    Authorization: `Bearer ${token}`,
                                  },
                                });

                                const auditData = await auditResponse.json();

                                if (auditResponse.ok) {
                                  setAuditLogs(auditData.logs || []);
                                }



              } catch (error) {
                console.error("Failed to fetch staff counts:", error);
              }
            };


            fetchStaffCounts();
          }, []);


  const stats = [
    {
      title: "Patients Today",
      value: patientCount,
      change: "12%",
      direction: "↑",
      icon: "👥",
    },
    {
      title: "Currently Admitted",
      value: admittedCount,
      change: "5%",
      direction: "↑",
      icon: "🛏️",
    },
    {
      title: "Discharged Today",
      value: dischargedCount,
      change: "3%",
      direction: "↑",
      icon: "🚪",
    },
    {
      title: "Surgeries Today",
      value: surgeryCount,
      change: "14%",
      direction: "↓",
      icon: "🩺",
    },
    {
      title: "Doctors",
      value: doctorCount,
      change: "Active",
      icon: "👨‍⚕️",
    },
    {
      title: "Interns",
      value: internCount,
      change: "Active",
      icon: "🎓",
    },
    {
      title: "Staff",
      value: staffCount,
      change: "Active",
      icon: "👥",
    },
    {
      title: "Cases Today",
      value: caseCount,
      change: "8%",
      direction: "↑",
      icon: "📋",
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex">
      
      {/* Sidebar */}
      <aside className="w-64 bg-green-700 text-white min-h-screen hidden lg:flex flex-col">
        
        {/* Logo */}
        <div className="px-6 py-6 border-b border-green-500">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-2xl">
              🌿
            </div>

            <div>
              <h1 className="font-bold text-lg tracking-wide">
                DHANVANTARI
              </h1>
              <p className="text-xs text-green-100">
                Ayurvedic Hospital
              </p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-4 py-6">
          <p className="text-xs text-green-200 uppercase tracking-wider px-3 mb-3">
            Main
          </p>

          <div className="space-y-1">
            <SidebarItem icon="🏠" label="Dashboard" active onClick={onDashboard}/>
            <SidebarItem icon="👨‍⚕️" label="Doctors" onClick={onDoctors} />
            <SidebarItem icon="🎓" label="Interns" onClick={()=>onInterns()}/>
            <SidebarItem icon="👥" label="Patients" onClick={onPatients}/>
            <SidebarItem icon="📋" label="Cases" />
            <SidebarItem icon="📅" label="Appointments" />
            <SidebarItem icon="🩺" label="Surgeries" />
            <SidebarItem icon="🛏️" label="Admissions" />
            <SidebarItem icon="🚪" label="Discharges" />
          </div>

          <p className="text-xs text-green-200 uppercase tracking-wider px-3 mt-7 mb-3">
            Other
          </p>

          <div className="space-y-1">
            <SidebarItem icon="👥" label="Staff" />
            <SidebarItem icon="🏢" label="Departments" />
            <SidebarItem icon="💊" label="Medicines" />
            <SidebarItem icon="📊" label="Reports" />
            <SidebarItem icon="🔐" label="Audit Logs" />
            <SidebarItem icon="⚙️" label="Settings" />
          </div>
        </nav>

        {/* Hospital */}
        <div className="p-4">
          <div className="bg-green-800 rounded-xl p-4">
            <p className="font-semibold text-sm">
              Dhanvantari Ayurvedic
            </p>

            <p className="font-semibold text-sm">
              Hospital
            </p>

            <p className="text-xs text-green-200 mt-2">
              Bengaluru, Karnataka
            </p>

            <div className="flex items-center gap-2 mt-3">
              <span className="w-2 h-2 rounded-full bg-green-400"></span>
              <span className="text-xs text-green-100">
                Active
              </span>
            </div>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 min-w-0">
        
        {/* Header */}
        <header className="bg-white border-b border-slate-200 px-6 py-5">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            
            <div>
              <p className="text-sm text-slate-500">
                Welcome back,
              </p>

              <h1 className="text-3xl font-bold text-slate-900">
                Admin 👋
              </h1>

              <p className="text-sm text-slate-500 mt-1">
                Here's what's happening in your hospital today.
              </p>
            </div>

            <div className="flex items-center gap-4">
              <div className="hidden sm:block text-sm text-slate-600">
                📅 09 Apr 2026
              </div>

              <button className="relative w-10 h-10 rounded-full hover:bg-slate-100">
                🔔
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] w-5 h-5 rounded-full flex items-center justify-center">
                  3
                </span>
              </button>

              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center">
                  👤
                </div>

                <div className="hidden sm:block">
                  <p className="text-sm font-semibold">
                    Admin
                  </p>
                  <p className="text-xs text-slate-500">
                    Super Admin
                  </p>
                </div>
              </div>
            </div>
          </div>
        </header>

        <div className="p-6">
          
          {/* Action buttons */}
          <div className="flex justify-end gap-3 mb-6">
            <button className="px-4 py-2 bg-white border border-slate-200 rounded-lg text-sm font-medium hover:bg-slate-50">
              ↓ Export Report
            </button>

            <button className="px-4 py-2 bg-white border border-slate-200 rounded-lg text-sm font-medium hover:bg-slate-50">
              📅 Today ▾
            </button>
          </div>

          {/* Statistics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-5">
            {stats.map((stat) => (
              <StatCard
                key={stat.title}
                {...stat}
              />
            ))}
          </div>

          {/* Activity + Patient Overview */}
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-5 mt-6">
            
            {/* Activity Overview */}
            <DashboardCard title="Today's Activity Overview">
              <div className="space-y-5">
                <ActivityRow
                  icon="👤"
                  label="New Patients"
                  value={patientCount}
                />

                <ActivityRow
                  icon="🛏️"
                  label="Admitted"
                  value={admittedCount}
                />

                <ActivityRow
                  icon="🚪"
                  label="Discharged"
                  value={dischargedCount}
                />

                <ActivityRow
                  icon="🩺"
                  label="Surgeries"
                  value={surgeryCount}
                />

                <ActivityRow
                  icon="📋"
                  label="New Case Records"
                  value={caseCount}
                />

                <ActivityRow
                  icon="👥"
                  label="Follow-ups"
                  value="22"
                />

                <button className="text-green-600 font-semibold text-sm mt-3">
                  View Full Report →
                </button>
              </div>
            </DashboardCard>

            {/* Patient Overview */}
            <DashboardCard title="Patients Overview">
              <div className="flex flex-col sm:flex-row items-center justify-center gap-8 py-4">
                
                <div className="w-40 h-40 rounded-full border-[25px] border-green-500 flex items-center justify-center">
                  <div className="text-center">
                    <p className="text-xs text-slate-500">
                      Total
                    </p>
                    <p className="text-2xl font-bold">
                      {patientCount}
                    </p>
                  </div>
                </div>

                <div className="space-y-4">
                  <OverviewItem label="In Patients" value="25 (16%)" />
                  <OverviewItem label="Out Patients" value="84 (55%)" />
                  <OverviewItem label="Follow Up" value="28 (18%)" />
                  <OverviewItem label="Others" value="15 (11%)" />
                </div>
              </div>

              <button className="text-green-600 font-semibold text-sm">
                View Patient Analytics →
              </button>
            </DashboardCard>
          </div>

          {/* Monthly Trend */}
          <DashboardCard
            title="Monthly Trend"
            subtitle="This Month"
            className="mt-6"
          >
            <div className="h-64 flex items-end gap-3 px-4 pt-8">
              {monthlyTrend.map(
                (height, index) => (
                  <div
                    key={index}
                    className="flex-1 flex flex-col justify-end"
                  >
                    <div
                      className="bg-green-500 rounded-t-md"
                      style={{ height: `${height * 2}px` }}
                    ></div>
                  </div>
                )
              )}
            </div>

            <div className="flex justify-between text-xs text-slate-400 px-4 mt-2">
              <span>1 Apr</span>
              <span>4 Apr</span>
              <span>7 Apr</span>
              <span>10 Apr</span>
              <span>14 Apr</span>
            </div>

            <button className="text-green-600 font-semibold text-sm mt-5">
              Detailed Analytics →
            </button>
          </DashboardCard>

          {/* Bottom cards */}
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-5 mt-6">
            
            <DashboardCard title="Recent Registrations">
              {recentPatients.slice(0, 5).map((patient) => (
                    <RecentItem
                      key={patient._id}
                      name={patient.patientName}
                      type="Patient"
                      time={new Date(patient.createdAt).toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    />
                  ))}

              <button className="text-green-600 font-semibold text-sm mt-4">
                View All
              </button>
            </DashboardCard>

            <DashboardCard title="Recent Activities">
              <RecentActivity text="Dr. Arjun created a new case" time="10:35 AM" />
              <RecentActivity text="Intern Sneha added a case note" time="10:20 AM" />
              {recentPatients.slice(0, 1).map((patient) => (
                    <RecentActivity
                      key={patient._id}
                      text={`Patient ${patient.patientName} registered`}
                      time={new Date(patient.createdAt).toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    />
                  ))}
              <RecentActivity text="Dr. Meera updated a prescription" time="09:50 AM" />

              <button className="text-green-600 font-semibold text-sm mt-4">
                View All
              </button>
            </DashboardCard>

            <DashboardCard title="Recent Audit Logs">
              {auditLogs.map((log) => (
                  <AuditItem
                    key={log._id}
                    text={log.description || `${log.role} ${log.action}`}
                    status={log.action || "SUCCESS"}
                  />
                ))}

              <button onClick={onPatients}
               className="text-green-600 font-semibold text-sm mt-4">
                View All
              </button>
            </DashboardCard>
          </div>
        </div>
      </main>
    </div>
  );
};

/* ---------------- Components ---------------- */

const SidebarItem = ({ icon, label, active, onClick }) => (
  <button
  onClick={onClick}
    className={`w-full flex items-center gap-3 px-3 py-3 rounded-lg text-sm font-medium transition ${
      active
        ? "bg-green-500 text-white"
        : "text-green-100 hover:bg-green-600"
    }`}
  >
    <span>{icon}</span>
    <span>{label}</span>
  </button>
);

const StatCard = ({
  title,
  value,
  change,
  direction,
  icon,
}) => (
  <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm">
    <div className="flex items-center justify-between">
      <div>
        <p className="text-sm text-slate-500">
          {title}
        </p>

        <p className="text-3xl font-bold text-slate-900 mt-2">
          {value}
        </p>

        <p
          className={`text-xs font-semibold mt-2 ${
            direction === "↓"
              ? "text-red-500"
              : "text-green-600"
          }`}
        >
          {direction} {change}
        </p>
      </div>

      <div className="w-14 h-14 rounded-full bg-green-50 flex items-center justify-center text-2xl">
        {icon}
      </div>
    </div>
  </div>
);

const DashboardCard = ({
  title,
  subtitle,
  children,
  className = "",
}) => (
  <div
    className={`bg-white rounded-xl border border-slate-200 p-5 shadow-sm ${className}`}
  >
    <div className="flex items-center justify-between mb-5">
      <h2 className="font-bold text-slate-800">
        {title}
        {subtitle && (
          <span className="text-xs font-normal text-slate-400 ml-2">
            ({subtitle})
          </span>
        )}
      </h2>
    </div>

    {children}
  </div>
);

const ActivityRow = ({ icon, label, value }) => (
  <div className="flex items-center justify-between">
    <div className="flex items-center gap-3">
      <span className="text-xl">{icon}</span>
      <span className="text-sm text-slate-600">
        {label}
      </span>
    </div>

    <span className="font-bold text-slate-800">
      {value}
    </span>
  </div>
);

const OverviewItem = ({ label, value }) => (
  <div className="flex items-center justify-between gap-6">
    <span className="text-sm text-slate-600">
      {label}
    </span>

    <span className="text-sm font-semibold text-slate-800">
      {value}
    </span>
  </div>
);

const RecentItem = ({ name, type, time }) => (
  <div className="flex items-center justify-between py-3 border-b border-slate-100">
    <div>
      <p className="text-sm font-semibold text-slate-800">
        {name}
      </p>
      <p className="text-xs text-slate-400">
        {type}
      </p>
    </div>

    <span className="text-xs text-slate-500">
      {time}
    </span>
  </div>
);

const RecentActivity = ({ text, time }) => (
  <div className="flex items-center justify-between py-3 border-b border-slate-100">
    <p className="text-sm text-slate-700">
      {text}
    </p>

    <span className="text-xs text-slate-400 ml-3 whitespace-nowrap">
      {time}
    </span>
  </div>
);

const AuditItem = ({ text, status }) => (
  <div className="flex items-center justify-between py-3 border-b border-slate-100">
    <p className="text-sm text-slate-700">
      {text}
    </p>

    <span
      className={`text-[10px] font-bold px-2 py-1 rounded-full ${
        status === "FAILED"
          ? "bg-red-100 text-red-600"
          : "bg-green-100 text-green-600"
      }`}
    >
      {status}
    </span>
  </div>
);

export default AdminDashboard;