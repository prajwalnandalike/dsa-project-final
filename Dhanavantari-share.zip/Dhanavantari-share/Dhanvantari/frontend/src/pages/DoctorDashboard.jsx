import React, {useEffect, useState} from "react";


const DoctorDashboard = ({onStartCaseTaking}) => {
 
  const user = JSON.parse(localStorage.getItem("user") || "{}");

          const [patients, setPatients] = useState([]);
        const [selectedPatient, setSelectedPatient] = useState("");

        useEffect(() => {
          const fetchPatients = async () => {
            try {
              const token = localStorage.getItem("token");

              const response = await fetch("/api/patients", {
                headers: {
                  Authorization: `Bearer ${token}`,
                },
              });

              const data = await response.json();

              if (response.ok) {
                setPatients(data.patients || []);
              }
            } catch (error) {
              console.error("Failed to fetch patients:", error);
            }
          };

          fetchPatients();
        }, []);

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");

    window.location.reload();
  };

  return (
    <div className="min-h-screen bg-slate-50">

      {/* Header */}
      <header className="bg-gradient-to-r from-emerald-700 via-emerald-600 to-cyan-600 px-6 py-4 text-white shadow-lg">
        <div className="mx-auto flex max-w-7xl items-center justify-between">

          <div>
            <h1 className="text-2xl font-bold">
              Dhanvantari
            </h1>

            <p className="text-sm text-emerald-100">
              Smart AYUSH Care Platform
            </p>
          </div>

          <button
            onClick={handleLogout}
            className="rounded-xl bg-white/15 px-5 py-2.5 text-sm font-semibold backdrop-blur transition hover:bg-white/25"
          >
            Logout
          </button>

        </div>
      </header>

      {/* Main */}
      <main className="mx-auto max-w-7xl px-6 py-8">

        {/* Welcome */}
        <div className="mb-8">
          <p className="text-sm font-semibold uppercase tracking-wider text-emerald-600">
            Doctor Portal
          </p>

          <h2 className="mt-1 text-3xl font-bold text-slate-800">
            Welcome, Dr. {user.doctorName || "Doctor"}
          </h2>

          <p className="mt-2 text-slate-500">
            Manage patients, clinical cases and AYUSH care from one secure platform.
          </p>
        </div>

        {/* Profile */}
        <div className="mb-8 rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">

          <h3 className="text-lg font-bold text-slate-800">
            Doctor Profile
          </h3>

          <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">

            <div>
              <p className="text-xs font-semibold uppercase text-slate-400">
                Name
              </p>
              <p className="mt-1 font-medium text-slate-700">
                {user.doctorName || "—"}
              </p>
            </div>

            <div>
              <p className="text-xs font-semibold uppercase text-slate-400">
                Qualification
              </p>
              <p className="mt-1 font-medium text-slate-700">
                {user.qualification || "—"}
              </p>
            </div>

            <div>
              <p className="text-xs font-semibold uppercase text-slate-400">
                Specialization
              </p>
              <p className="mt-1 font-medium text-slate-700">
                {user.specialization || "—"}
              </p>
            </div>

            <div>
              <p className="text-xs font-semibold uppercase text-slate-400">
                Department
              </p>
              <p className="mt-1 font-medium text-slate-700">
                {user.department || "—"}
              </p>
            </div>

          </div>
        </div>

        {/* Dashboard Cards */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">

          <DashboardCard
            icon="👥"
            title="Patients"
            description="View and manage registered patients."
          />

          <DashboardCard
            icon="📋"
            title="Case Taking"
            description="Start a medical-system specific case."
          />

          <DashboardCard
            icon="🩺"
            title="Clinical Cases"
            description="View ongoing and completed cases."
          />

          <DashboardCard
            icon="🌿"
            title="Care Instructions"
            description="Review and approve patient care instructions."
          />

        </div>

        {/* Quick Actions */}
        <div className="mt-8 rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">

          <h3 className="text-lg font-bold text-slate-800">
            Quick Actions
          </h3>

          <div className="mt-5 flex flex-wrap gap-3">

            <button className="rounded-xl bg-emerald-600 px-5 py-3 text-sm font-semibold text-white transition hover:bg-emerald-700">
              + New Patient
            </button>


            <select
                value={selectedPatient}
                onChange={(e) => setSelectedPatient(e.target.value)}
                className="rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm"
              >
                <option value="">Select Patient</option>

                {patients.map((patient) => (
                  <option key={patient._id} value={patient._id}>
                    {patient.patientName} — {patient.patientId}
                  </option>
                ))}
              </select>
            <button
                  onClick={() => {
                    if (!selectedPatient) {
                      alert("Please select a patient first.");
                      return;
                    }

                    const patient = patients.find(
                      (p) => p._id === selectedPatient
                    );

                    localStorage.setItem(
                      "selectedPatient",
                      JSON.stringify(patient)
                    );

                    onStartCaseTaking();
                  }}
                  className="rounded-xl bg-cyan-600 px-5 py-3 text-sm font-semibold text-white transition hover:bg-cyan-700"
                >
                  Start Case Taking
                </button>

            <button className="rounded-xl bg-slate-800 px-5 py-3 text-sm font-semibold text-white transition hover:bg-slate-900">
              View Cases
            </button>

          </div>

        </div>

      </main>
    </div>
  );
};


/* Dashboard Card */
const DashboardCard = ({ icon, title, description }) => {
  return (
    <button
      type="button"
      className="group rounded-2xl bg-white p-6 text-left shadow-sm ring-1 ring-slate-200 transition duration-200 hover:-translate-y-1 hover:shadow-lg"
    >

      <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-50 text-2xl">
        {icon}
      </div>

      <h3 className="mt-5 text-lg font-bold text-slate-800">
        {title}
      </h3>

      <p className="mt-2 text-sm leading-6 text-slate-500">
        {description}
      </p>

      <p className="mt-4 text-sm font-semibold text-emerald-600">
        Open →
      </p>

    </button>
  );
};

export default DoctorDashboard;