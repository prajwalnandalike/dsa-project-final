import React, { useState } from 'react'

const AdminLogin = ({onBack, onLoginSuccess, onSignup}) => {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleLogin = async (e) => {
    e.preventDefault()

    setError('')

    if (!email || !password) {
      setError('Please enter email and password')
      return
    }

    try {
      setLoading(true)

      const response = await fetch('/api/admin/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          email,
          password
        })
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(
          data.message || 'Login failed'
        )
      }

      // Store JWT
      localStorage.setItem('token', data.token)

      // Store basic user information
      localStorage.setItem(
        'user',
        JSON.stringify({
          userId: data.admin?._id,
          role: 'admin',
          hospitalId: data.admin?.hospitalId,
          adminName: data.admin?.adminName,
          email: data.admin?.email
        })
      )

      console.log('Admin login successful')
      console.log('JWT stored successfully')

      // Temporary success message
      // alert('Admin login successful')
      if(onLoginSuccess){
        onLoginSuccess()
      }

    } catch (err) {
      console.error(err)
      setError(err.message || 'Unable to login')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-cyan-50">

      {/* Header */}
      <header className="flex items-center justify-between bg-gradient-to-r from-green-800 via-green-700 to-cyan-600 px-6 py-4 text-white shadow-lg">

        <div className="flex items-center gap-3">

          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/15">
            🌿
          </div>

          <div>
            <h1 className="text-xl font-bold">
              Dhanvantari
            </h1>

            <p className="text-xs text-green-100">
              Smart AYUSH Care Platform
            </p>
          </div>

        </div>

      </header>


      {/* Main */}
      <main className="flex min-h-[calc(100vh-76px)] items-center justify-center px-4 py-10">

        <div className="grid w-full max-w-5xl overflow-hidden rounded-3xl bg-white shadow-2xl lg:grid-cols-2">

          {/* Left panel */}
          <div className="hidden bg-gradient-to-br from-green-800 via-green-700 to-cyan-600 p-10 text-white lg:flex lg:flex-col lg:justify-between">

            <div>

              <div className="mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-white/15 text-3xl">
                🏥
              </div>

              <h2 className="text-3xl font-bold leading-tight">
                Hospital
                <br />
                Administration
              </h2>

              <p className="mt-4 max-w-sm text-sm leading-6 text-green-50">
                Manage your hospital, doctors, interns,
                patients and clinical workflows securely
                from one platform.
              </p>

            </div>


            <div className="space-y-3">

              <div className="flex items-center gap-3 rounded-xl bg-white/10 p-3">
                <span>✓</span>
                <span className="text-sm">
                  Secure authentication
                </span>
              </div>

              <div className="flex items-center gap-3 rounded-xl bg-white/10 p-3">
                <span>✓</span>
                <span className="text-sm">
                  Hospital-based access
                </span>
              </div>

              <div className="flex items-center gap-3 rounded-xl bg-white/10 p-3">
                <span>✓</span>
                <span className="text-sm">
                  Role-based management
                </span>
              </div>

            </div>

          </div>


          {/* Login panel */}
          <div className="p-7 sm:p-10">

            <div className="mb-8">

              <p className="text-sm font-semibold text-emerald-600">
                ADMIN PORTAL
              </p>

              <h2 className="mt-2 text-3xl font-bold text-slate-800">
                Welcome back
              </h2>

              <p className="mt-2 text-sm text-slate-500">
                Sign in to manage your hospital
              </p>

            </div>


            {/* Error */}
            {error && (
              <div className="mb-5 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                {error}
              </div>
            )}


            <form
              onSubmit={handleLogin}
              className="space-y-5"
            >

              {/* Email */}
              <div>

                <label className="mb-2 block text-sm font-semibold text-slate-700">
                  Admin Email
                </label>

                <input
                  type="email"
                  value={email}
                  onChange={(e) =>
                    setEmail(e.target.value)
                  }
                  placeholder="Enter admin email"
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-800 outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100"
                />

              </div>


              {/* Password */}
              <div>

                <label className="mb-2 block text-sm font-semibold text-slate-700">
                  Password
                </label>

                <input
                  type="password"
                  value={password}
                  onChange={(e) =>
                    setPassword(e.target.value)
                  }
                  placeholder="Enter your password"
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-800 outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100"
                />

              </div>


              {/* Login button */}
              <button
                type="submit"
                disabled={loading}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-green-700 to-emerald-600 px-5 py-3.5 text-sm font-bold text-white shadow-lg transition hover:from-green-800 hover:to-emerald-700 disabled:cursor-not-allowed disabled:opacity-60"
              >

                {loading ? (
                  <>
                    <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                    Signing in...
                  </>
                ) : (
                  <>
                    🔐
                    Sign in as Admin
                  </>
                )}

              </button>
          <button
              type="button"
              onClick={onSignup}
              className="w-full mt-3 py-3 rounded-xl border-2 border-emerald-600 text-emerald-700 font-semibold hover:bg-emerald-50 transition"
            >
              Create Hospital Admin Account
            </button>
                              {/* Back to Portals */}
                <div className="mt-6 flex justify-center">
                  <button
                    type="button"
                    onClick={onBack}
                    className="flex w-full max-w-md items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 px-6 py-3.5 text-sm font-bold text-white shadow-lg shadow-emerald-500/20 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-xl"
                  >
                    <span className="text-lg">←</span>
                    Back to Portals
                  </button>
                </div>


            </form>


            <div className="mt-8 border-t border-slate-100 pt-5 text-center">

              <p className="text-xs text-slate-400">
                Authorized hospital administrators only
              </p>

            </div>

          </div>

        </div>

      </main>

    </div>
  )
}

export default AdminLogin