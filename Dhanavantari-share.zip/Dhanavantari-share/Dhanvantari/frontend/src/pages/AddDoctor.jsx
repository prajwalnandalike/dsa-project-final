import React, { useState } from "react";

const AddDoctor = ({ onBack }) => {
  const [formData, setFormData] = useState({
    doctorName: "",
    email: "",
    mobile: "",
    registrationNumber: "",
    qualification: "",
    specialization: "",
    department: "",
    password: "",
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    setLoading(true);
    setError("");

    try {
      const token = localStorage.getItem("token");

      const response = await fetch("/api/doctors", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Failed to create doctor");
      }

      alert("Doctor created successfully!");
      onBack();

    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-cyan-50 p-6">

      <button
        onClick={onBack}
        className="mb-6 rounded-xl bg-green-700 px-5 py-3 text-sm font-semibold text-white shadow hover:bg-green-800"
      >
        ← Back to Doctors
      </button>

      <div className="mx-auto max-w-4xl">

        <div className="mb-6">
          <p className="text-sm font-semibold uppercase tracking-wider text-emerald-600">
            Hospital Administration
          </p>

          <h1 className="mt-1 text-3xl font-bold text-slate-800">
            Add Doctor
          </h1>

          <p className="mt-2 text-sm text-slate-500">
            Create a doctor account and assign their professional details.
          </p>
        </div>

        <div className="rounded-3xl border border-slate-200 bg-white p-8 shadow-xl">

          {error && (
            <div className="mb-6 rounded-xl bg-red-50 p-4 text-sm font-medium text-red-700">
              {error}
            </div>
          )}

          <form
            onSubmit={handleSubmit}
            className="grid grid-cols-1 gap-5 md:grid-cols-2"
          >

            <div>
              <label className="form-label">Doctor Name</label>
              <input
                name="doctorName"
                value={formData.doctorName}
                onChange={handleChange}
                placeholder="Enter doctor name"
                className="form-input"
                required
              />
            </div>

            <div>
              <label className="form-label">Email</label>
              <input
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="doctor@example.com"
                className="form-input"
                required
              />
            </div>

            <div>
              <label className="form-label">Mobile Number</label>
              <input
                name="mobile"
                value={formData.mobile}
                onChange={handleChange}
                placeholder="Enter mobile number"
                className="form-input"
                required
              />
            </div>

            <div>
              <label className="form-label">Registration Number</label>
              <input
                name="registrationNumber"
                value={formData.registrationNumber}
                onChange={handleChange}
                placeholder="Medical registration number"
                className="form-input"
                required
              />
            </div>

            <div>
              <label className="form-label">Qualification</label>
              <input
                name="qualification"
                value={formData.qualification}
                onChange={handleChange}
                placeholder="e.g. BAMS"
                className="form-input"
                required
              />
            </div>

            <div>
              <label className="form-label">Specialization</label>
              <input
                name="specialization"
                value={formData.specialization}
                onChange={handleChange}
                placeholder="e.g. Kayachikitsa"
                className="form-input"
              />
            </div>

            <div>
              <label className="form-label">Department</label>
              <input
                name="department"
                value={formData.department}
                onChange={handleChange}
                placeholder="e.g. Ayurveda"
                className="form-input"
              />
            </div>

            <div>
              <label className="form-label">Temporary Password</label>
              <input
                name="password"
                type="password"
                value={formData.password}
                onChange={handleChange}
                placeholder="Create temporary password"
                className="form-input"
                required
              />
            </div>

            <div className="md:col-span-2 mt-4">
              <button
                type="submit"
                disabled={loading}
                className="w-full rounded-xl bg-gradient-to-r from-green-700 to-emerald-600 px-6 py-4 font-bold text-white shadow-lg transition hover:from-green-800 hover:to-emerald-700 disabled:opacity-50"
              >
                {loading ? "Creating Doctor..." : "Create Doctor"}
              </button>
            </div>

          </form>
        </div>
      </div>
    </div>
  );
};

export default AddDoctor;