
import React, {useEffect, useState} from "react";




const PatientsManagement = ({ onBack, onNewPatient }) => {
    const [patients, setPatients] = useState([]);
        const [stats, setStats] = useState({
                      totalPatients: 0,
                      activePatients: 0,
                      admittedPatients: 0,
                      registeredToday: 0,
           });



        //  const totalPatients = patients.length;

        //     const activePatients = patients.filter(
        //       (patient) => patient.isActive
        //     ).length;

        //     const registeredToday = patients.filter((patient) => {
        //       const today = new Date();
        //       const created = new Date(patient.createdAt);

        //       return (
        //         created.getDate() === today.getDate() &&
        //         created.getMonth() === today.getMonth() &&
        //         created.getFullYear() === today.getFullYear()
        //       );
        //     }).length;

        useEffect(() => {
          const fetchPatients = async () => {
            try {
              const token = localStorage.getItem("token");

              const response = await fetch("/api/patients", {
                headers: {
                  Authorization: `Bearer ${token}`,
                },
              });

              const data = await response.json();

              if (!response.ok) {
                throw new Error(data.message || "Failed to fetch patients");
              }

              setPatients(data.patients || []);
              setStats(data.stats ||[]);
            } catch (error) {
              console.error("Fetch patients error:", error);
            }
          };

          fetchPatients();
        }, []);


  return (
    <div className="min-h-screen bg-slate-50">

      {/* Header */}
      <header className="bg-gradient-to-r from-green-800 via-green-700 to-cyan-600 px-6 py-5 text-white shadow-lg">
        <div className="mx-auto max-w-7xl">

          <button
            onClick={onBack}
            className="mb-4 rounded-lg bg-white/15 px-4 py-2 text-sm font-semibold backdrop-blur transition hover:bg-white/25"
          >
            ← Back to Dashboard
          </button>

          <p className="text-xs font-semibold uppercase tracking-widest text-green-100">
            Hospital Administration
          </p>

          <h1 className="mt-1 text-3xl font-bold">
            Patients Management
          </h1>

          <p className="mt-1 text-sm text-green-100">
            View and manage patients registered under your hospital.
          </p>

        </div>
      </header>


      {/* Main */}
      <main className="mx-auto max-w-7xl px-6 py-8">

        {/* Top Stats */}
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">

          <StatCard
            icon="👥"
            title="Total Patients"
            value={stats.totalPatients}
          />

          <StatCard
            icon="🟢"
            title="Active Patients"
            value={stats.activePatients}
          />

          <StatCard
            icon="🏥"
            title="Admitted"
            value={stats.admittedPatients}
          />

          <StatCard
            icon="📋"
            title="Registered Today"
            value={stats.registeredToday}
          />

        </div>


        {/* Patient Section */}
        <div className="mt-8 rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">

          <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">

            <div>
              <h2 className="text-xl font-bold text-slate-800">
                Patient Records
              </h2>

              <p className="mt-1 text-sm text-slate-500">
                Search and manage registered patients.
              </p>
            </div>

            <button
            onClick={onNewPatient}
              className="rounded-xl bg-gradient-to-r from-green-700 to-emerald-600 px-5 py-3 text-sm font-bold text-white shadow-md transition hover:from-green-800 hover:to-emerald-700"
            >
              + New Patient
            </button>

          </div>


          {/* Search */}
          <div className="mt-6">

            <input
              type="text"
              placeholder="Search by patient name, ID, mobile number..."
              className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-2 focus:ring-emerald-100"
            />

          </div>


          {/* Table */}
          <div className="mt-6 overflow-x-auto">

            <table className="w-full min-w-[800px]">

              <thead>
                <tr className="border-b border-slate-200 text-left">

                  <th className="px-4 py-4 text-xs font-bold uppercase tracking-wide text-slate-500">
                    Patient ID
                  </th>

                  <th className="px-4 py-4 text-xs font-bold uppercase tracking-wide text-slate-500">
                    Patient
                  </th>

                  <th className="px-4 py-4 text-xs font-bold uppercase tracking-wide text-slate-500">
                    Mobile
                  </th>

                  <th className="px-4 py-4 text-xs font-bold uppercase tracking-wide text-slate-500">
                    Gender
                  </th>

                  <th className="px-4 py-4 text-xs font-bold uppercase tracking-wide text-slate-500">
                    Registration
                  </th>

                  <th className="px-4 py-4 text-xs font-bold uppercase tracking-wide text-slate-500">
                    Status
                  </th>

                </tr>
              </thead>
              <tbody>
                  {patients.map((patient) => (
                    <PatientRow
                      key={patient._id}
                      id={patient.patientId}
                      name={patient.patientName}
                      mobile={patient.mobile}
                      gender={patient.gender}
                      registration={patient.registrationType}
                      status={patient.isActive ? "Active" : "Inactive"}
                    />
                  ))}
                </tbody>
            </table>

          </div>

        </div>

      </main>

    </div>
  );
};


/* ================= STAT CARD ================= */

const StatCard = ({ icon, title, value }) => {
  return (
    <div className="rounded-2xl bg-white p-5 shadow-sm ring-1 ring-slate-200 transition hover:-translate-y-1 hover:shadow-md">

      <div className="flex items-center justify-between">

        <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-50 text-2xl">
          {icon}
        </div>

        <span className="text-2xl font-bold text-slate-800">
          {value}
        </span>

      </div>

      <p className="mt-4 text-sm font-medium text-slate-500">
        {title}
      </p>

    </div>
  );
};


/* ================= PATIENT ROW ================= */

const PatientRow = ({
  id,
  name,
  mobile,
  gender,
  registration,
  status,
}) => {
  return (
    <tr className="border-b border-slate-100 transition hover:bg-slate-50">

      <td className="px-4 py-4 text-sm font-semibold text-emerald-700">
        {id}
      </td>

      <td className="px-4 py-4 text-sm font-semibold text-slate-800">
        {name}
      </td>

      <td className="px-4 py-4 text-sm text-slate-600">
        {mobile}
      </td>

      <td className="px-4 py-4 text-sm text-slate-600">
        {gender}
      </td>

      <td className="px-4 py-4 text-sm text-slate-600">
        {registration}
      </td>

      <td className="px-4 py-4">

        <span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-bold text-emerald-700">
          {status}
        </span>

      </td>

    </tr>
  );
};

export default PatientsManagement;