import React from "react";

const InternDashboard = () => {
  const intern = JSON.parse(localStorage.getItem("intern") || "{}");

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("userRole");
    localStorage.removeItem("intern");
    window.location.reload();
  };

  return (
    <div className="min-h-screen bg-slate-50 flex">

      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-slate-200 hidden md:flex flex-col">

        <div className="p-6 border-b border-slate-200">
          <h1 className="text-2xl font-bold text-emerald-700">
            Dhanvantari
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Smart AYUSH Care Platform
          </p>
        </div>

        <nav className="flex-1 p-4 space-y-2">

          <button className="w-full text-left px-4 py-3 rounded-lg bg-emerald-50 text-emerald-700 font-semibold">
            🏠 Dashboard
          </button>

          <button className="w-full text-left px-4 py-3 rounded-lg hover:bg-slate-100">
            👥 Patients
          </button>

          <button className="w-full text-left px-4 py-3 rounded-lg hover:bg-slate-100">
            📋 Case Taking
          </button>

          <button className="w-full text-left px-4 py-3 rounded-lg hover:bg-slate-100">
            🔎 Investigations
          </button>

          <button className="w-full text-left px-4 py-3 rounded-lg hover:bg-slate-100">
            📑 My Cases
          </button>

          <button className="w-full text-left px-4 py-3 rounded-lg hover:bg-slate-100">
            👨‍⚕️ Doctor Review
          </button>

          <button className="w-full text-left px-4 py-3 rounded-lg hover:bg-slate-100">
            🔔 Notifications
          </button>

        </nav>

        <div className="p-4 border-t border-slate-200">
          <button
            onClick={handleLogout}
            className="w-full px-4 py-3 rounded-lg text-red-600 hover:bg-red-50 text-left"
          >
            🚪 Logout
          </button>
        </div>

      </aside>

      {/* Main Content */}
      <main className="flex-1">

        {/* Header */}
        <header className="bg-white border-b border-slate-200 px-6 py-5 flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold text-slate-800">
              Intern Dashboard
            </h2>

            <p className="text-sm text-slate-500 mt-1">
              Welcome back, {intern.name || "Intern"}
            </p>
          </div>

          <div className="w-11 h-11 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700 font-bold">
            I
          </div>
        </header>

        {/* Dashboard */}
        <section className="p-6">

          {/* Welcome */}
          <div className="bg-gradient-to-r from-emerald-700 to-teal-600 rounded-2xl p-6 text-white mb-6">
            <h3 className="text-2xl font-bold">
              Welcome to Dhanvantari
            </h3>

            <p className="mt-2 text-emerald-50">
              Assist doctors in patient care, case taking and AYUSH clinical
              documentation.
            </p>
          </div>

          {/* Quick Actions */}
          <h3 className="text-lg font-bold text-slate-800 mb-4">
            Quick Actions
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">

            <div className="bg-white rounded-xl border border-slate-200 p-5 hover:shadow-md transition">
              <div className="text-3xl mb-3">👥</div>

              <h4 className="font-bold text-slate-800">
                Patients
              </h4>

              <p className="text-sm text-slate-500 mt-2">
                View and assist with assigned patients.
              </p>

              <button className="mt-4 text-emerald-700 font-semibold">
                View Patients →
              </button>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 p-5 hover:shadow-md transition">
              <div className="text-3xl mb-3">📋</div>

              <h4 className="font-bold text-slate-800">
                Case Taking
              </h4>

              <p className="text-sm text-slate-500 mt-2">
                Record structured AYUSH case information.
              </p>

              <button className="mt-4 text-emerald-700 font-semibold">
                Start Case Taking →
              </button>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 p-5 hover:shadow-md transition">
              <div className="text-3xl mb-3">🔎</div>

              <h4 className="font-bold text-slate-800">
                Investigations
              </h4>

              <p className="text-sm text-slate-500 mt-2">
                View investigations associated with patients.
              </p>

              <button className="mt-4 text-emerald-700 font-semibold">
                View Investigations →
              </button>
            </div>

          </div>

          {/* Work Area */}
          <div className="mt-6 bg-white rounded-xl border border-slate-200 p-6">

            <h3 className="text-lg font-bold text-slate-800">
              My Work
            </h3>

            <p className="text-sm text-slate-500 mt-2">
              Your assigned patients, cases and doctor review activities
              will appear here once connected to the hospital database.
            </p>

            <div className="mt-5 p-5 rounded-lg bg-slate-50 text-center">
              <p className="text-slate-500">
                No assigned work available yet.
              </p>
            </div>

          </div>

        </section>
      </main>
    </div>
  );
};

export default InternDashboard;