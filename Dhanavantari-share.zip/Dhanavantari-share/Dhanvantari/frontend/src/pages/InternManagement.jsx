import React from "react";

const InternsManagement = ({ onBack, onAddIntern }) => {
  return (
    <div className="min-h-screen bg-slate-50 p-6">

      <button
        onClick={onBack}
        className="mb-6 rounded-lg bg-green-700 px-4 py-2 text-sm font-semibold text-white hover:bg-green-800"
      >
        ← Back to Dashboard
      </button>

      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">
            Interns Management
          </h1>

          <p className="mt-2 text-sm text-slate-500">
            Manage interns registered under this hospital.
          </p>
        </div>

        <button
        onClick={onAddIntern}
          className="rounded-lg bg-green-700 px-5 py-3 text-sm font-bold text-white hover:bg-green-800"
        >
          + Add Intern
        </button>
      </div>

      <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
        <h2 className="text-lg font-bold text-slate-800">
          Registered Interns
        </h2>

        <p className="mt-2 text-sm text-slate-500">
          No interns registered yet.
        </p>
      </div>

    </div>
  );
};

export default InternsManagement;