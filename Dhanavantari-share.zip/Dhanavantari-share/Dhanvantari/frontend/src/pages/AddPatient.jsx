import React, { useState } from "react";

const AddPatient = ({ onBack, onSuccess }) => {
  const [formData, setFormData] = useState({
    patientId: "",
    patientName: "",
    dateOfBirth: "",
    age: "",
    gender: "",
    mobile: "",
    email: "",
    address: "",
    bloodGroup: "",
    abhaNumber: "",
    registrationType: "full_account",
    loginEnabled: false,
    password: "",
    guardian: {
      name: "",
      relationship: "",
      Mobile: "",
    },
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleGuardianChange = (e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      guardian: {
        ...prev.guardian,
        [name]: value,
      },
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    setError("");
    setLoading(true);

    try {
      const token = localStorage.getItem("token");

      const response = await fetch("/api/patients", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Failed to create patient");
      }

      alert("Patient created successfully!");

      if (onSuccess) {
        onSuccess();
      }
    } catch (error) {
      console.error(error);
      setError(error.message || "Failed to create patient");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">

      {/* Header */}
      <header className="bg-gradient-to-r from-green-800 via-green-700 to-cyan-600 px-6 py-5 text-white shadow-lg">
        <div className="mx-auto max-w-5xl">

          <button
            onClick={onBack}
            className="mb-4 rounded-lg bg-white/15 px-4 py-2 text-sm font-semibold backdrop-blur transition hover:bg-white/25"
          >
            ← Back to Patients
          </button>

          <p className="text-xs font-semibold uppercase tracking-widest text-green-100">
            Hospital Administration
          </p>

          <h1 className="mt-1 text-3xl font-bold">
            Register New Patient
          </h1>

          <p className="mt-1 text-sm text-green-100">
            Create a patient profile for your hospital.
          </p>

        </div>
      </header>


      {/* Form */}
      <main className="mx-auto max-w-5xl px-6 py-8">

        <form
          onSubmit={handleSubmit}
          className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200 sm:p-8"
        >

          {error && (
            <div className="mb-6 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-medium text-red-700">
              {error}
            </div>
          )}


          {/* Basic Information */}
          <SectionTitle
            title="Basic Information"
            description="Enter the patient's identification and personal details."
          />

          <div className="grid grid-cols-1 gap-5 md:grid-cols-2">

            <Input
              label="Patient ID *"
              name="patientId"
              value={formData.patientId}
              onChange={handleChange}
              placeholder="PAT-001"
              required
            />

            <Input
              label="Patient Name *"
              name="patientName"
              value={formData.patientName}
              onChange={handleChange}
              placeholder="Enter patient name"
              required
            />

            <Input
              label="Date of Birth"
              type="date"
              name="dateOfBirth"
              value={formData.dateOfBirth}
              onChange={handleChange}
            />

            <Input
              label="Age"
              type="number"
              name="age"
              value={formData.age}
              onChange={handleChange}
              placeholder="Age"
              min="0"
            />

            <Select
              label="Gender"
              name="gender"
              value={formData.gender}
              onChange={handleChange}
              options={[
                ["", "Select Gender"],
                ["male", "Male"],
                ["female", "Female"],
                ["other", "Other"],
                ["prefer_not_to_say", "Prefer not to say"],
              ]}
            />

            <Input
              label="Mobile Number *"
              name="mobile"
              value={formData.mobile}
              onChange={handleChange}
              placeholder="Enter mobile number"
              required
            />

            <Input
              label="Email"
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="patient@example.com"
            />

            <Input
              label="Blood Group"
              name="bloodGroup"
              value={formData.bloodGroup}
              onChange={handleChange}
              placeholder="e.g. B+"
            />

            <Input
              label="ABHA Number"
              name="abhaNumber"
              value={formData.abhaNumber}
              onChange={handleChange}
              placeholder="Enter ABHA number"
            />

          </div>


          {/* Address */}
          <div className="mt-6">
            <label className="mb-2 block text-sm font-semibold text-slate-700">
              Address
            </label>

            <textarea
              name="address"
              value={formData.address}
              onChange={handleChange}
              rows="3"
              placeholder="Enter patient's address"
              className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-2 focus:ring-emerald-100"
            />
          </div>


          {/* Registration */}
          <div className="mt-8 border-t border-slate-100 pt-8">

            <SectionTitle
              title="Registration & Access"
              description="Choose how this patient will be registered."
            />

            <div className="grid grid-cols-1 gap-5 md:grid-cols-2">

              <Select
                label="Registration Type *"
                name="registrationType"
                value={formData.registrationType}
                onChange={handleChange}
                options={[
                  ["full_account", "Full Account"],
                  ["quick_registration", "Quick Registration"],
                  ["guardian_assisted", "Guardian Assisted"],
                ]}
                required
              />

              <div className="flex items-center rounded-xl border border-slate-200 bg-slate-50 px-4 py-3">

                <input
                  type="checkbox"
                  name="loginEnabled"
                  checked={formData.loginEnabled}
                  onChange={handleChange}
                  className="h-4 w-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                />

                <div className="ml-3">
                  <p className="text-sm font-semibold text-slate-700">
                    Enable Patient Login
                  </p>

                  <p className="text-xs text-slate-500">
                    Allow the patient to log in to the platform.
                  </p>
                </div>

              </div>

            </div>


            {formData.loginEnabled && (
              <div className="mt-5 max-w-md">

                <Input
                  label="Temporary Password"
                  type="password"
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  placeholder="Create temporary password"
                  required
                />

              </div>
            )}

          </div>


          {/* Guardian */}
          {formData.registrationType === "guardian_assisted" && (
            <div className="mt-8 border-t border-slate-100 pt-8">

              <SectionTitle
                title="Guardian Information"
                description="Required for guardian-assisted registration."
              />

              <div className="grid grid-cols-1 gap-5 md:grid-cols-3">

                <Input
                  label="Guardian Name"
                  name="name"
                  value={formData.guardian.name}
                  onChange={handleGuardianChange}
                  placeholder="Guardian name"
                  required
                />

                <Input
                  label="Relationship"
                  name="relationship"
                  value={formData.guardian.relationship}
                  onChange={handleGuardianChange}
                  placeholder="Father / Mother / etc."
                  required
                />

                <Input
                  label="Guardian Mobile"
                  name="Mobile"
                  value={formData.guardian.Mobile}
                  onChange={handleGuardianChange}
                  placeholder="Mobile number"
                  required
                />

              </div>

            </div>
          )}


          {/* Buttons */}
          <div className="mt-10 flex flex-col-reverse gap-3 border-t border-slate-100 pt-6 sm:flex-row sm:justify-end">

            <button
              type="button"
              onClick={onBack}
              className="rounded-xl border border-slate-200 bg-white px-6 py-3 text-sm font-bold text-slate-600 transition hover:bg-slate-50"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={loading}
              className="rounded-xl bg-gradient-to-r from-green-700 to-emerald-600 px-7 py-3 text-sm font-bold text-white shadow-md transition hover:from-green-800 hover:to-emerald-700 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {loading ? "Creating Patient..." : "Create Patient"}
            </button>

          </div>

        </form>

      </main>

    </div>
  );
};


/* ================= COMPONENTS ================= */

const SectionTitle = ({ title, description }) => (
  <div className="mb-6">
    <h2 className="text-xl font-bold text-slate-800">
      {title}
    </h2>

    <p className="mt-1 text-sm text-slate-500">
      {description}
    </p>
  </div>
);


const Input = ({
  label,
  name,
  type = "text",
  value,
  onChange,
  placeholder,
  required,
  min,
}) => (
  <div>
    <label className="mb-2 block text-sm font-semibold text-slate-700">
      {label}
    </label>

    <input
      type={type}
      name={name}
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      required={required}
      min={min}
      className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-2 focus:ring-emerald-100"
    />
  </div>
);


const Select = ({
  label,
  name,
  value,
  onChange,
  options,
  required,
}) => (
  <div>
    <label className="mb-2 block text-sm font-semibold text-slate-700">
      {label}
    </label>

    <select
      name={name}
      value={value}
      onChange={onChange}
      required={required}
      className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-2 focus:ring-emerald-100"
    >
      {options.map(([value, label]) => (
        <option key={value} value={value}>
          {label}
        </option>
      ))}
    </select>
  </div>
);


export default AddPatient;