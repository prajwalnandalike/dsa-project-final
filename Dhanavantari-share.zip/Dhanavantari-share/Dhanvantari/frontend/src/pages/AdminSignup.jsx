import React, { useState } from "react";
import logo from "../assets/dhanvantariLogo.jpeg";

const AdminSignup = ({ onBack, onSignupSuccess }) => {
  const [step, setStep] = useState("signup");

  const [formData, setFormData] = useState({
    hospitalName: "",
    hospitalId: "",
    medicalSystem: "Ayurveda",
    address: "",
    hospitalPhoneNumber: "",
    hospitalEmail: "",
    website: "",
    adminName: "",
    email: "",
    phoneNumber: "",
    password: "",
  });

  const [otp, setOtp] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  // ================= SIGNUP =================

  const handleSignup = async (e) => {
    e.preventDefault();

    setLoading(true);
    setError("");
    setMessage("");

    try {
      const response = await fetch("/api/admin/signup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || data.message || "Signup failed");
      }

      // Store IDs returned by backend
      localStorage.setItem("pendingAdminId", data.adminId || "");
      localStorage.setItem("pendingHospitalId", data.hospitalId || "");
      localStorage.setItem("pendingAdminPhone", formData.phoneNumber);

      setMessage(
        data.message ||
          "Admin registered successfully. Please verify your phone number."
      );

      // Move to OTP screen
     await  handleSendOtp();
     setStep("otp")
    } catch (err) {
      setError(err.message || "Unable to create admin account");
    } finally {
      setLoading(false);
    }
  };

  // ================= SEND OTP =================

  const handleSendOtp = async () => {
    setLoading(true);
    setError("");
    setMessage("");

    try {
      const response = await fetch("/api/admin/send-otp", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          phoneNumber: formData.phoneNumber,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || data.message || "Unable to send OTP");
      }

      setMessage(
        data.message || "OTP generated successfully. Check your phone."
      );
    } catch (err) {
      setError(err.message || "Unable to send OTP");
    } finally {
      setLoading(false);
    }
  };

  // ================= VERIFY OTP =================

  const handleVerifyOtp = async (e) => {
    e.preventDefault();

    if (otp.length !== 6) {
      setError("Please enter the 6-digit OTP.");
      return;
    }

    setLoading(true);
    setError("");
    setMessage("");

    try {
      const response = await fetch("/api/admin/verify-otp", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          phoneNumber: formData.phoneNumber,
          otp,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || data.message || "Invalid OTP");
      }

      setMessage(
        data.message || "Phone number verified successfully!"
      );

      setTimeout(() => {
        if (onSignupSuccess) {
          onSignupSuccess();
        }
      }, 1200);
    } catch (err) {
      setError(err.message || "OTP verification failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-cyan-50 flex items-center justify-center px-4 py-8">

      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-72 h-72 bg-emerald-200 rounded-full blur-3xl opacity-30"></div>
      <div className="absolute bottom-0 right-0 w-80 h-80 bg-cyan-200 rounded-full blur-3xl opacity-30"></div>

      <div className="relative w-full max-w-6xl bg-white/90 backdrop-blur-xl rounded-3xl shadow-2xl overflow-hidden border border-white">

        {/* ================= LEFT PANEL ================= */}

        <div className="grid lg:grid-cols-2">

          <div className="hidden lg:flex bg-gradient-to-br from-emerald-700 via-emerald-600 to-cyan-600 text-white p-12 flex-col justify-between">

            <div>
              <div className="flex items-center gap-4 mb-10">
                <div className="bg-white rounded-2xl p-2 shadow-lg">
                  <img
                    src={logo}
                    alt="Dhanvantari"
                    className="w-16 h-16 object-contain rounded-xl"
                  />
                </div>

                <div>
                  <h1 className="text-2xl font-bold">
                    Dhanvantari
                  </h1>
                  <p className="text-emerald-100 text-sm">
                    Smart AYUSH Care Platform
                  </p>
                </div>
              </div>

              <h2 className="text-4xl font-bold leading-tight">
                Create your
                <br />
                Hospital Admin
                <br />
                Account
              </h2>

              <p className="mt-6 text-emerald-50 leading-relaxed">
                Register your hospital and securely manage doctors,
                interns, patients, cases and healthcare operations
                from one platform.
              </p>
            </div>

            <div className="space-y-4 text-sm text-emerald-50">
              <div className="flex items-center gap-3">
                <span className="bg-white/20 rounded-full p-2">✓</span>
                Secure administrator access
              </div>

              <div className="flex items-center gap-3">
                <span className="bg-white/20 rounded-full p-2">✓</span>
                Phone number verification
              </div>

              <div className="flex items-center gap-3">
                <span className="bg-white/20 rounded-full p-2">✓</span>
                Hospital-based data management
              </div>
            </div>
          </div>

          {/* ================= RIGHT PANEL ================= */}

          <div className="p-6 sm:p-10 lg:p-12">

            {/* Mobile logo */}

            <div className="lg:hidden flex items-center gap-3 mb-8">
              <img
                src={logo}
                alt="Dhanvantari"
                className="w-12 h-12 rounded-xl object-contain"
              />

              <div>
                <h1 className="font-bold text-xl text-emerald-700">
                  Dhanvantari
                </h1>
                <p className="text-xs text-gray-500">
                  Smart AYUSH Care Platform
                </p>
              </div>
            </div>

            {/* ================= SIGNUP ================= */}

            {step === "signup" && (
              <>
                <div className="mb-8">
                  <p className="text-sm font-semibold text-emerald-600">
                    ADMIN REGISTRATION
                  </p>

                  <h2 className="text-3xl font-bold text-gray-800 mt-2">
                    Register Hospital
                  </h2>

                  <p className="text-gray-500 mt-2">
                    Create the primary administrator account for your hospital.
                  </p>
                </div>

                <form
                  onSubmit={handleSignup}
                  className="space-y-6"
                >

                  {/* Hospital Information */}

                  <div>
                    <h3 className="font-semibold text-gray-800 mb-4">
                      Hospital Information
                    </h3>

                    <div className="grid sm:grid-cols-2 gap-4">

                      <Input
                        label="Hospital Name"
                        name="hospitalName"
                        value={formData.hospitalName}
                        onChange={handleChange}
                        placeholder="Dhanvantari Ayurvedic Hospital"
                      />

                      <Input
                        label="Hospital ID"
                        name="hospitalId"
                        value={formData.hospitalId}
                        onChange={handleChange}
                        placeholder="HOSP001"
                      />

                      <div>
                        <label className="text-sm font-medium text-gray-700">
                          Medical System
                        </label>

                        <select
                          name="medicalSystem"
                          value={formData.medicalSystem}
                          onChange={handleChange}
                          className="mt-1 w-full px-4 py-3 rounded-xl border border-gray-200 bg-white outline-none focus:ring-2 focus:ring-emerald-500"
                        >
                          <option value="Ayurveda">Ayurveda</option>
                          <option value="unani">Unani</option>
                          <option value="siddha">Siddha</option>
                          <option value="homeopathy">Homeopathy</option>
                          <option value="yoga">Yoga</option>
                          <option value="naturopathy">Naturopathy</option>
                        </select>
                      </div>

                      <Input
                        label="Hospital Phone"
                        name="hospitalPhoneNumber"
                        value={formData.hospitalPhoneNumber}
                        onChange={handleChange}
                        placeholder="+91 9876543210"
                      />

                      <Input
                        label="Hospital Email"
                        name="hospitalEmail"
                        type="email"
                        value={formData.hospitalEmail}
                        onChange={handleChange}
                        placeholder="hospital@example.com"
                      />

                      <Input
                        label="Website"
                        name="website"
                        value={formData.website}
                        onChange={handleChange}
                        placeholder="https://hospital.com"
                      />

                    </div>

                    <div className="mt-4">
                      <label className="text-sm font-medium text-gray-700">
                        Hospital Address
                      </label>

                      <textarea
                        name="address"
                        value={formData.address}
                        onChange={handleChange}
                        rows="2"
                        placeholder="Enter complete hospital address"
                        className="mt-1 w-full px-4 py-3 rounded-xl border border-gray-200 resize-none outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                    </div>
                  </div>

                  {/* Admin Information */}

                  <div>
                    <h3 className="font-semibold text-gray-800 mb-4">
                      Administrator Information
                    </h3>

                    <div className="grid sm:grid-cols-2 gap-4">

                      <Input
                        label="Admin Name"
                        name="adminName"
                        value={formData.adminName}
                        onChange={handleChange}
                        placeholder="Enter full name"
                      />

                      <Input
                        label="Admin Email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleChange}
                        placeholder="admin@example.com"
                      />

                      <Input
                        label="Admin Phone Number"
                        name="phoneNumber"
                        value={formData.phoneNumber}
                        onChange={handleChange}
                        placeholder="+91 9876543210"
                      />

                      <Input
                        label="Password"
                        name="password"
                        type="password"
                        value={formData.password}
                        onChange={handleChange}
                        placeholder="Create a strong password"
                      />

                    </div>
                  </div>

                  {/* Messages */}

                  {error && (
                    <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm">
                      {error}
                    </div>
                  )}

                  {message && (
                    <div className="bg-emerald-50 border border-emerald-200 text-emerald-700 px-4 py-3 rounded-xl text-sm">
                      {message}
                    </div>
                  )}

                  {/* Button */}

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-600 to-cyan-600 text-white font-semibold shadow-lg hover:shadow-xl hover:scale-[1.01] transition disabled:opacity-60"
                  >
                    {loading
                      ? "Creating Account..."
                      : "Create Admin Account →"}
                  </button>

                  <button
                    type="button"
                    onClick={onBack}
                    className="w-full text-gray-500 text-sm hover:text-emerald-600"
                  >
                    ← Back to Login
                  </button>

                </form>
              </>
            )}

            {/* ================= OTP ================= */}

            {step === "otp" && (
              <div className="max-w-md mx-auto py-8">

                <div className="text-center mb-8">

                  <div className="mx-auto w-20 h-20 rounded-full bg-emerald-100 flex items-center justify-center text-3xl">
                    📱
                  </div>

                  <p className="text-sm font-semibold text-emerald-600 mt-6">
                    PHONE VERIFICATION
                  </p>

                  <h2 className="text-3xl font-bold text-gray-800 mt-2">
                    Verify your phone
                  </h2>

                  <p className="text-gray-500 mt-3">
                    Enter the 6-digit OTP sent to
                  </p>

                  <p className="font-semibold text-gray-800 mt-1">
                    {formData.phoneNumber}
                  </p>

                </div>

                <form onSubmit={handleVerifyOtp}>

                  <label className="text-sm font-medium text-gray-700">
                    Enter OTP
                  </label>

                  <input
                    type="text"
                    maxLength="6"
                    value={otp}
                    onChange={(e) =>
                      setOtp(e.target.value.replace(/\D/g, ""))
                    }
                    placeholder="000000"
                    className="mt-2 w-full text-center tracking-[0.6em] text-2xl font-bold px-4 py-4 rounded-xl border border-gray-200 outline-none focus:ring-2 focus:ring-emerald-500"
                  />

                  {error && (
                    <div className="mt-4 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm">
                      {error}
                    </div>
                  )}

                  {message && (
                    <div className="mt-4 bg-emerald-50 border border-emerald-200 text-emerald-700 px-4 py-3 rounded-xl text-sm">
                      {message}
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={loading}
                    className="mt-6 w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-600 to-cyan-600 text-white font-semibold shadow-lg hover:shadow-xl transition disabled:opacity-60"
                  >
                    {loading
                      ? "Verifying..."
                      : "Verify Phone Number"}
                  </button>

                </form>

                <button
                  onClick={handleSendOtp}
                  disabled={loading}
                  className="mt-4 w-full py-3 rounded-xl border border-emerald-200 text-emerald-700 font-semibold hover:bg-emerald-50 transition"
                >
                  Resend OTP
                </button>

                <button
                  onClick={() => {
                    setStep("signup");
                    setError("");
                    setMessage("");
                  }}
                  className="mt-5 w-full text-sm text-gray-500 hover:text-emerald-600"
                >
                  ← Edit registration details
                </button>

              </div>
            )}

          </div>
        </div>
      </div>
    </div>
  );
};


// ================= REUSABLE INPUT =================

const Input = ({
  label,
  name,
  value,
  onChange,
  placeholder,
  type = "text",
}) => {
  return (
    <div>
      <label className="text-sm font-medium text-gray-700">
        {label}
      </label>

      <input
        type={type}
        name={name}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className="mt-1 w-full px-4 py-3 rounded-xl border border-gray-200 bg-white outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition"
      />
    </div>
  );
};

export default AdminSignup;