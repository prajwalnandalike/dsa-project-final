import React, { useState } from "react";

const AdminOTPVerification = ({ phoneNumber, onVerified, onBack }) => {
  const [otp, setOtp] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  const handleVerify = async (e) => {
    e.preventDefault();

    if (otp.length !== 6) {
      setMessage("Please enter the 6-digit OTP.");
      return;
    }

    setLoading(true);
    setMessage("");

    try {
      const response = await fetch("/api/admin/verify-otp", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          phoneNumber,
          otp,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || data.message || "Invalid OTP");
      }

      alert("Phone number verified successfully!");

      onVerified();
    } catch (error) {
      setMessage(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-cyan-50 flex items-center justify-center p-6">

      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl p-8">

        {/* Icon */}
        <div className="flex justify-center mb-6">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center text-3xl shadow-lg">
            🔐
          </div>
        </div>

        <div className="text-center">
          <p className="text-sm font-semibold text-emerald-600">
            PHONE VERIFICATION
          </p>

          <h1 className="text-3xl font-bold text-slate-800 mt-2">
            Verify Your Phone
          </h1>

          <p className="text-slate-500 text-sm mt-3">
            Enter the 6-digit OTP sent to
          </p>

          <p className="font-semibold text-slate-700 mt-1">
            {phoneNumber}
          </p>
        </div>

        <form onSubmit={handleVerify} className="mt-8">

          <label className="block text-sm font-medium text-slate-700 mb-2">
            Enter OTP
          </label>

          <input
            type="text"
            inputMode="numeric"
            maxLength="6"
            value={otp}
            onChange={(e) =>
              setOtp(e.target.value.replace(/\D/g, ""))
            }
            placeholder="Enter 6-digit OTP"
            className="w-full text-center text-2xl tracking-[0.5em] rounded-xl border border-slate-200 px-4 py-4 outline-none focus:border-emerald-500 focus:ring-4 focus:ring-emerald-100"
          />

          {message && (
            <div className="mt-4 p-3 rounded-xl bg-red-50 text-red-600 text-sm text-center">
              {message}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full mt-6 py-3.5 rounded-xl bg-gradient-to-r from-emerald-600 to-cyan-500 text-white font-bold hover:opacity-90 transition disabled:opacity-60"
          >
            {loading ? "Verifying..." : "Verify OTP"}
          </button>

          <button
            type="button"
            onClick={onBack}
            className="w-full mt-3 py-3.5 rounded-xl border border-slate-300 text-slate-700 font-semibold hover:bg-slate-50 transition"
          >
            Back to Registration
          </button>

        </form>

        <p className="text-xs text-center text-slate-400 mt-6">
          Your phone number is required to activate the administrator account.
        </p>

      </div>
    </div>
  );
};

export default AdminOTPVerification;