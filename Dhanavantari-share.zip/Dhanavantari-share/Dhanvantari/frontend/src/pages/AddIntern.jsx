import React, { useEffect, useState } from "react";

const AddIntern = ({ onBack }) => {
  const [formData, setFormData] = useState({
    internName: "",
    internId: "",
    email: "",
    mobile: "",
    college: "",
    course: "",
    year: "",
    department: "",
    joiningDate: "",
    supervisorDoctorId: "",
    password: "",
  });

  const [doctors, setDoctors] = useState([]);
  const [loading, setLoading] = useState(false);
  const [doctorLoading, setDoctorLoading] = useState(true);
  const [error, setError] = useState("");

  // Load doctors for supervisor dropdown
  useEffect(() => {
    const fetchDoctors = async () => {
      try {
        const token = localStorage.getItem("token");

        const response = await fetch("/api/doctors", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.message || "Failed to load doctors");
        }

        setDoctors(data.doctors || []);
      } catch (error) {
        setError(error.message);
      } finally {
        setDoctorLoading(false);
      }
    };

    fetchDoctors();
  }, []);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    setLoading(true);
    setError("");

    try {
      const token = localStorage.getItem("token");

      const response = await fetch("/api/interns", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Failed to create intern");
      }

      alert("Intern created successfully!");
      onBack();

    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-cyan-50 p-6">

      {/* Back */}
      <button
        onClick={onBack}
        className="mb-6 rounded-xl bg-green-700 px-5 py-3 text-sm font-semibold text-white shadow hover:bg-green-800"
      >
        ← Back to Interns
      </button>

      <div className="mx-auto max-w-4xl">

        {/* Header */}
        <div className="mb-6">
          <p className="text-sm font-semibold uppercase tracking-wider text-emerald-600">
            Hospital Administration
          </p>

          <h1 className="mt-1 text-3xl font-bold text-slate-800">
            Add Intern
          </h1>

          <p className="mt-2 text-sm text-slate-500">
            Create an intern account and assign their academic and clinical details.
          </p>
        </div>

        {/* Form Card */}
        <div className="rounded-3xl border border-slate-200 bg-white p-8 shadow-xl">

          {error && (
            <div className="mb-6 rounded-xl bg-red-50 p-4 text-sm font-medium text-red-700">
              {error}
            </div>
          )}

          <form
            onSubmit={handleSubmit}
            className="grid grid-cols-1 gap-5 md:grid-cols-2"
          >

            {/* Intern Name */}
            <div>
              <label className="form-label">
                Intern Name
              </label>

              <input
                name="internName"
                value={formData.internName}
                onChange={handleChange}
                placeholder="Enter intern name"
                className="form-input"
                required
              />
            </div>

            {/* Intern ID */}
            <div>
              <label className="form-label">
                Intern ID
              </label>

              <input
                name="internId"
                value={formData.internId}
                onChange={handleChange}
                placeholder="e.g. INT001"
                className="form-input"
                required
              />
            </div>

            {/* Email */}
            <div>
              <label className="form-label">
                Email
              </label>

              <input
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="intern@example.com"
                className="form-input"
                required
              />
            </div>

            {/* Mobile */}
            <div>
              <label className="form-label">
                Mobile Number
              </label>

              <input
                name="mobile"
                value={formData.mobile}
                onChange={handleChange}
                placeholder="Enter mobile number"
                className="form-input"
                required
              />
            </div>

            {/* College */}
            <div>
              <label className="form-label">
                College
              </label>

              <input
                name="college"
                value={formData.college}
                onChange={handleChange}
                placeholder="Enter college name"
                className="form-input"
              />
            </div>

            {/* Course */}
            <div>
              <label className="form-label">
                Course
              </label>

              <input
                name="course"
                value={formData.course}
                onChange={handleChange}
                placeholder="e.g. BAMS"
                className="form-input"
              />
            </div>

            {/* Year */}
            <div>
              <label className="form-label">
                Year
              </label>

              <select
                name="year"
                value={formData.year}
                onChange={handleChange}
                className="form-input"
              >
                <option value="">Select year</option>
                <option value="1st Year">1st Year</option>
                <option value="2nd Year">2nd Year</option>
                <option value="3rd Year">3rd Year</option>
                <option value="4th Year">4th Year</option>
                <option value="Internship">Internship</option>
              </select>
            </div>

            {/* Department */}
            <div>
              <label className="form-label">
                Department
              </label>

              <input
                name="department"
                value={formData.department}
                onChange={handleChange}
                placeholder="e.g. Ayurveda"
                className="form-input"
              />
            </div>

            {/* Joining Date */}
            <div>
              <label className="form-label">
                Joining Date
              </label>

              <input
                name="joiningDate"
                type="date"
                value={formData.joiningDate}
                onChange={handleChange}
                className="form-input"
              />
            </div>

            {/* Supervisor */}
            <div>
              <label className="form-label">
                Supervisor Doctor
              </label>

              <select
                name="supervisorDoctorId"
                value={formData.supervisorDoctorId}
                onChange={handleChange}
                className="form-input"
                disabled={doctorLoading}
              >
                <option value="">
                  {doctorLoading
                    ? "Loading doctors..."
                    : "Select supervisor doctor"}
                </option>

                {doctors.map((doctor) => (
                  <option key={doctor._id} value={doctor._id}>
                    Dr. {doctor.doctorName}
                  </option>
                ))}
              </select>
            </div>

            {/* Password */}
            <div>
              <label className="form-label">
                Temporary Password
              </label>

              <input
                name="password"
                type="password"
                value={formData.password}
                onChange={handleChange}
                placeholder="Create temporary password"
                className="form-input"
                required
              />
            </div>

            {/* Submit */}
            <div className="md:col-span-2 mt-4">
              <button
                type="submit"
                disabled={loading}
                className="w-full rounded-xl bg-gradient-to-r from-green-700 to-emerald-600 px-6 py-4 font-bold text-white shadow-lg transition hover:from-green-800 hover:to-emerald-700 disabled:opacity-50"
              >
                {loading ? "Creating Intern..." : "Create Intern"}
              </button>
            </div>

          </form>
        </div>
      </div>
    </div>
  );
};

export default AddIntern;