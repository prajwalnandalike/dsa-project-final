import React, { useState } from "react";
import logo from "../assets/dhanvantarilogo.jpeg";

const DoctorLogin = ({onBack, onLoginSuccess}) => {

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleLogin = async (e) => {
    e.preventDefault();

    setError("");

    if (!email || !password) {
      setError("Please enter your email and password.");
      return;
    }

    try {
      setLoading(true);

      const response = await fetch("/api/doctors/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email,
          password,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Login failed");
      }

      // Store JWT
      localStorage.setItem("token", data.token);

      // Store basic doctor information
      localStorage.setItem(
        "user",
        JSON.stringify({
          userId: data.doctor?._id,
          doctorName: data.doctor?.doctorName,
          email: data.doctor?.email,
          hospitalId: data.doctor?.hospitalId,
          role: "doctor",
          qualification: data.doctor?.qualification,
          specialization: data.doctor?.specialization,
          department: data.doctor?.department,
        })
      );

      console.log("Doctor login successful");

      // Temporary success message
      
      if(onLoginSuccess){
        onLoginSuccess()
      }

      // Dashboard will be connected later
      // window.location.href = "/doctor/dashboard";

    } catch (err) {
      console.error(err);
      setError(err.message || "Unable to login");
    } finally {
      setLoading(false);
    }
  };

  return (
  
     <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-cyan-50">

      

    {/* Your existing Doctor Login layout */}
    {/* <div className="flex min-h-screen ..."></div> */}

      {/* ================= HEADER ================= */}
      <header className="flex items-center justify-between bg-gradient-to-r from-green-800 via-green-700 to-cyan-600 px-6 py-4 text-white shadow-lg">

        <div className="flex items-center gap-3">

          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/15 p-1">
            <img
              src={logo}
              alt="Dhanvantari Logo"
              className="h-full w-full rounded-lg object-contain"
            />
          </div>

          <div>
            <h1 className="text-xl font-bold">
              Dhanvantari
            </h1>

            <p className="text-xs text-green-100">
              Smart AYUSH Care Platform
            </p>
          </div>

        </div>

        <div className="hidden rounded-full bg-white/10 px-4 py-2 text-sm font-medium sm:block">
          Doctor Portal
        </div>

      </header>
 

      {/* ================= MAIN ================= */}
      <main className="flex min-h-[calc(100vh-64px)] items-center justify-start px-4 py-8">

        <div className="grid w-full max-w-5xl overflow-hidden rounded-3xl bg-white shadow-2xl lg:grid-cols-2">

          {/* ================= LEFT PANEL ================= */}
          <div className="relative hidden overflow-hidden bg-gradient-to-br from-green-800 via-green-700 to-cyan-600 p-10 text-white lg:flex lg:flex-col lg:justify-between">

            <div>

              <div className="mb-8 flex h-16 w-16 items-center justify-center rounded-2xl bg-white/15 p-2 backdrop-blur-sm">
                <img
                  src={logo}
                  alt="Dhanvantari"
                  className="h-full w-full rounded-xl object-contain"
                />
              </div>

              <p className="mb-3 text-sm font-semibold uppercase tracking-[0.2em] text-green-100">
                Doctor Portal
              </p>

              <h2 className="text-4xl font-bold leading-tight">
                Care with
                <br />
                confidence.
              </h2>

              <p className="mt-5 max-w-md text-sm leading-7 text-green-50">
                Manage patients, clinical cases, AYUSH case-taking and
                personalized care through one secure hospital platform.
              </p>
              {/* Dhanvantari Shloka */}
<div className="mt-7 border-y border-white/20 py-4 text-center">
  <p className="text-lg font-semibold tracking-wide text-white">
    ॐ नमो भगवते धन्वन्तरये ।
  </p>

  <p className="mt-1.5 text-xs italic text-emerald-100">
    Salutations to Lord Dhanvantari
  </p>
</div>

            </div>


            {/* Feature cards */}
            <div className="mt-10 space-y-3">

              <Feature
                icon="🩺"
                title="Clinical Care"
                text="Manage patient cases securely"
              />

              <Feature
                icon="🌿"
                title="AYUSH Case Taking"
                text="System-specific clinical workflows"
              />

              <Feature
                icon="📋"
                title="Care Instructions"
                text="Review and approve patient care"
              />

            </div>

          </div>


          {/* ================= LOGIN PANEL ================= */}
          <div className="p-7 sm:p-10 lg:p-12">

            <div className="mx-auto max-w-md">

              {/* Mobile logo */}
              <div className="mb-6 flex items-center gap-3 lg:hidden">

                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-50 p-1">
                  <img
                    src={logo}
                    alt="Dhanvantari Logo"
                    className="h-full w-full rounded-lg object-contain"
                  />
                </div>

                <div>
                  <h1 className="font-bold text-slate-800">
                    Dhanvantari
                  </h1>

                  <p className="text-xs text-slate-500">
                    Doctor Portal
                  </p>
                </div>

              </div>


              {/* Heading */}
              <div className="mb-8">

                <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-100 text-2xl">
                  🩺
                </div>

                <p className="text-sm font-semibold uppercase tracking-wider text-emerald-600">
                  DOCTOR LOGIN
                </p>

                <h2 className="mt-2 text-3xl font-bold tracking-tight text-slate-800">
                  Welcome back, Doctor
                </h2>

                <p className="mt-2 text-sm leading-6 text-slate-500">
                  Sign in to manage your patients and clinical care securely.
                </p>

              </div>


              {/* Error */}
              {error && (
                <div className="mb-5 flex items-start gap-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">

                  <span className="text-lg">
                    ⚠️
                  </span>

                  <p>
                    {error}
                  </p>

                </div>
              )}


              {/* Login form */}
              <form
                onSubmit={handleLogin}
                className="space-y-5"
              >

                {/* Email */}
                <div>

                  <label className="mb-2 block text-sm font-semibold text-slate-700">
                    Doctor Email
                  </label>

                  <div className="relative">

                    <span className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-lg">
                      ✉️
                    </span>

                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Enter your registered email"
                      className="w-full rounded-xl border border-slate-200 bg-slate-50 py-3.5 pl-12 pr-4 text-sm text-slate-800 outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100"
                    />

                  </div>

                </div>


                {/* Password */}
                <div>

                  <label className="mb-2 block text-sm font-semibold text-slate-700">
                    Password
                  </label>

                  <div className="relative">

                    <span className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-lg">
                      🔒
                    </span>

                    <input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter your password"
                      className="w-full rounded-xl border border-slate-200 bg-slate-50 py-3.5 pl-12 pr-4 text-sm text-slate-800 outline-none transition focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-100"
                    />

                  </div>

                </div>


                {/* Login button */}
                <button
                  type="submit"
                  disabled={loading}
                  className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-green-700 to-emerald-600 px-5 py-3.5 text-sm font-bold text-white shadow-lg shadow-emerald-200 transition hover:from-green-800 hover:to-emerald-700 disabled:cursor-not-allowed disabled:opacity-60"
                >

                  {loading ? (
                    <>
                      <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                      Signing in...
                    </>
                  ) : (
                    <>
                      🩺
                      Sign in as Doctor
                    </>
                  )}

                </button>
                {/* Back to Portals */}
<div className="mt-6 flex justify-center">
  <button
    type="button"
    onClick={onBack}
    className="flex w-full max-w-md items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 px-6 py-3.5 text-sm font-bold text-white shadow-lg shadow-emerald-500/20 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-xl"
  >
    <span className="text-lg">←</span>
    Back to Portals
  </button>
</div>

              </form>


              {/* Security notice */}
              <div className="mt-8 rounded-2xl border border-emerald-100 bg-emerald-50 p-4">

                <div className="flex gap-3">

                  <div className="text-xl">
                    🛡️
                  </div>

                  <div>

                    <h3 className="text-sm font-semibold text-emerald-800">
                      Secure Clinical Access
                    </h3>

                    <p className="mt-1 text-xs leading-5 text-emerald-700">
                      Patient and clinical information is available only to
                      authorized hospital users.
                    </p>

                  </div>

                </div>

              </div>


              {/* Footer */}
              <p className="mt-8 text-center text-xs text-slate-400">
                Dhanvantari • Smart AYUSH Care Platform
              </p>

            </div>

          </div>

        </div>
  

      </main>
     

    </div>
  );
};


/* ================= FEATURE COMPONENT ================= */

const Feature = ({ icon, title, text }) => {
  return (
    <div className="flex items-center gap-4 rounded-2xl bg-white/10 p-4 backdrop-blur-sm">

      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white/15 text-xl">
        {icon}
      </div>

      <div>
        <h3 className="text-sm font-semibold">
          {title}
        </h3>

        <p className="mt-1 text-xs text-green-100">
          {text}
        </p>
      </div>

    </div>
  );
};


export default DoctorLogin;