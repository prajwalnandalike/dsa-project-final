import React, { useEffect, useMemo, useState } from 'react'

const CarePopup = ({
  patient,
  diagnosis,
  dosha,
  patientGroup,
  medicalSystem = 'Ayurveda',
  onClose,
  onApprove
}) => {
  const [recommendations, setRecommendations] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const [aushadhi, setAushadhi] = useState('')
  const [dosage, setDosage] = useState('')
  const [sevanaKala, setSevanaKala] = useState('')

  const [saving, setSaving] = useState(false)

  // -------------------------------------------------------
  // FETCH CARE DATA FROM BACKEND

  useEffect(() => {
    const fetchCare = async () => {
      try {
        setLoading(true)
        setError('')

        const token = localStorage.getItem('token')

        const params = new URLSearchParams({
          medicalSystem,
          diseaseName: diagnosis,
          dosha
        })

        if (patientGroup) {
          params.append('patientGroup', patientGroup)
        }

        const response = await fetch(
          `/api/care?${params.toString()}`,
          {
            headers: {
              Authorization: `Bearer ${token}`
            }
          }
        )

        const data = await response.json()

        if (!response.ok) {
          throw new Error(
            data.message || 'Failed to fetch care recommendations'
          )
        }

        setRecommendations(
          data.recommendations || []
        )
      } catch (err) {
        console.error(err)

        setError(
          err.message ||
          'Unable to load care recommendations'
        )
      } finally {
        setLoading(false)
      }
    }

    if (diagnosis && dosha) {
      fetchCare()
    }
  }, [
    medicalSystem,
    diagnosis,
    dosha,
    patientGroup
  ])

  // -------------------------------------------------------
  // FIND MOST SPECIFIC COMBINATION
  // -------------------------------------------------------

  const selectedCare = useMemo(() => {
    if (!recommendations.length) {
      return null
    }

    const normalizedDosha =
      dosha?.trim().toLowerCase()

    const normalizedGroup =
      patientGroup?.trim().toLowerCase()

    // 1. EXACT:
    // Disease + Dosha + Patient Group
    const exactMatch = recommendations.find(
      (item) =>
        item?.dosha?.trim().toLowerCase() ===
          normalizedDosha &&
        item?.patientGroup?.trim().toLowerCase() ===
          normalizedGroup
    )

    if (exactMatch) {
      return exactMatch
    }

    // 2. GENERAL:
    // Disease + Dosha
    // patientGroup empty means applicable generally
    const generalMatch = recommendations.find(
      (item) =>
        item?.dosha?.trim().toLowerCase() ===
          normalizedDosha &&
        (!item?.patientGroup ||
          item.patientGroup.trim() === '')
    )

    if (generalMatch) {
      return generalMatch
    }

    return null
  }, [
    recommendations,
    dosha,
    patientGroup
  ])

  // -------------------------------------------------------
  // LOAD DOCTOR EDITABLE VALUES
  // -------------------------------------------------------

  useEffect(() => {
    if (!selectedCare) {
      setAushadhi('')
      setDosage('')
      setSevanaKala('')
      return
    }

    setAushadhi(
      selectedCare.aushadhi || ''
    )

    setDosage(
      getValue(selectedCare.dosage)
    )

    setSevanaKala(
      getValue(selectedCare.sevanaKala)
    )
  }, [selectedCare])

  // -------------------------------------------------------
  // APPROVE
  // -------------------------------------------------------

  const handleApprove = async () => {
    const finalCare = {
      patientId: patient?.patientId,

      medicalSystem,

      diseaseName:
        selectedCare?.diseaseName ||
        diagnosis,

      namcCode:
        selectedCare?.namcCode || '',

      namcId:
        selectedCare?.namcId || '',

      dosha,

      patientGroup,

      pathya:
        selectedCare?.pathya || [],

      apathya:
        selectedCare?.apathya || [],

      aushadhi,

      dosage,

      sevanaKala
    }

    try {
      setSaving(true)

      if (onApprove) {
        await onApprove(finalCare)
      }

    } catch (err) {
      console.error(err)
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm">

      <div className="flex max-h-[94vh] w-full max-w-6xl flex-col overflow-hidden rounded-3xl bg-white shadow-2xl">

        {/* ================================================= */}
        {/* HEADER */}
        {/* ================================================= */}

        <div className="relative overflow-hidden bg-gradient-to-r from-green-800 via-green-700 to-cyan-600 px-6 py-6 text-white">

          <div className="absolute -right-16 -top-16 h-40 w-40 rounded-full bg-white/10" />

          <div className="relative flex items-center justify-between">

            <div className="flex items-center gap-4">

              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white/15">
                <LeafIcon />
              </div>

              <div>

                <div className="flex flex-wrap items-center gap-3">

                  <h2 className="text-2xl font-bold">
                    Care Instructions
                  </h2>

                  <span className="rounded-full bg-white/20 px-3 py-1 text-xs font-semibold">
                    {medicalSystem}
                  </span>

                </div>

                <p className="mt-1 text-sm text-green-100">
                  Doctor-reviewed personalized care
                </p>

              </div>

            </div>

            <button
              onClick={onClose}
              className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 text-2xl hover:bg-white/20"
            >
              ×
            </button>

          </div>

        </div>


        {/* ================================================= */}
        {/* CONTENT */}
        {/* ================================================= */}

        <div className="overflow-y-auto p-6">

          {/* PATIENT & CASE INFORMATION */}

<div className="mb-6 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">

  {/* Patient header */}

  <div className="mb-5 flex items-center justify-between">

    <div className="flex items-center gap-3">

      <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
        <UserIcon />
      </div>

      <div>

        <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">
          Patient
        </p>

        <h3 className="text-lg font-bold text-slate-800">
          {patient?.patientName || 'Patient'}
        </h3>

      </div>

    </div>

    <div className="hidden rounded-full bg-emerald-50 px-3 py-1.5 text-xs font-semibold text-emerald-700 sm:block">
      Clinical Care
    </div>

  </div>


  {/* Patient information */}

  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">

    <div className="rounded-xl bg-slate-50 p-4">
      <p className="text-xs font-medium text-slate-400">
        Patient ID
      </p>

      <p className="mt-1 font-semibold text-slate-800">
        {patient?.patientId || '—'}
      </p>
    </div>


    <div className="rounded-xl bg-blue-50 p-4">
      <p className="text-xs font-medium text-blue-500">
        Diagnosis
      </p>

      <p className="mt-1 font-semibold text-slate-800">
        {diagnosis || '—'}
      </p>
    </div>


    <div className="rounded-xl bg-amber-50 p-4">
      <p className="text-xs font-medium text-amber-600">
        Dosha
      </p>

      <p className="mt-1 font-semibold text-slate-800">
        {dosha || '—'}
      </p>
    </div>


    <div className="rounded-xl bg-purple-50 p-4">
      <p className="text-xs font-medium text-purple-600">
        Patient Group
      </p>

      <p className="mt-1 font-semibold text-slate-800">
        {patientGroup || '—'}
      </p>
    </div>

  </div>

</div>

          


          {/* LOADING */}

          {loading && (
            <div className="flex flex-col items-center justify-center py-16">

              <div className="h-10 w-10 animate-spin rounded-full border-4 border-slate-200 border-t-green-600" />

              <p className="mt-4 text-sm text-slate-500">
                Loading care recommendations...
              </p>

            </div>
          )}


          {/* ERROR */}

          {!loading && error && (

            <div className="rounded-2xl border border-red-200 bg-red-50 p-5 text-red-700">

              <div className="flex gap-3">

                <AlertIcon />

                <div>

                  <p className="font-semibold">
                    Unable to load care
                  </p>

                  <p className="mt-1 text-sm">
                    {error}
                  </p>

                </div>

              </div>

            </div>

          )}


          {/* NO MATCH */}

          {!loading &&
            !error &&
            !selectedCare && (

              <div className="rounded-2xl border border-amber-200 bg-amber-50 p-6 text-center">

                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-amber-100 text-amber-700">
                  <AlertIcon />
                </div>

                <h3 className="mt-3 font-bold text-amber-900">
                  No matching care recommendation
                </h3>

                <p className="mt-1 text-sm text-amber-700">
                  No recommendation was found for this
                  disease, Dosha and patient group.
                </p>

              </div>

            )}


          {/* CARE CONTENT */}

          {!loading &&
            !error &&
            selectedCare && (
            <>

                {/* MATCHED CARE COMBINATION */}

<div className="mb-7 overflow-hidden rounded-2xl border border-blue-100 bg-gradient-to-r from-blue-50 to-cyan-50">

  <div className="flex items-center gap-3 border-b border-blue-100 px-5 py-4">

    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-100 text-blue-700">
      <SparkleIcon />
    </div>

    <div>
      <h3 className="font-bold text-slate-800">
        Matched Care Profile
      </h3>

      <p className="text-xs text-slate-500">
        Care information selected from the clinical combination
      </p>
    </div>

  </div>


  <div className="grid grid-cols-1 gap-3 p-5 sm:grid-cols-3">

    <div className="rounded-xl bg-white p-4 shadow-sm">
      <p className="text-xs font-medium uppercase tracking-wide text-slate-400">
        Disease
      </p>

      <p className="mt-1 font-semibold text-slate-800">
        {diagnosis || '—'}
      </p>
    </div>


    <div className="rounded-xl bg-white p-4 shadow-sm">
      <p className="text-xs font-medium uppercase tracking-wide text-slate-400">
        Dosha
      </p>

      <p className="mt-1 font-semibold text-slate-800">
        {dosha || '—'}
      </p>
    </div>


    <div className="rounded-xl bg-white p-4 shadow-sm">
      <p className="text-xs font-medium uppercase tracking-wide text-slate-400">
        Patient Group
      </p>

      <p className="mt-1 font-semibold text-slate-800">
        {selectedCare.patientGroup || 'General'}
      </p>
    </div>

  </div>


  <div className="flex items-center gap-2 border-t border-blue-100 px-5 py-3 text-xs text-blue-700">

    <CheckIcon />

    <span>
      Applicable care information found
    </span>

  </div>

</div>



                {/* REFERENCE */}

                <section className="mb-7">

                  <SectionTitle
                    icon={<ClipboardIcon />}
                    title="Clinical Reference"
                    subtitle="Matched terminology from care knowledge"
                  />

                  <div className="grid gap-4 md:grid-cols-3">

                    <Reference
                      label="Disease"
                      value={
                        selectedCare.diseaseName ||
                        diagnosis
                      }
                    />

                    <Reference
                      label="NAMC Code"
                      value={
                        selectedCare.namcCode ||
                        '—'
                      }
                    />

                    <Reference
                      label="NAMC ID"
                      value={
                        selectedCare.namcId ||
                        '—'
                      }
                    />

                  </div>

                </section>


                {/* ===================================================== */}
{/* PATHYA + APATHYA */}
{/* ===================================================== */}

<div className="mb-7 grid grid-cols-1 gap-5 lg:grid-cols-2">

  {/* PATHYA */}

  <CareCard
    title="Pathya"
    subtitle="Recommended diet & lifestyle"
    icon={<FoodIcon />}
    type="good"
  >

    <div className="mb-4 rounded-xl bg-white/70 px-4 py-3">
      <p className="text-xs font-medium uppercase tracking-wide text-emerald-600">
        Recommended for this case
      </p>

      <p className="mt-1 text-sm text-slate-600">
        Follow the applicable dietary and lifestyle recommendations.
      </p>
    </div>

    <RecommendationList
      items={selectedCare.pathya}
      good
    />

  </CareCard>


  {/* APATHYA */}

  <CareCard
    title="Apathya"
    subtitle="Foods & activities to avoid"
    icon={<BanIcon />}
    type="bad"
  >

    <div className="mb-4 rounded-xl bg-white/70 px-4 py-3">
      <p className="text-xs font-medium uppercase tracking-wide text-rose-600">
        Avoid / Restrict
      </p>

      <p className="mt-1 text-sm text-slate-600">
        Review these restrictions before final approval.
      </p>
    </div>

    <RecommendationList
      items={selectedCare.apathya}
    />

  </CareCard>

</div>

                

                {/* ===================================================== */}
{/* AUSHADHI & ADMINISTRATION */}
{/* ===================================================== */}

<div className="mb-7">

  {/* Section heading */}
  <div className="mb-4 flex items-center gap-3">
    <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-blue-100 text-blue-700">
      <MedicineIcon />
    </div>

    <div>
      <h3 className="text-lg font-bold text-slate-800">
        Aushadhi & Administration
      </h3>
      <p className="text-sm text-slate-500">
        Medicine and administration details for this care plan
      </p>
    </div>
  </div>

  {/* Information cards */}
  <div className="grid grid-cols-1 gap-5 md:grid-cols-3">

    {/* Aushadhi */}
    <div className="rounded-2xl border border-blue-100 bg-gradient-to-br from-blue-50 to-white p-5 shadow-sm">

      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-100 text-blue-700">
            <MedicineIcon />
          </div>

          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-blue-500">
              Aushadhi
            </p>
            <p className="text-sm font-semibold text-slate-700">
              Medicine
            </p>
          </div>
        </div>

        <span className="rounded-full bg-amber-100 px-2.5 py-1 text-[11px] font-semibold text-amber-700">
          Doctor Entry
        </span>
      </div>

      <div className="rounded-xl bg-white p-4">
        <p className="text-sm leading-6 text-slate-700">
          {aushadhi || 'No medicine entered yet'}
        </p>
      </div>

    </div>


    {/* Dosage */}
    <div className="rounded-2xl border border-emerald-100 bg-gradient-to-br from-emerald-50 to-white p-5 shadow-sm">

      <div className="mb-4 flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
          <DoseIcon />
        </div>

        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-emerald-600">
            Dosage
          </p>
          <p className="text-sm font-semibold text-slate-700">
            Quantity / Dose
          </p>
        </div>
      </div>

      <div className="rounded-xl bg-white p-4">
        <p className="text-sm leading-6 text-slate-700">
          {dosage || 'Not specified'}
        </p>
      </div>

    </div>


    {/* Sevana Kala */}
    <div className="rounded-2xl border border-purple-100 bg-gradient-to-br from-purple-50 to-white p-5 shadow-sm">

      <div className="mb-4 flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-purple-100 text-purple-700">
          <ClockIcon />
        </div>

        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-purple-600">
            Sevana Kala
          </p>
          <p className="text-sm font-semibold text-slate-700">
            Administration Time
          </p>
        </div>
      </div>

      <div className="rounded-xl bg-white p-4">
        <p className="text-sm leading-6 text-slate-700">
          {sevanaKala || 'Not specified'}
        </p>
      </div>

    </div>

  </div>

</div>

                

                {/* ===================================================== */}
{/* DOCTOR REVIEW */}
{/* ===================================================== */}

<div className="mb-7 overflow-hidden rounded-2xl border border-amber-200 bg-white shadow-sm">

  {/* Header */}
  <div className="border-b border-amber-100 bg-gradient-to-r from-amber-50 to-white px-5 py-4">
    <div className="flex items-start gap-3">

      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-amber-100 text-amber-700">
        <EditIcon />
      </div>

      <div>
        <h3 className="text-lg font-bold text-slate-800">
          Doctor Review
        </h3>

        <p className="mt-1 text-sm text-slate-500">
          Review and update the care instructions before approval
        </p>
      </div>

    </div>
  </div>


  {/* Review notice */}
  <div className="p-5">

    <div className="mb-5 flex items-start gap-3 rounded-xl border border-blue-100 bg-blue-50 p-4">

      <div className="mt-0.5 text-blue-600">
        <InfoIcon />
      </div>

      <div>
        <p className="text-sm font-semibold text-blue-800">
          Clinician-in-the-loop
        </p>

        <p className="mt-1 text-sm leading-6 text-blue-700">
          The doctor has final control over the care instructions.
          Please review the information and make any necessary changes
          before approving.
        </p>
      </div>

    </div>


    {/* Editable fields */}
    <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">

      {/* Aushadhi */}
      <div>
        <label className="mb-2 flex items-center gap-2 text-sm font-semibold text-slate-700">
          <MedicineIcon />
          Aushadhi
        </label>

        <textarea
          value={aushadhi}
          onChange={(e) => setAushadhi(e.target.value)}
          placeholder="Enter medicine prescribed by the doctor..."
          rows={5}
          className="w-full resize-none rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-blue-400 focus:ring-4 focus:ring-blue-100"
        />

        <p className="mt-2 text-xs text-slate-400">
          Doctor-entered medicine
        </p>
      </div>


      {/* Dosage */}
      <div>
        <label className="mb-2 flex items-center gap-2 text-sm font-semibold text-slate-700">
          <ScaleIcon />
          Dosage
        </label>

        <textarea
          value={dosage}
          onChange={(e) => setDosage(e.target.value)}
          placeholder="Enter dosage..."
          rows={5}
          className="w-full resize-none rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-emerald-400 focus:ring-4 focus:ring-emerald-100"
        />

        <p className="mt-2 text-xs text-slate-400">
          Quantity / dose as prescribed
        </p>
      </div>


      {/* Sevana Kala */}
      <div>
        <label className="mb-2 flex items-center gap-2 text-sm font-semibold text-slate-700">
          <ClockIcon />
          Sevana Kala
        </label>

        <textarea
          value={sevanaKala}
          onChange={(e) => setSevanaKala(e.target.value)}
          placeholder="Enter medicine administration timing..."
          rows={5}
          className="w-full resize-none rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-purple-400 focus:ring-4 focus:ring-purple-100"
        />

        <p className="mt-2 text-xs text-slate-400">
          When the medicine should be taken
        </p>
      </div>

    </div>


    {/* Approval status */}
    <div className="mt-5 flex flex-col gap-3 rounded-xl border border-slate-200 bg-slate-50 p-4 sm:flex-row sm:items-center sm:justify-between">

      <div className="flex items-center gap-3">

        <div className="flex h-9 w-9 items-center justify-center rounded-full bg-amber-100 text-amber-700">
          <ShieldIcon />
        </div>

        <div>
          <p className="text-sm font-semibold text-slate-700">
            Ready for clinical approval
          </p>

          <p className="text-xs text-slate-500">
            Changes will be included in the final care instructions
          </p>
        </div>

      </div>

      <span className="w-fit rounded-full bg-amber-100 px-3 py-1.5 text-xs font-semibold text-amber-700">
        Pending Approval
      </span>

    </div>

  </div>

</div>


{/* ===================================================== */}
{/* APPROVAL FOOTER */}
{/* ===================================================== */}

<div className="sticky bottom-0 z-20 -mx-5 -mb-5 mt-8 border-t border-slate-200 bg-white/95 p-5 backdrop-blur">

  <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">

    {/* Approval information */}
    <div className="flex items-start gap-3">

      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-emerald-700">
        <ShieldIcon />
      </div>

      <div>
        <p className="text-sm font-semibold text-slate-800">
          Doctor approval required
        </p>

        <p className="mt-1 text-xs leading-5 text-slate-500">
          Review all care instructions before approving and sending
          them to the patient's registered phone.
        </p>
      </div>

    </div>


    {/* Action buttons */}
    <div className="flex w-full gap-3 sm:w-auto">

      <button
        type="button"
        onClick={onClose}
        disabled={saving}
        className="flex-1 rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-semibold text-slate-600 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50 sm:flex-none"
      >
        Cancel
      </button>

      <button
        type="button"
        onClick={handleApprove}
        disabled={saving || !selectedCare}
        className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-emerald-600 px-6 py-3 text-sm font-bold text-white shadow-md transition hover:bg-emerald-700 disabled:cursor-not-allowed disabled:opacity-50 sm:flex-none"
      >

        {saving ? (
          <>
            <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
            Processing...
          </>
        ) : (
          <>
            <CheckIcon />
            Approve & Send
          </>
        )}

      </button>

    </div>

  </div>

</div>
</>
            )}
             </div>
              </div>
               </div>



          )
        }
       
          

/* ========================================================= */
/* HELPERS */
/* ========================================================= */

const getValue = (value) => {
  if (!value) return ''

  if (Array.isArray(value)) {
    if (!value.length) return ''

    if (
      typeof value[0] === 'object' &&
      value[0]?.value
    ) {
      return value
        .map((item) => item.value)
        .join(', ')
    }

    return value.join(', ')
  }

  return String(value)
}


/* ========================================================= */
/* SMALL COMPONENTS */
/* ========================================================= */

const Info = ({ label, value }) => (
  <div>
    <p className="text-xs text-slate-400">
      {label}
    </p>

    <p className="mt-1 truncate text-sm font-semibold text-slate-800">
      {value || '—'}
    </p>
  </div>
)


const SectionTitle = ({
  icon,
  title,
  subtitle
}) => (
  <div className="mb-4 flex items-center gap-3">

    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-50 text-blue-600">
      {icon}
    </div>

    <div>
      <h3 className="font-bold text-slate-800">
        {title}
      </h3>

      <p className="text-xs text-slate-500">
        {subtitle}
      </p>
    </div>

  </div>
)


const Reference = ({
  label,
  value
}) => (
  <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">

    <p className="text-xs uppercase tracking-wide text-slate-400">
      {label}
    </p>

    <p className="mt-2 font-semibold text-slate-800">
      {value || '—'}
    </p>

  </div>
)


const CareCard = ({
  title,
  subtitle,
  icon,
  type,
  children
}) => {

  const good = type === 'good'

  return (
    <div
      className={
        good
          ? 'rounded-3xl border border-emerald-200 bg-emerald-50/60 p-5'
          : 'rounded-3xl border border-rose-200 bg-rose-50/60 p-5'
      }
    >

      <div className="mb-5 flex items-center gap-3">

        <div
          className={
            good
              ? 'flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700'
              : 'flex h-11 w-11 items-center justify-center rounded-xl bg-rose-100 text-rose-700'
          }
        >
          {icon}
        </div>

        <div>

          <h3 className="font-bold text-slate-800">
            {title}
          </h3>

          <p className="text-xs text-slate-500">
            {subtitle}
          </p>

        </div>

      </div>

      {children}

    </div>
  )
}


const RecommendationList = ({
  items,
  good = false
}) => {

  if (!Array.isArray(items) || !items.length) {
    return (
      <div className="rounded-xl bg-white p-4 text-sm text-slate-500">
        No information available.
      </div>
    )
  }

  return (
    <div className="space-y-3">

      {items.map((item, index) => (

        <div
          key={index}
          className="flex items-start gap-3 rounded-xl bg-white p-3 shadow-sm"
        >

          <div
            className={
              good
                ? 'mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-emerald-700'
                : 'mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-rose-100 text-rose-700'
            }
          >

            {good ? <CheckIcon /> : <AlertIcon />}

          </div>

          <p className="text-sm leading-6 text-slate-700">
            {item}
          </p>

        </div>

      ))}

    </div>
  )
}


const DataCard = ({
  title,
  icon,
  value
}) => (
  <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">

    <div className="mb-3 flex items-center gap-3">

      <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-50 text-blue-600">
        {icon}
      </div>

      <h4 className="font-semibold text-slate-800">
        {title}
      </h4>

    </div>

    <p className="text-sm leading-6 text-slate-600">
      {value || 'Not specified'}
    </p>

  </div>
)


const ReviewField = ({
  label,
  value,
  setValue
}) => (
  <div>

    <label className="mb-2 block text-sm font-semibold text-slate-700">
      {label}
    </label>

    <textarea
      value={value}
      onChange={(e) => setValue(e.target.value)}
      rows={4}
      placeholder={`Enter ${label}...`}
      className="w-full resize-none rounded-xl border border-slate-300 bg-white p-3 text-sm text-slate-700 outline-none focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100"
    />

  </div>
)


/* ========================================================= */
/* ICONS */
/* ========================================================= */

const LeafIcon = () => (
  <svg
    width="30"
    height="30"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
  >
    <path d="M20 4C12 4 6 8 6 14c0 3 2 5 5 5 6 0 9-6 9-15Z" />
    <path d="M4 20c3-5 7-8 12-10" />
  </svg>
)


const UserIcon = () => (
  <svg
    width="20"
    height="20"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
  >
    <circle cx="12" cy="8" r="4" />
    <path d="M4 21c1.5-4 4-6 8-6s6.5 2 8 6" />
  </svg>
)


const ClipboardIcon = () => (
  <svg
    width="19"
    height="19"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
  >
    <rect x="5" y="4" width="14" height="17" rx="2" />
    <path d="M9 4V2h6v2M8 9h8M8 13h8M8 17h5" />
  </svg>
)


const SparkleIcon = () => (
  <svg
    width="19"
    height="19"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
  >
    <path d="M12 2l1.8 6.2L20 10l-6.2 1.8L12 18l-1.8-6.2L4 10l6.2-1.8L12 2Z" />
    <path d="M19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8L19 16Z" />
  </svg>
)


const FoodIcon = () => (
  <svg
    width="21"
    height="21"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
  >
    <path d="M4 3v18M7 3v7c0 2-1 3-3 3M11 3v18M16 3v18M16 3c3 0 4 2 4 5v3h-4" />
  </svg>
)


const BanIcon = () => (
  <svg
    width="21"
    height="21"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
  >
    <circle cx="12" cy="12" r="9" />
    <path d="M5.5 5.5l13 13" />
  </svg>
)


const MedicineIcon = () => (
  <svg
    width="21"
    height="21"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
  >
    <path d="M7 3h10v5H7zM9 8v13h6V8" />
    <path d="M10 12h4M12 10v4" />
  </svg>
)


const ScaleIcon = () => (
  <svg
    width="21"
    height="21"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
  >
    <path d="M12 3v18M5 7h14" />
    <path d="M7 7l-3 6h6L7 7ZM17 7l-3 6h6l-3-6Z" />
  </svg>
)


const ClockIcon = () => (
  <svg
    width="21"
    height="21"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
  >
    <circle cx="12" cy="12" r="9" />
    <path d="M12 7v5l3 2" />
  </svg>
)


const EditIcon = () => (
  <svg
    width="21"
    height="21"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
  >
    <path d="M4 20h4L19 9l-4-4L4 16v4Z" />
    <path d="M13 6l4 4" />
  </svg>
)


const ShieldIcon = () => (
  <svg
    width="18"
    height="18"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
  >
    <path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3Z" />
    <path d="m9 12 2 2 4-4" />
  </svg>
)


const CheckIcon = () => (
  <svg
    width="17"
    height="17"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.5"
  >
    <path d="m5 12 4 4L19 6" />
  </svg>
)


const AlertIcon = () => (
  <svg
    width="18"
    height="18"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
  >
    <path d="M12 8v5M12 17h.01" />
    <circle cx="12" cy="12" r="9" />
  </svg>
)

export default CarePopup
