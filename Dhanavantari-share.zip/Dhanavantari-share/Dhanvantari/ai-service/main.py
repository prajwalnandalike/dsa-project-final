import os
import json
import tempfile

from dotenv import load_dotenv
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from groq import Groq
from langchain_groq import ChatGroq
from langchain_core.prompts import ChatPromptTemplate

load_dotenv()

app = FastAPI(
    title="Dhanvantari AI Voice Service",
    version="1.0.0"
)

GROQ_API_KEY = os.getenv("GROQ_API_KEY")

if not GROQ_API_KEY:
    raise RuntimeError("GROQ_API_KEY is missing in .env")

groq_client = Groq(
    api_key=GROQ_API_KEY,
    timeout=120.0
)

llm = ChatGroq(
    model="llama-3.1-8b-instant",
    temperature=0,
    groq_api_key=GROQ_API_KEY,
    timeout=120,
    max_retries=2,
)


@app.get("/")
def root():
    return {
        "success": True,
        "service": "Dhanvantari AI Voice Service",
        "status": "running"
    }


@app.get("/health")
def health():
    return {
        "success": True,
        "groq_configured": bool(GROQ_API_KEY)
    }
@app.get("/groq-test")
def groq_test():
    try:
        response = groq_client.chat.completions.create(
            model="llama-3.1-8b-instant",
            messages=[
                {"role": "user", "content": "Reply with only: GROQ OK"}
            ],
            temperature=0,
        )

        return {
            "success": True,
            "message": response.choices[0].message.content
        }

    except Exception as error:
        print("Groq Test Error:", error)
        return {
            "success": False,
            "error": str(error)
        }

@app.post("/api/voice-to-structured")
async def voice_to_structured(
    audio: UploadFile = File(...),
    medical_system: str = Form("Ayurveda")
):
    temp_path = None

    try:
        # Validate audio
        if not audio.filename:
            raise HTTPException(
                status_code=400,
                detail="Audio file is required"
            )

        allowed_types = {
            "audio/webm",
            "audio/wav",
            "audio/x-wav",
            "audio/mpeg",
            "audio/mp3",
            "audio/mp4",
            "audio/m4a",
            "audio/x-m4a",
            "audio/ogg",
            "audio/flac",
        }

        if audio.content_type not in allowed_types:
            raise HTTPException(
                status_code=400,
                detail=f"Unsupported audio type: {audio.content_type}"
            )

        # Read uploaded audio
        audio_bytes = await audio.read()

        if not audio_bytes:
            raise HTTPException(
                status_code=400,
                detail="Uploaded audio is empty"
            )

        # Create temporary audio file
        suffix = os.path.splitext(audio.filename)[1] or ".webm"

        with tempfile.NamedTemporaryFile(
            delete=False,
            suffix=suffix
        ) as temp_file:
            temp_file.write(audio_bytes)
            temp_path = temp_file.name

        # ---------------------------------------------------------
        # STEP 1: GROQ SPEECH-TO-TEXT
        # ---------------------------------------------------------

        with open(temp_path, "rb") as audio_file:
            transcription = groq_client.audio.transcriptions.create(
                file=(
                    os.path.basename(temp_path),
                    audio_file.read()
                ),
                model="whisper-large-v3-turbo",
                response_format="json",
            )

        transcript = transcription.text

        if not transcript.strip():
            raise HTTPException(
                status_code=400,
                detail="No speech could be detected in the audio"
            )

        # ---------------------------------------------------------
        # STEP 2: LANGCHAIN + GROQ
        # Convert transcript into structured clinical JSON
        # ---------------------------------------------------------

        system_prompt = """
You are a clinical documentation assistant for the Dhanvantari
AYUSH digital case-taking platform.

Your job is to extract ONLY information that is explicitly present
in the doctor's transcript.

Do NOT invent, diagnose, infer, or add information that the doctor
did not state.

Medical system: {medical_system}

Return ONLY valid JSON.

Use this general structure:

{{
  "chief_complaint": "",
  "duration": "",
  "history_of_present_illness": "",
  "aggravating_factors": "",
  "relieving_factors": "",
  "associated_symptoms": "",
  "vitals": {{
    "blood_pressure": "",
    "pulse": "",
    "temperature": "",
    "respiratory_rate": ""
  }},
  "clinical_findings": "",
  "medical_system_notes": "",
  "other_information": ""
}}

For Ayurveda, medical_system_notes may contain explicitly spoken
Ayurvedic information such as Prakruthi, Vikruthi, Dosha or related
findings.

For Unani, medical_system_notes may contain explicitly spoken
Unani information such as Mizaj, Su-e-Mizaj, Akhlat, Nabz or
related findings.

For other AYUSH systems, preserve the terminology actually spoken
by the doctor.

If a field is not mentioned, return an empty string.

Never create a value just because it seems medically likely.
"""

        human_prompt = """
Doctor's transcript:

{transcript}

Extract the information into the required JSON structure.
"""

        prompt = ChatPromptTemplate.from_messages([
            ("system", system_prompt),
            ("human", human_prompt),
        ])

        chain = prompt | llm

        result = chain.invoke({
            "medical_system": medical_system,
            "transcript": transcript,
        })

        raw_content = result.content

        # ---------------------------------------------------------
        # STEP 3: CLEAN JSON RESPONSE
        # ---------------------------------------------------------

        cleaned = raw_content.strip()

        if cleaned.startswith("```json"):
            cleaned = cleaned[7:]

        if cleaned.startswith("```"):
            cleaned = cleaned[3:]

        if cleaned.endswith("```"):
            cleaned = cleaned[:-3]

        cleaned = cleaned.strip()

        try:
            structured_data = json.loads(cleaned)
        except json.JSONDecodeError:
            structured_data = {
                "chief_complaint": "",
                "duration": "",
                "history_of_present_illness": "",
                "aggravating_factors": "",
                "relieving_factors": "",
                "associated_symptoms": "",
                "vitals": {
                    "blood_pressure": "",
                    "pulse": "",
                    "temperature": "",
                    "respiratory_rate": ""
                },
                "clinical_findings": "",
                "medical_system_notes": "",
                "other_information": cleaned
            }

        return {
            "success": True,
            "medical_system": medical_system,
            "transcript": transcript,
            "structured_data": structured_data
        }

    except HTTPException:
        raise

    except Exception as error:
        print("Voice AI Error:", error)

        raise HTTPException(
            status_code=500,
            detail=f"AI processing failed: {str(error)}"
        )

    finally:
        # Delete temporary audio file
        if temp_path and os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except Exception:
                pass